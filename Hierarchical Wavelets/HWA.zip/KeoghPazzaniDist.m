function d = KeoghPazzaniDist( u, v)
%% Given two 1d arrays, reutrn distance measure adapted from Keogh and
%% Pazzani (1998) and described in Rouyer et al 2008

d = 0;
m = size(u);
for ii=1:m-1
    now = u(ii)  - v(ii);
    next = u(ii+1) - v(ii+1);
    
    d = d + atan( abs(now - next) );
    
end
    

        