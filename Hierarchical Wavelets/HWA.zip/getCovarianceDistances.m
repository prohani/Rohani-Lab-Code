function [Y,distances] = getCovarianceDistances(matrices, covariance_to_explain)
%% Given (number of matrices, rows, cols) list of arrays, return:   
%% a vector (in the for pdist uses) and an array (for easy plotting)
%% of pairwise distances between the matrices as calculated in Rouyer et al
%% (2008) "Analysing multiple time series and extending significance
%% testing to wavelet analysis"

% optional covariance_to_explain argument has default
if nargin < 2
    covariance_to_explain = 0.99;
end
    
size(matrices)
% Setup array with 0 distances
[p,n,m] = size( matrices);
distances = zeros(p);

% For each unique pair of matrices
for ii = 1:p
    for jj = 1:(ii-1)
    
        % Pair of matrices
        Wi =squeeze( matrices(ii, :, :) );
        
        
        Wj = squeeze( matrices(jj, :, :) );
        
        % Covariance matrix
        R = Wi * Wj';
        
        % SVD of covariance matrix
        [U,S,V] = svd(R);
        
        % Until sufficiant covariance has been explained,
        % walk through leading patterns and count distance
        k = 1;
        total_weight = 0;
        dist = 0;        
        while total_weight < covariance_to_explain && k <= n
            
            % From SVD, want columns of U and V and weight
            u = U(:, k);
            v = V(:, k);
            s = S(k,k);
   
            
            
            % Leading patterns by projecting onto u and v
            Li = Wi'*u;
            Lj = v'*Wj;
            
            % Vector distances as in Keogh and Pazzani (1998)
            L_dist = KeoghPazzaniDist( Li, Lj);
            uv_dist =  KeoghPazzaniDist( u, v);
            
            % Contributions to distance and total weight
            total_weight = total_weight + s;
            dist = dist + s*( L_dist + uv_dist);

        end
        
        % Rescale distance
        dist = dist / total_weight;
        % Put distance into matrix
        distances(ii,jj) = dist;
        distances(jj,ii) = dist;
    end
end

% Arrange distances in format that pdist uses
Y = zeros(1, p*(p-1)/2);
ind = 1;
for ii = 1:p-1
    for jj = ii+1:p
        Y(ind) = distances(jj, ii);
        ind = ind + 1;
    end
end

