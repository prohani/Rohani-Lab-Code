%% Test/example wavelet cluster finding code
% uses a noisy travelling wave as test case

noise_amp = 0.5; % amplitude of the noise

p = 20; % number of time series to generate
n = 100; % length of time series
m = 50;  % largest scale to look at


time  = 1:n; 
scales = 1:m;

wavelets = zeros(p,m,n);
wave = zeros(p,n);
for ii =1:p
    % Noisy waves offset by position 
    series = sin( pi*0.05*(time + (mod(ii,5))) ) + noise_amp*rand(size(time));
    
    % Save wave for plotting later
    wave(ii,:) = series;
    
    % continuous wavelet transfrom w/ Morlet wavelet
    W =  cwt( series, scales, 'morl');
    wavelets(ii,:,:) = W;
end

% Find pairwise distances
[Y, D] = getCovarianceDistances(wavelets);


    
% Get agglomerative heirarchical cluster tree    
Z = linkage(Y);
c = cluster(Z, 'maxclust', 5);

% Matrix with 1 for same cluster, 0 for different cluster
M = crosstab(c, 1:p);

% Plot time series
subplot(221)
imagesc(wave);
title('Wave')
xlabel('time')
ylabel('position')
colorbar()
% Plot pairwise distances
subplot(222)
imagesc(D);
colorbar()
colormap('autumn')
title('Distance between time series')
xlabel('position')
ylabel('position')
% Plot cluster tree
subplot(212)
dendrogram(Z);
title('Cluster tree')