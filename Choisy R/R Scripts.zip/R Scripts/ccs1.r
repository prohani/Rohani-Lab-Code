ccs1 = function(disease=selectstates(pertussis),pop=selectstates(popsize),
	from,to,graph=T,fact=1000)
{
# Set the values of the time selection if needed:
	if(missing(from)) from = floor(min(disease$time))
	if(missing(to)) to = ceiling(max(disease$time))
# Select the datasets on the specified time range:
	disease = subset(disease,time>=from & time<to)
	pop = subset(pop,year>=from & year<to)
# Calculate the proportion of months with zero notification:
	total = length(unique(disease$time))
	disease = disease[disease$count>0,]
	fadeout = 1-apply(table(disease[,c("time","state")]),2,sum)/total
# Calculate the mean population size of the states:
	pop = apply(matrix(pop$size,nrow=length(unique(pop$state))),1,mean)
# Calculating the regression curve:
	model = lm(log(fadeout+0.01)~pop)
	model = nls(fadeout~A*exp(-B*pop),
		start=list(A=exp(model$coeff[1]),B=-model$coeff[2]))
	coeff = summary(model)$coeff[1:2,1]
# Calculating the CCS:
	A = coeff[1] ; B = -coeff[2] ; thresh = 1/total
	fct = function(x){A*exp(B*x)-thresh}
	CCS = uniroot(fct,c(0,1e10))$root
# Calculating the number of states below and above the CCS:
	nb = c(total=length(pop),below=length(pop[pop<CCS]),above=length(pop[pop>CCS]))
#	out = new("ccscl",pop=pop,fadeout=fadeout,param=c(A,B),CCS=CCS,nb=nb)
	out = list(pop=pop,fadeout=fadeout,param=c(A,B),CCS=CCS,nb=nb,thresh=thresh)
	if(graph) ccsplot(out,fact=fact,pdf=pdf)
	out
}
