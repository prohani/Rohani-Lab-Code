selectstates = function(disease=pertussis,excl=
	c("Alaska","Guam","Hawaii","New York City","Northern Mariana Isl","Palau","Puerto Rico"))
{
# Eliminate the states that do not enter the analysis:
	subset(disease,!is.element(state,excl))	
}
