plotstate = function(statename="Arizona",data=pertussis,from,to,transf)
# This function plots the time series of cases of state 'statename' from
# year 'from' to year 'to'. The dataset should be a dataframe with three
# columns named 'time', 'count' and 'state' respectively.
{
# Set the values of the time selection if needed:
	if(missing(from)) from = floor(min(data$time))
	if(missing(to)) to = ceiling(max(data$time))
# selecting the data to plot:
	data = subset(data,state==statename & time>=from & time<=to)
# Transform the data:
	if(!missing(transf))
	{	
		if(transf=='log') data$count = log(data$count+1)
		if(transf=='sqrt') data$count = sqrt(data$count)
	}
# plotting the data :
	plot(data$time,data$count,xlab="year",ylab="",type="l",main=statename)
	if(missing(transf)) title(ylab="number of cases")
	else
	{	
		if(transf=="sqrt") title(ylab="Sqrt(number of cases)")
		if(transf=="log") title(ylab="Log(number of cases + 1)")
	}
	cat(paste("\n\tPlotted state:",statename,"\n\n"))
}

