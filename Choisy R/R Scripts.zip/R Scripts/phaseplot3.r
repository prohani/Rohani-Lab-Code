phaseplot3 = function(state="New York",data=pertussis,from=1951,to=1963,lower=3.5,upper=4.5)
{
# Set the values of the time selection if needed:
#	if(missing(from)) from = floor(min(data$time))
#	if(missing(to)) to = ceiling(max(data$time))
	phases = NULL
	states = unique(selectstates(data)$state)
	for(i in states)
		phases = cbind(phases,transfphase(waveletfilter(waveletanalysis(i,from,to,data,F),lower,upper)$phase_ts))
# Creates the time vector:
	times = unique(subset(data,time>=from & time<=to)$time)
# Performs the linear regression:
	mod = lm(as.vector(phases)~rep(times,49))
# And calculate the residuals:
	pred = mod$coef[1]+mod$coef[2]*times
	pred = matrix(rep(pred,49),ncol=49)
# Put the data in shape and draw the plot:
	phases = phases1 = phases-pred
	phases = as.vector(t(phases))
	X = rep(centroids[states,"X"],144)
	par(mgp=c(1.5,0.5,0))
#	plot(jitter(X,100),phases,cex=0.1)
#	plot(jitter(X,300),phases,pch=".")
	plot(X,phases,xlab="longitude")
# We may want to explain the phase residuals as a function of both latitude and longitude:
#	Y = rep(centroids[states,"Y"],144)
#	mod=lm(phases~X*Y)
#	mod
}
