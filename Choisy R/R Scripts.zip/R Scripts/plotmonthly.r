plotmonthly = function(thestate="Alabama",plot=T)
# This function plots the weekly cases on the 2003-2007 period.
{
	a = read.table('newdata0307.dat',sep='\t')
	names(a) = c("year","week","count","state")
	a = subset(a,state==thestate)
	time = a$year+a$week/53
	months = seq(2003,2008,1/12)
	newcounts = NULL
	for(i in 1:(5*12))
		newcounts = c(newcounts,sum(a$count[time>months[i] & time<=months[i+1]]))
	if(plot)
	{
		par(mgp=c(1.5,0.5,0))
		plot(months[-length(months)],newcounts,type="l",xlab="time (week)",ylab="pertussis cases")
	}
	else cbind(months[-length(months)],newcounts)
}
