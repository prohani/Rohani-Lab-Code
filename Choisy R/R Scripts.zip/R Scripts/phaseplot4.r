phaseplot4 = function(data=pertussis,from=1951,to=1963,lower=3.5,upper=4.5,mtype="smooth",alpha=0.01,pad=128,method="method1")
{
	require(maps)
# Set the values of the time selection if needed:
#	if(missing(from)) from = floor(min(data$time))
#	if(missing(to)) to = ceiling(max(data$time))
	states = unique(selectstates(data)$state)
	nbstates = length(states)
# Calculate and linearly transform the phases for all the states:
	phases = NULL
	if(method=="method1")
		for(i in states)
			phases = cbind(phases,transfphase(waveletfilter(waveletanalysis(i,from,to,data,F,pad=pad),lower,upper)$phase_ts))
	else
	{
		for(i in states)
			phases = cbind(phases,transfphase(waveletfilter(waveletanalysis(i,data=data,plot=F,pad=pad),lower,upper)$phase_ts))
		phases = phases[unique(data$time)>=from & unique(data$time)<to,]
	}
# This replaces the commented lines below:
	phases = phases - apply(phases,1,mean,na.rm=T)
## Do the linear regression of the phases as a function of time:
#	times = unique(subset(data,time>=from & time<=to)$time)
#	mod = lm(as.vector(phases)~rep(times,nbstates))
## Take the residuals of the phases:
#	pred = mod$coef[1]+mod$coef[2]*times
#	pred = matrix(rep(pred,nbstates),ncol=nbstates)
#	phases = phases-pred

# Calculate the mean phase angle for each state:
	themeans = apply(phases,2,mean,na.rm=T)
# Put the phase angles into a good shape:
	phases = as.vector(t(phases))
# Extract the longitude and latitude coordinates:
	X = rep(centroids[states,"X"],12*(to-from))
	Y = rep(centroids[states,"Y"],12*(to-from))
# The figure:	
	width=4.5; height=4
	xlim = c(-125,-67); ylim = c(25,50)
	x11(width=width,height=height)
#	ratio = 0.528758689183387*width/height
	ratio = width/(1.75*height)
# The first graph: the USA map:
#	plt = c(0.12,0.95,NA,0.95)
	plt = c(0.32,0.95,NA,0.9)
	plt[3] = plt[4]-(plt[2]-plt[1])*ratio
	par(plt=plt)
	tmp = map("usa",plot=F)
	end = which(is.na(tmp$x))[1]-1
	tmp$x = tmp$x[1:end]
	tmp$y = tmp$y[1:end]
	plot(tmp$x,tmp$y,type="n",axes=F,ann=F,xlim=xlim,ylim=ylim,xaxs="i",yaxs="i")
# Fist type of map:
	if(mtype=="none") map("usa",col="grey",fill=T,add=T)
# Second type of map:
	else if(mtype=="smooth")
	{
		require(gam)
		regamlolo = gam(phases~lo(X)+lo(Y)+lo(X,Y),family=gaussian)
		lwidth = 300#100
		lheight = 200#70
		x = seq(-125,-67,length=lwidth)
		x = seq(-125,-67,length=lwidth)
		y = seq(25,50,length=lheight)
		y = seq(25,50,length=lheight)
		xv = rep(x,lheight)
		yv = rep(y,each=lwidth)
		v = predict(regamlolo,newdata=data.frame(Y=yv,X=xv))
		mv = matrix(v,lwidth,lheight)
#		image(x,y,mv,col=rainbow(100),ann=F,axes=F)
		image(x,y,mv,col=rev(heat.colors(10)),ann=F,axes=F)
		contour(x,y,mv,add=T)
		polygon(c(tmp$x,tmp$x[1],tmp$x[1],-127,-127,-65,-65,tmp$x[1],tmp$x[1]),
			c(tmp$y,tmp$y[1],23,23,60,60,23,23,tmp$y[1]),col="white",border="white")
#		polygon(c(tmp$x,tmp$x[1],tmp$x[1],-130,-130,-60,-60,tmp$x[1],tmp$x[1]),
#			c(tmp$y,tmp$y[1],20,20,60,60,20,20,tmp$y[1]),col="white",border="white")
#		polygon(c(tmp$x,tmp$x[1],tmp$x[1],min(x),min(x),max(x),max(x),tmp$x[1],tmp$x[1]),
#			c(tmp$y,tmp$y[1],min(y),min(y),max(y),max(y),min(y),min(y),tmp$y[1]),col="white",border="white")
		points(tmp$x,tmp$y,type="l")
	}
# Third type of map:
	else if(mtype=="state")
	{
#		thecolors = heat.colors(100)
		thecolors = rainbow(100)
		thecol = function(x)
			which(hist(x,breaks=seq(1*min(themeans),1.05*max(themeans),length=101),plot=F)$counts>0)
		colors = thecolors[unlist(lapply(themeans,function(x)thecol(x)))]
		for(i in 1:length(states))
			map("state",translatestates[translatestates[,1]==states[i],2],col=colors[i],fill=T,add=T)
	}
# Plot the centroids:
	for(i in states) points(centroids[i,"X"],centroids[i,"Y"],pch=20)
# The second graph: residual phase angles vs longitude:
	regloess = loess(phases~X)
	u = seq(min(X),max(X),length=100)
	v = predict(regloess,data.frame(X=u),se=T)
	vu=c(v$fit+qnorm(1-alpha/2)*v$se.fit,rev(v$fit-qnorm(1-alpha/2)*v$se.fit))
	plt = plt0 = par('plt')
	plt[4] = plt[3]
	plt[3] = 0.12
	par(plt=plt,new=T,mgp=c(1.5,0.5,0))
	ylim2 = c(-2,2)
	plot(X,phases,pch=".",xlim=xlim,ylim=ylim2,xlab="longitude (degree)",
		ylab="residual phase angle (radian)",xaxs="i",yaxs="i",axes=F,type="n")
	axis(1); axis(2)
	polygon(c(u,rev(u))[is.na(vu)==FALSE],vu[is.na(vu)==FALSE],col="light grey",border=FALSE)
	points(X,phases,pch=".")
	points(centroids[states,"X"],themeans,pch=20)
	lmconfint(cbind(X,phases))
# The third graph: latitude vs residual phase angles:
	phasesW = phases[X<(-100)]
	phasesE = phases[X>(-100)]
	YW = Y[X<(-100)]
	YE = Y[X>(-100)]
	regloessW = loess(phasesW~YW)
	regloessE = loess(phasesE~YE)
	uW = seq(min(YW),max(YW),length=100)
	uE = seq(min(YE),max(YE),length=100)
	vW = predict(regloessW,data.frame(YW=uW),se=T)
	vE = predict(regloessE,data.frame(YE=uE),se=T)
	vuW=c(vW$fit+2.576*vW$se.fit,rev(vW$fit-2.576*vW$se.fit))
	vuE=c(vE$fit+2.576*vE$se.fit,rev(vE$fit-2.576*vE$se.fit))
	plt0[2] = 0.95*plt0[1]
	plt0[1] = 0.1
	par(plt=plt0,new=T)
	plot(phases,Y,pch=".",xlim=c(-2,2),ylim=ylim,xlab="",ylab="latitude (degree)",
		xaxs="i",yaxs="i",axes=F,type="n")
	axis(3); axis(2,seq(30,45,5))
#	polygon(vuW[is.na(vuW)==FALSE],c(uW,rev(uW))[is.na(vuW)==FALSE],col="light pink",border=FALSE)
#	polygon(vuE[is.na(vuE)==FALSE],c(uE,rev(uE))[is.na(vuE)==FALSE],col="light blue",border=FALSE)
	points(phases,Y,pch=".")
#	points(phasesW,YW,pch=".",col="red")
#	points(phasesE,YE,pch=".",col="blue")
	points(themeans,centroids[states,"Y"],pch=20)
#	points(themeans[X<(-100)],centroids[states,"Y"][X<(-100)],pch=20,col="red")
#	points(themeans[X>(-100)],centroids[states,"Y"][X>(-100)],pch=20,col="blue")
	mtext("residual phase angle (radian)",line=1.5)
# The fourth graph: the color scale:
	if(mtype=="state" | mtype=="smooth")
	{
		plt[1] = 0.15; plt[2] = 0.2; par(plt=plt,new=T)
		colrange = seq(min(themeans),max(themeans),length=100)
		scalecol = matrix(rep(colrange,25),ncol=25)
#		image(1:25,colrange,t(scalecol),col=rainbow(100),ylim=ylim2,ann=F,axes=F)
		image(1:25,colrange,t(scalecol),col=rev(heat.colors(12)),ylim=ylim2,ann=F,axes=F)
		rect(1,max(colrange[1],ylim2[1]),25,min(colrange[length(colrange)],ylim2[2]))
	}
# Give the output:
	list(x=x,y=y,mv=mv,tmp=tmp,X=X,Y=Y,phases=phases,u=u,vu=vu,centroids=centroids,states=states,themeans=themeans)
}
