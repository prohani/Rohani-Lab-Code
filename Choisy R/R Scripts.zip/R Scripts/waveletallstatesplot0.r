waveletallstatesplot = function(object,from,to,pvalue,transf,centered,test,ns,ps,amp,ylab="number of cases")
# This function draws the plot of a wavelet decomposition.
{
	if(sum(names(object)==c("time","period","power","themax","themax2"))==5)
	{
		time = object$time
		period = object$period
		power = object$power
		themax = object$themax
		themax2 = object$themax2
		giveresults = F
	}
	else
	{
		giveresults = T
# Calculate the vector of periods:
		period = object[[1]]$fourier_factor*object[[1]]$scale
# Calculate the significativity and the power:
#		out = lapply(object,function(x)wavelettest2(x,test,pvalue))
		thelength = length(object)
		pvp = power = 0
		for(i in 1:thelength)
		{
#			pvp = pvp+out[[i]]$pv
			power = power+wavepower(object[[i]])
		}
#		pvp = t(pvp)
#		pvp = pvp[,ncol(pvp):1]
#		pvp = pvp/thelength
#		pvp = pvp^0.3
	
# Calculating the maximum period:
		nr = nrow(power)
		nc = ncol(power)
		themax = apply(power,2,max)
		themax = matrix(rep(themax,nr),byrow=T,nrow=nr)
		themax = period[which(power==themax)-seq(0,by=nr,length=nc)]
		themax[which(themax==max(period)|themax==min(period))] = NA

# Calculating the maximum period:
		power2 = power[period<1.5,]
		nr = nrow(power2)
		nc = ncol(power2)
		themax2 = apply(power2,2,max)
		themax2 = matrix(rep(themax2,nr),byrow=T,nrow=nr)
		themax2 = period[which(power2==themax2)-seq(0,by=nr,length=nc)]
		themax2[which(themax2==max(period)|themax2==min(period))] = NA

		power = t(power)#^0.3)
		power = power[,ncol(power):1]
# Calculate the time vector:
		time = seq(from,to,object[[1]]$dt)
		time = time[-length(time)]
	}

# Ploting the local wavelet power spectrum:
	parplt = c(0.15,0.79,0.3,0.65); par(plt=parplt,mgp=c(1.5,0.5,0))
	image(time,period,power^0.3,xlab="time (year)",ylab="period (year)",axes=F,col=heat.colors(10))
#	points(time,object[[1]]$upP-themax,type="l",lty=2,col="black")
	points(time,sum(range(period))-themax,type="l",lty=2,col="black")
	points(time,sum(range(period))-themax2,type="l",lty=2,col="black")
#	abline(h=object[[1]]$upP-1,lty=2,col="black")
#	image(time,period,power,xlab="time (year)",ylab="period (year)",axes=F,col=rev(rainbow(100,from=0,end=0.7,gamma=1)))
#	contour(time,period,pvp,levels=c(pvalue,1),add=T,drawlabels=F)
##	contour(time,period,pvp,levels=1,add=T,drawlabels=F)
#	points(time,max(period)-object$coi,col="white",type="l")
	show(pretty(period))
	show(as.character(rev(pretty(period))))
	axis(1,pretty(time))
	tmp = range(period)
	axis(2,rev(sum(tmp)-pretty(tmp)),as.character(rev(pretty(period))))
#	axis(2,pretty(period),as.character(rev(pretty(period))))
	box()
## Plot the time series:
#	parplt[3:4]=c(0.65,0.85); par(plt=parplt,new='T')
#	plot(time,object$y,type="l",xaxs='i',axes=F,xlab="",ylab=ylab,col="blue")
#	axis(2); box()
# Plot the global wavelet power spectrum:
#	parplt = c(0.79,0.99,0.3,0.65); par(plt=parplt,new='T')
#	plot(c(global_ws,gm_ws),rep(-period,2),xlab="power",ylab="",type="n",xaxs='i',yaxs='i',axes=F)
#	points(global_ws,-period,type="l",col="blue")
#	points(gm_ws,-period,type="l",lty=2)
#	axis(1); box()
	if(giveresults) list(time=time,period=period,power=power,themax=themax,themax2=themax2)
}
