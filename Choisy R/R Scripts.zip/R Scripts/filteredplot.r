filteredplot = function(state1="New York",state2="Colorado",data=pertussis,
	from=1951,to=1963,lower=3.5,upper=4.5,pad=128,method="method1",what="filtr_ts",transform=F,resid=F)
# There are two ways of doing it. Either we do the wavelet analysis on the specified time period and then
# we filter the times series (method 1), or we first filter the time series over the all period and then
# we select the time period we are interested in (method 2).
#
# what: could be either "filtr_ts" or "phase_ts".
# tranform: in case we are dealing with phases, tell whether or not we want to linearly transform them.
{
# Set the values of the time selection if needed:
#	if(missing(from)) from = floor(min(data$time))
#	if(missing(to)) to = ceiling(max(data$time))
	if(what=="phase_ts" & transform) f = function(x) transfphase(x)
	else f = function(x) x
	filtered = NULL
	states = unique(selectstates(data)$state)
# The first method: we filter only on the specified time period:
	if(method=="method1")
		for(i in states)
		{
			tmp = waveletanalysis(i,from,to,data,F,pad=pad)
			filtered = rbind(filtered,f(waveletfilter(tmp,lower,upper)[[what]]))
		}
# The second method: we first filter and then select the specified the time period:
	else
	{
		for(i in states)
		{
			tmp = waveletanalysis(i,data=data,plot=F,pad=pad)
			filtered = rbind(filtered,f(waveletfilter(tmp,lower,upper)[[what]]))
		}
# Note that the columns of the filtered matrix are, by construction, in the same time order as the data$time vector:
		filtered = filtered[,unique(data$time)>=from & unique(data$time)<to]
	}
# Possibly plot the residuals:
	if(resid)
	{
		meanphases = apply(filtered,2,mean,na.rm=T)
		filtered = t(t(filtered) - meanphases)
	}
# The time vector:
	times = unique(subset(data,time>=from & time<=to)$time)
# The graphic:
	par(mgp=c(1.5,0.5,0))
	plot(times,filtered[1,],type="l",xlab="year",ylab="quadriennal component",col="grey",ylim=range(as.vector(filtered),na.rm=T))
	for(i in 2:length(states)) points(times,filtered[i,],type="l",col="grey")
	if(!state1=="") points(times,filtered[which(states==state1),],type="l",col="red")
	if(!state2=="") points(times,filtered[which(states==state2),],type="l",col="blue")
# The output:
	list(times=times,filtered=filtered,states=states,state1=state1,state2=state2)
}
