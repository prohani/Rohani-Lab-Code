randusa = function(nb=1158)
{
	require(maps)
	tmp = map("usa",plot=F)
	end = which(is.na(tmp$x))[1]-1
	x = round(tmp$x[1:end])
	y = round(tmp$y[1:end])
	minx = min(x)
	miny = min(y)
	rangex = range(x)
	rangey = range(y)
	randxy = NULL
	count = 0
	while(count<nb)
	{
		randx = minx+diff(rangex)*runif(1)
		randy = miny+diff(rangey)*runif(1)
		foo = abs(x-randx)
		bar = range(y[foo==min(foo)])
		if(randy>=bar[1]&randy<=bar[2])
		{
			randxy = rbind(randxy,c(randx,randy))
			count = count+1
		}
	}
	randxy
}
