waveletallstatesplot = function(object,from,to,pvalue,transf,centered,test,ns,ps,amp)
# This function draws the mean power spectrum across all states.
{
	if(sum(names(object)==c("time","period","power","themax","themax2"))==5)
	{
		time = object$time
		period = object$period
		power = object$power
		themax = object$themax
		themax2 = object$themax2
		giveresults = F
	}
	else
	{
		giveresults = T
# Calculate the vector of periods:
		period = object[[1]]$fourier_factor*object[[1]]$scale
# Calculate the mean power across all states:
		thelength = length(object)
		power = 0
		for(i in 1:thelength) power = power+wavepower(object[[i]])
# Calculating the first maximum period:
		nr = nrow(power)
		nc = ncol(power)
		themax = apply(power,2,max)
		themax = matrix(rep(themax,nr),byrow=T,nrow=nr)
		themax = period[which(power==themax)-seq(0,by=nr,length=nc)]
		themax[which(themax==max(period)|themax==min(period))] = NA
# Calculating the second maximum period:
		power2 = power[period<1.5,]
		nr = nrow(power2)
		nc = ncol(power2)
		themax2 = apply(power2,2,max)
		themax2 = matrix(rep(themax2,nr),byrow=T,nrow=nr)
		themax2 = period[which(power2==themax2)-seq(0,by=nr,length=nc)]
		themax2[which(themax2==max(period)|themax2==min(period))] = NA
# Putting the power matrix in good shape for plotting:
		power = t(power)
		power = power[,ncol(power):1]
# Calculate the time vector:
		time = seq(from,to,object[[1]]$dt)
		time = time[-length(time)]
	}
# Ploting the local wavelet power spectrum:
#	parplt = c(0.15,0.79,0.25,0.65); par(plt=parplt,mgp=c(1.5,0.5,0))
	parplt = c(0.1,0.85,0.15,0.65); par(plt=parplt,mgp=c(1.5,0.5,0))
	powert = power^0.3
	image(time,period,powert,xlab="time (year)",ylab="period (year)",axes=F,col=rev(heat.colors(10)))
	points(time,sum(range(period))-themax,type="l",lty=2,col="black")
	points(time,sum(range(period))-themax2,type="l",lty=2,col="black")
	axis(1,pretty(time))
	tmp = range(period)
	axis(2,rev(sum(tmp)-pretty(tmp)),as.character(rev(pretty(period))))
	box()
# Plot the time series:
	parplt[3:4]=c(0.65,0.9); par(plt=parplt,new='T')
	tmp = prevalencestate()
	tmp = apply(matrix(tmp[,2],ncol=length(unique(tmp[,3]))),1,mean)
	plot(time,tmp,type="l",xaxs='i',axes=F,xlab="",ylab="incidence",col="blue")
	axis(2); box()
# Add the scale:
	par(plt=c(0.87,0.89,0.15,0.9),new=T)
	colrange = seq(min(powert),max(powert),length=10)
	scalecol = matrix(rep(colrange,25),ncol=25)
	image(1:25,colrange,t(scalecol),col=rev(heat.colors(10)),ann=F,axes=F)
	axis(4,pretty(range(powert)),as.character(round(pretty(range(powert))^(1/0.3))))
	mtext("local power",4,line=1.5); box()
#	rect(1,max(colrange[1],ylim2[1]),25,min(colrange[length(colrange)],ylim2[2]))
	if(giveresults) list(time=time,period=period,power=power,themax=themax,themax2=themax2)
}
