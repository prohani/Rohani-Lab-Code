#wavepower = function(object) abs(object$wave)^2
wavepower = function(object,from,to)
{
	if(missing(from) | missing(to)) out = abs(object$wave)^2
	else
	{
		time = object$time
		sel = time>=from & time<to
		wave = object$wave
		out = abs(wave[,sel])^2
	}
	out
}

#waveglobal = function(object) var(object$y)*apply(wavepower(object),1,mean)
waveglobal = function(object,from,to)
{
	if(missing(from) | missing(to)) out = var(object$y)*apply(wavepower(object),1,mean)
	else
	{
		ts = object$y
		time = object$time
		sel = time>=from & time<to
		variance = var(ts[sel])
		power = wavepower(object,from,to)
		out = variance*apply(power,1,mean)
	}
	out
}
