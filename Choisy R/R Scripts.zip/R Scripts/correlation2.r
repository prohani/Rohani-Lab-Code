correlation2 = function(disease=selectstates(pertussis),from,mid,to,
	transf,xlimits,ylimits,eps=0,graph=T)
# This function cuts the dataset _disease_ into 2 time periods
# defined by _from_, _mid_, and _to_. It then calculates the
# correlation coefficients for each pair of states for the two
# time periods. The histograms of the correlation coefficients
# can be plotted.
{
# Load the needed library:
	require(ecodist)
# Transform the data:
	if(!missing(transf))
	{
		if(transf=='log') disease$count = log(disease$count+1)
		if(transf=='sqrt') disease$count = sqrt(disease$count)
	}
# Set the values of the time selection if needed:
	if(missing(from)) from = floor(min(disease$time))
	if(missing(to)) to = ceiling(max(disease$time))
	if(missing(mid)) mid = round(mean(c(from,to)))
# Segreggates the dataset in two datasets:
	disease1 = subset(disease,time>=from & time<mid)$count
	disease2 = subset(disease,time>=mid & time<to)$count
# Calculate the correlation coefficients:
	nbstates = length(unique(disease$state))
	disease1 = lower(cor(as.data.frame(matrix(disease1,ncol=nbstates))))
	disease2 = lower(cor(as.data.frame(matrix(disease2,ncol=nbstates))))
# Output:
	out = list(series1=disease1,series2=disease2,from=from,mid=mid,to=to)
	if(graph) correlplot(out,xlimits,ylimits,eps)
	else(out)
}
