figureS2 = function()
{
# width = 5.5, height = 2.25
	x1 = 0.12
	x2 = 0.61
	par(plt=c(x1,x1+0.335,0.225,0.88),mgp=c(1.5,0.5,0))
	correlation2()
	par(plt=c(x2,x2+0.335,0.225,0.88),mgp=c(1.5,0.5,0),new=T)
	corrchanges()
# Write the subfigure letters:
	t = 0.1
	x3 = x1-t
	x4 = x2-t
	par(plt=c(x3,x3+0.05,0.88,0.93),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(5,5,"A",font=2)
	par(plt=c(x4,x4+0.05,0.88,0.93),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(5,5,"B",font=2)
}
