corrdistangle1 = function(from=1951,to=1964,data=selectstates(pertussis))
# This function plots the spatial correlation function for one time period using Sncf.
{
	require(ncf)
	require(plotrix)
# Set the values of the time selection if needed:
#	if(missing(from)) from = floor(min(data$time))
#	if(missing(to)) to = ceiling(max(data$time))
# Select the time range:
	data = subset(data,time>=from & time<to)
# Calculate the spatial correlation:
	states = unique(data$state)
	coord = centroids[states,]
	data = t(matrix(data$count,ncol=length(states)))
	angles = seq(0,2*pi,length=100)
	out = Sncf2D(coord$X,coord$Y,data,resamp=0,quiet=T,angle=180*(pi/2-angles)/pi)
	themax = NULL
	for(i in 1:length(angles)) themax = c(themax,max(out$real[[i]]$predicted$y,na.rm=T))
	x = themax*cos(angles)
	y = themax*sin(angles)
	par(pty="s",las=1,mar=rep(2,4))
	corrmax = ceiling(10*max(themax))/10
	corrlim = c(-corrmax,corrmax)
	thecircles = seq(0.1,corrmax,0.1)
	plot(x,y,xlim=corrlim,ylim=corrlim,axes=F,ann=F,type="l",col="blue")
	abline(h=0)
	abline(v=0)
	for(i in thecircles) draw.circle(0,0,i,lty=2)
	mtext("S",1); mtext("W",2); mtext("N",3); mtext("E",4)
	cbind(x,y)
}
