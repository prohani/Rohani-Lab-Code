corrdistanceX = function(before=T,data=selectstates(pertussis),out=datacorrdistanceXbefore)
# This function plots the spatial correlation functions for periods of time of increasing duration.
{
	require(ncf)
# General parameters:
	states = unique(data$state)
	coord = centroids[states,]
	X = coord$X
	Y = coord$Y
	theends = seq(1952,2008,5)
	nbends = length(theends)
	giveresult = F
	if(is.null(out))
	{
		giveresult = T
		out = vector("list",nbends)
		for(i in 1:nbends)
		{
# Creates the news dataset:
			end = theends[i]
			if(before) data1 = subset(data,time<end)
			else data1 = subset(data,time>=end)
			data1 = t(matrix(data1$count,ncol=length(states)))
# Calculates the spaial correlations:
			out[[i]] = Sncf(X,Y,data1,latlon=T,quiet=T,resamp=1000)
		}
	}
	else
	{
		before = out$before
		out = out$out
	}
# Draws the graphs:
	x1 = out[[1]]$boot$boot.summary$predicted$x
	y1l = out[[1]]$boot$boot.summary$predicted$y["0.025",]
	y1u = out[[1]]$boot$boot.summary$predicted$y["0.975",]
	par(mgp=c(1.5,0.5,0))
	if(before) {col1 = "red"; col2 = rgb(1,0,0,0.1)}
	else {col1 = "blue"; col2 = rgb(0,0,1,0.1)}
	plot(out[[1]]$real$predicted$x,out[[1]]$real$predicted$y,type="l",ylim=c(0,1),
		col=col1,xlab="distance (km)",ylab="correlation")
	polygon(c(x1,rev(x1)),c(y1l,rev(y1u)),col=col2,border=NA)
	for(i in 2:nbends)
	{
		points(out[[i]]$real$predicted$x,out[[i]]$real$predicted$y,type="l",col=col1)
		x1 = out[[i]]$boot$boot.summary$predicted$x
		y1l = out[[i]]$boot$boot.summary$predicted$y["0.025",]
		y1u = out[[i]]$boot$boot.summary$predicted$y["0.975",]
		polygon(c(x1,rev(x1)),c(y1l,rev(y1u)),col=col2,border=NA)
	}
# Gives the output:
	if(giveresult) list(out=out,before=before)
}
