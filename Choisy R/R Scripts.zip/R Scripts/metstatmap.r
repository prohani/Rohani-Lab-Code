metstatmap = function(data=datameandist,stat="mean",thresh=100,tickmax=25)
# width = 6.9, height = 4
{
	require(maps)
	nbcol = 12
	t1 = 0.01
	t2 = 0.01
	x1 = 0.07-t1
	x2 = 0.17-t1
	x3 = 0.17-t1
	x4 = 0.5065-t1
	x5 = 0.5065+t2
	x6 = 0.825+t2
	x7 = 0.825+t2
	x8 = 0.925+t2
	y1 = 0.114125
	y2 = 0.48125
	y3 = 0.51125
	y4 = 0.889375
	xlim = c(-125,-67); ylim = c(25,50)

	met1950 = subset(met1950,!is.element(state,c("Alaska","Puerto Rico","Hawaii")))
	met2000 = subset(met2000,!is.element(state,c("Alaska","Puerto Rico","Hawaii")))
	alpha = 0.5

	tmp = map("usa",plot=F)
	end = which(is.na(tmp$x))[1]-1
	tmp$x = tmp$x[1:end]
	tmp$y = tmp$y[1:end]

	lwidth = 300
	lheight = 200
	x = seq(-125,-67,length=lwidth)
	x = seq(-125,-67,length=lwidth)
	y = seq(25,50,length=lheight)
	y = seq(25,50,length=lheight)
	xv = rep(x,lheight)
	yv = rep(y,each=lwidth)


	if(is.null(data))
	{
		require(gam)
		
		datamet1950 = distance2(met1950)
		distances1950 = matrix(datamet1950$dist,nrow=nrow(met1950)-1)
		distances1950 = as.data.frame(distances1950)
		if(stat=="mean") statdist1950 = unlist(lapply(distances1950,mean))
		else if(stat=="median") statdist1950 = unlist(lapply(distances1950,median))
		else if(stat=="count")
			statdist1950 = unlist(lapply(distances1950,function(x)sum(x<thresh)))
		thestates1950 = matrix(datamet1950$state,nrow(met1950)-1)[1,]
		statelist1950 = unique(thestates1950)
		statemean1950 = lapply(statelist1950,function(x)mean(statdist1950[thestates1950==x]))
		confidint1950 = lapply(distances1950,function(x)sort(na.exclude(x)))
		confidint1950 = lapply(confidint1950,function(x)
			x[c(round((alpha/2)*length(x)),round((1-alpha/2)*length(x)))])
		confidint1950 = matrix(unlist(confidint1950),byrow=T,ncol=2)

		datamet2000 = distance2(met2000)
		distances2000 = matrix(datamet2000$dist,nrow=nrow(met2000)-1)
		distances2000 = as.data.frame(distances2000)
		if(stat=="mean") statdist2000 = unlist(lapply(distances2000,mean))
		else if(stat=="median") statdist2000 = unlist(lapply(distances2000,median))
		else if(stat=="count")
			statdist2000 = unlist(lapply(distances2000,function(x)sum(x<thresh)))
		thestates2000 = matrix(datamet2000$state,nrow(met2000)-1)[1,]
		statelist2000 = unique(thestates2000)
		statemean2000 = lapply(statelist2000,function(x)mean(statdist2000[thestates2000==x]))
		confidint2000 = lapply(distances2000,function(x)sort(na.exclude(x)))
		confidint2000 = lapply(confidint2000,function(x)
			x[c(round((alpha/2)*length(x)),round((1-alpha/2)*length(x)))])
		confidint2000 = matrix(unlist(confidint2000),byrow=T,ncol=2)

		X = met1950$lon
		Y = met1950$lat
		regamlolo = gam(statdist1950~lo(X)+lo(Y)+lo(X,Y),family=gaussian)
		v = predict(regamlolo,newdata=data.frame(Y=yv,X=xv))
		v[v<0]=0
		mv1950 = matrix(v,lwidth,lheight)

		X = met2000$lon
		Y = met2000$lat
		regamlolo = gam(statdist2000~lo(X)+lo(Y)+lo(X,Y),family=gaussian)
		v = predict(regamlolo,newdata=data.frame(Y=yv,X=xv))
		v[v<0]=0
		mv2000 = matrix(v,lwidth,lheight)

		output = T
	}
	else
	{
		statdist1950 = data$statdist1950
		statdist2000 = data$statdist2000
		mv1950 = data$mv1950
		mv2000 = data$mv2000
		statelist1950 = data$statelist1950
		statelist2000 = data$statelist2000
		statemean1950 = data$statemean1950
		statemean2000 = data$statemean2000
		output=F
	}
	themin = max(min(c(mv1950,mv2000)),0)
	themax = max(c(mv1950,mv2000))
	therange = range(c(mv1950,mv2000))
	if(stat=="count") countmax = max(c(statdist1950,statdist2000))

# The first distances-latitude plot on the left of the first map:
	par(plt=c(x1,x2,y3,y4),mgp=c(1.5,0.5,0))
	if(stat=="count")
		plot(datamet1950[,1],datamet1950[,3],ylim=ylim,ylab="latitude (degree)",xlab="",xaxs="i",yaxs="i",axes=F,type="n",xlim=c(0,countmax))
	else
		plot(datamet1950[,1],datamet1950[,3],ylim=ylim,ylab="latitude (degree)",xlab="",xaxs="i",yaxs="i",axes=F,type="n",xlim=c(0,4000))
	axis(3); axis(2)
	points(statdist1950,met1950$lat,col="red")
	points(statemean1950,centroids[statelist1950,"Y"],pch=19)
	if(stat=="count") mtext("           number of centers within radius",line=1.5)
	else mtext("  distance to other centers",line=1.5)
# The first map:
	par(plt=c(x3,x4,y3,y4),new=T)
#	image(x,y,mv1950,col=rev(heat.colors(10)),ann=F,axes=F)
	image(x,y,mv1950,col=rev(heat.colors(10))[round((min(mv1950)-themin)/diff(therange)+1):round(10-(themax-max(mv1950))/diff(therange))],ann=F,axes=F)
#	contour(x,y,mv1950,add=T)
	polygon(c(tmp$x,tmp$x[1],tmp$x[1],-127,-127,-65,-65,tmp$x[1],tmp$x[1]),
		c(tmp$y,tmp$y[1],23,23,60,60,23,23,tmp$y[1]),col="white",border="white")
	points(tmp$x,tmp$y,type="l")
	points(met1950$lon,met1950$lat,cex=0.5)
	mtext("1950",3,0.3,col="red")
# The second map:
	par(plt=c(x5,x6,y3,y4),new=T)
#	image(x,y,mv2000,col=rev(heat.colors(10)),ann=F,axes=F)
	image(x,y,mv2000,col=rev(heat.colors(10))[round((min(mv2000)-themin)/diff(therange)+1):round(10-(themax-max(mv2000))/diff(therange))],ann=F,axes=F)
#	contour(x,y,mv2000,add=T)
	polygon(c(tmp$x,tmp$x[1],tmp$x[1],-127,-127,-65,-65,tmp$x[1],tmp$x[1]),
		c(tmp$y,tmp$y[1],23,23,60,60,23,23,tmp$y[1]),col="white",border="white")
	points(tmp$x,tmp$y,type="l")
	points(met2000$lon,met2000$lat,pch=1,cex=0.5)
	mtext("2000",3,0.3,col="blue")
# The second distances-latitude plot on the right of the second map:
	par(plt=c(x7,x8,y3,y4),new=T,mgp=c(1.5,0.5,0))
	if(stat=="count")
	{
		plot(countmax-datamet2000[,1],datamet2000[,3],ylim=ylim,ylab="",xlab="",xaxs="i",yaxs="i",axes=F,type="n",xlim=c(0,countmax))
		points(countmax-statdist2000,met2000$lat,col="blue")
		points(countmax-unlist(statemean2000),centroids[statelist2000,"Y"],pch=19)
		axis(3,pretty(seq(0,countmax,length=10)),paste(rev(pretty(seq(0,countmax,length=10))))); axis(4)
	}
	else
	{
		plot(4000-datamet2000[,1],datamet2000[,3],ylim=ylim,ylab="",xlab="",xaxs="i",yaxs="i",axes=F,type="n",xlim=c(0,4000))
		points(4000-statdist2000,met2000$lat,col="blue")
		points(4000-unlist(statemean2000),centroids[statelist2000,"Y"],pch=19)
		axis(3,pretty(seq(0,4000,1000)),paste(rev(pretty(seq(0,4000,1000))))); axis(4)
	}
	mtext("latitude (degree)",4,1.5)
	if(stat=="count") mtext("number of centers within radius          ",line=1.5)
	else mtext("distance to other centers",line=1.5)
# The first color scale:
	xx = 0.005
	yy = 0.03
	par(plt=c(x1+xx,x1+xx+yy,y1,y2),new=T,mgp=c(1.5,0.5,0))
	colrange = seq(themin,themax,length=100)
	scalecol = matrix(rep(colrange,25),ncol=25)
	if(stat=="count")
	{	
		image(1:25,colrange,t(scalecol),col=rev(heat.colors(nbcol)),ann=F,axes=F,ylim=c(0,countmax),yaxs="r")
		axis(2,pretty(seq(0,tickmax,length=10)))
		rect(1,themax,25,themin)
	}
	else
	{
		image(1:25,colrange,t(scalecol),col=rev(heat.colors(nbcol)),ann=F,axes=F,ylim=c(0,4000))
		axis(2,pretty(seq(1000,3500,500)))
		rect(1,min(4000,themax),25,themin)
	}
# The first distances-longitude graph:
	par(plt=c(x3,x4,y1,y2),new=T,mgp=c(1.5,0.5,0))
	if(stat=="count")
		plot(datamet1950[,2],datamet1950[,1],xlim=xlim,xlab="longitude (degree)",ylab="number of centers within radius",xaxs="i",axes=F,type="n",ylim=c(0,countmax))
	else
		plot(datamet1950[,2],datamet1950[,1],xlim=xlim,xlab="longitude (degree)",ylab="distance to other centers",xaxs="i",yaxs="i",axes=F,type="n",ylim=c(0,4000))
	axis(1); axis(2)
#	points(datamet1950$lon,datamet1950$dist,pch=".")
#	segments(unique(datamet1950$long),confidint1950[,1],unique(datamet1950$long),confidint1950[,2])
	points(met1950$long,statdist1950,col="red")
	bar = centroids[statelist1950,"X"]
	points(bar,statemean1950,pch=19)
	foo = mean(unlist(statemean1950[bar<(-100)]))
	segments(min(bar),foo,max(bar[bar<(-100)]),foo,lty=1,col=rgb(0,0.75,0,1),lwd=2)
	foo = mean(unlist(statemean1950[bar>-100]))
	segments(min(bar[bar>-100]),foo,max(bar),foo,lty=1,col=rgb(0,0.75,0,1),lwd=2)

#	distances = datamet1950[,1]
#	X = datamet1950[,2]
#	regloess = loess(distances~X)
#	u = seq(min(X),max(X),length=100)
#	v = predict(regloess,data.frame(X=u),se=T)
#	vu=c(v$fit+qnorm(1-alpha/2)*v$se.fit,rev(v$fit-qnorm(1-alpha/2)*v$se.fit))
#	polygon(c(u,rev(u))[is.na(vu)==FALSE],vu[is.na(vu)==FALSE],col="light grey",border=FALSE)
#	points(X,phases,pch=".")
#	points(centroids[states,"X"],themeans,pch=20)
#	lmconfint(cbind(X,phases))

# The second distances-longitude graph:
	par(plt=c(x5,x6,y1,y2),new=T,mgp=c(1.5,0.5,0))
	if(stat=="count")
	{
		plot(datamet2000[,2],datamet2000[,1],xlim=xlim,xlab="longitude (degree)",ylab="",xaxs="i",axes=F,type="n",ylim=c(0,countmax))
		mtext("number of centers within radius",4,1.25)
	}
	else
	{
		plot(datamet2000[,2],datamet2000[,1],xlim=xlim,xlab="longitude (degree)",ylab="",xaxs="i",yaxs="i",axes=F,type="n",ylim=c(0,4000))
		mtext("distance to other centers",4,1.25)
	}
	axis(1); axis(4)
#	points(datamet2000$lon,datamet2000$dist,pch=".")
#	segments(unique(data$long),distances[,1],unique(data$long),distances[,2])
	points(met2000$long,statdist2000,col="blue")
	bar = centroids[statelist2000,"X"]
	points(bar,statemean2000,pch=19)
	foo = mean(unlist(statemean2000[bar<(-100)]))
	segments(min(bar),foo,max(bar[bar<(-100)]),foo,lty=1,col=rgb(0,0.75,0,1),lwd=2)
	foo = mean(unlist(statemean2000[bar>-100]))
	segments(min(bar[bar>-100]),foo,max(bar),foo,lty=1,col=rgb(0,0.75,0,1),lwd=2)
# The second color scale:
	xx = 0.005
	yy = 0.03
	par(plt=c(x8-xx-yy,x8-xx,y1,y2),new=T,mgp=c(1.5,0.5,0))
	colrange = seq(themin,themax,length=100)
	scalecol = matrix(rep(colrange,25),ncol=25)
	if(stat=="count")
	{	
		image(1:25,colrange,t(scalecol),col=rev(heat.colors(nbcol)),ann=F,axes=F,ylim=c(0,countmax),yaxs="r")
		axis(4,pretty(seq(0,tickmax,length=10)))
		rect(1,themax,25,themin)
	}
	else
	{
		image(1:25,colrange,t(scalecol),col=rev(heat.colors(nbcol)),ann=F,axes=F,ylim=c(0,4000))
		axis(4,pretty(seq(1000,3500,500)))
		rect(1,min(4000,themax),25,themin)
	}
# Write the subfigure letters:
	par(plt=c(0.0,0.04,0.91,0.96),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(5,5,"A",font=2)
	par(plt=c(0.15,0.2,0.91,0.96),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(5,5,"B",font=2)
	par(plt=c(0.51,0.56,0.91,0.96),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(5,5,"C",font=2)
	par(plt=c(0.78,0.83,0.91,0.96),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(5,5,"D",font=2)
	par(plt=c(0.15,0.2,0.48,0.53),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(5,5,"E",font=2)
	par(plt=c(0.51,0.56,0.48,0.53),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(5,5,"F",font=2)
# Gives the output:
	if(output) list(stat=stat,statdist1950=statdist1950,mv1950=mv1950,statemean1950=statemean1950,statelist1950=statelist1950,statdist2000=statdist2000,mv2000=mv2000,statemean2000=statemean2000,statelist2000=statelist2000)
}
