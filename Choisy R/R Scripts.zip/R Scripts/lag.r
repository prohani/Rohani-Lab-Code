lag = function(data=selectstates(pertussis),from=1951,to=1965,lower=3.5,upper=4.5,mtype="smooth",alpha=0.01,pad=128,method="method2")
{
# Set the values of the time selection if needed:
#	if(missing(from)) from = floor(min(data$time))
#	if(missing(to)) to = ceiling(max(data$time))
	states = unique(data$state)
	nbstates = length(states)
# Time selection:
	sel = unique(data$time)>=from & unique(data$time)<=to
	cases = matrix(data$count,ncol=nbstates)[sel,]
# Calculate and linearly transform the phases for all the states:
	phases = NULL
	if(method=="method1")
		for(i in states)
			phases = cbind(phases,transfphase(waveletfilter(waveletanalysis(i,from,to,data,F,pad=pad),lower,upper)$phase_ts))
	else
	{
		for(i in states)
			phases = cbind(phases,transfphase(waveletfilter(waveletanalysis(i,data=data,plot=F,pad=pad),lower,upper)$phase_ts))
		phases = phases[sel,]
	}
# The time vector:
	thetime = unique(data$time)[sel]
# Take the residual phase angle compared to the mean phase angle for each month:
	phases = phases - apply(phases,1,mean,na.rm=T)
# Calculate the mean phase angle for each state and order states according to them:
	themeans = apply(phases,2,mean,na.rm=T)
	orderedstates = states[order(themeans)]
	cases = cases[,order(themeans)]
# Re-ordering the states by putting first the ones with longitude < -100
# and then the ones with longitude > -100:
	casesrev = cases[,ncol(cases):1]
	X = centroids[orderedstates,"X"]
	cases = cbind(casesrev[,X<(-100)],cases[,X>-100])
	orderedstates = c(orderedstates[X<(-100)],orderedstates[X>-100])
# The graph:
        oplt = par('plt')
        oplt[1] = (1-oplt[2]+oplt[1])/2
        oplt[2] = 1 - oplt[1]
	oplt[1:2] = oplt[1:2]-0.03
        opar = par(plt=oplt,mgp=c(1.5,0.5,0))
	nbtime = length(thetime)
	themin = matrix(rep(apply(cases,2,min),nbtime),nrow=nbtime,byrow=T)
	themax = matrix(rep(apply(cases,2,max),nbtime),nrow=nbtime,byrow=T)
	cases = (cases-themin)/themax
	image(thetime,1:nbstates,cases,xlab="year",ylab="state",col=rev(heat.colors(100)))
# Plot the scale:
	oplt[1] = oplt[2] + 0.01
	oplt[2] = oplt[2] + 0.03
        par(plt=oplt,new=T)
        colrange = seq(0,1,length=100)
        scalecol = matrix(rep(colrange,25),ncol=25)
        image(1:25,colrange,t(scalecol),col=rev(heat.colors(100)),axes=F,ann=F)
        box(); axis(4)
        mtext("relative number of cases",4,1.5)
# Back to the initial graph parameter values:
	par(opar)
# Gives the order of the states as an output:
	orderedstates
}
