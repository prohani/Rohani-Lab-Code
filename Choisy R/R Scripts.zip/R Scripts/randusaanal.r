randusaanal = function(dataset,thresh=100,alpha=0.05)
{
	require(multicore)
	nbcounties = nrow(dataset)
	dataset = data.frame(longitude=dataset[,1],latitude=dataset[,2],state=rep("A",nbcounties))
	distances = distance2(dataset)
	distances = as.data.frame(matrix(distances$dist,nrow=nbcounties-1))
	meandist = unlist(mclapply(distances,mean))
#	medidist = unlist(lapply(distances,median))
#	diamdens = unlist(lapply(distances,function(x)sum(x<thresh)))
#	confiint = lapply(distances,function(x)sort(na.exclude(x)))
#	confiint = lapply(confiint,function(x)
#		x[c(round((alpha/2)*length(x)),round((1-alpha/2)*length(x)))])
#	confiint = matrix(unlist(confiint),byrow=T,ncol=2)
#	list(meandist=meandist,medidist=medidist,diamdens=diamdens,confiint=confiint)
	meandist
}
