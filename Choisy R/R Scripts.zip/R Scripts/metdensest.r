metdensest = function(data=met1950,byx=1,byy=1)
{
	require(maps)
	data = subset(data,!is.element(state,c("Alaska","Puerto Rico","Hawaii")))
	tmp = map("usa",plot=F)
	end = which(is.na(tmp$x))[1]-1
	tmp$x = tmp$x[1:end]
	tmp$y = tmp$y[1:end]
	x = round(tmp$x)
	y = round(tmp$y)
	seqx = seq(min(tmp$x)-byx/2,max(tmp$x)+byx/2,by=byx)
	seqy = seq(min(tmp$y)-byy/2,max(tmp$y)+byy/2,by=byy)
	start = expand.grid(seqx[-length(seqx)],seqy[-length(seqy)])	
	end = expand.grid(seqx[-1],seqy[-1])
	nbcenters = unlist(lapply(1:nrow(start),function(x)
		nrow(subset(data,
			longitude>start[x,1] & longitude<=end[x,1] &
			latitude>start[x,2] & latitude<=end[x,2]))))
	nbcenters = matrix(nbcenters,ncol=length(seqy)-1)
	coord = round(cbind(apply(cbind(start[,1],end[,1]),1,mean),
		apply(cbind(start[,2],end[,2]),1,mean)))
	belongto = NULL
	for(i in 1:nrow(coord))
	{
		yrange = range(y[x==coord[i,1]])
		if(coord[i,2]>=yrange[1] & coord[i,2]<=yrange[2]) belongto = c(belongto,T)
		else belongto = c(belongto,F)
	}
	belongto = matrix(belongto,ncol=length(seqy)-1)
	bylon = apply(nbcenters,1,sum)/apply(belongto,1,sum)
	bylat = apply(nbcenters,2,sum)/apply(belongto,2,sum)
	lonco = unique(apply(cbind(start[,1],end[,1]),1,mean))
	latco = unique(apply(cbind(start[,2],end[,2]),1,mean))
	bylon = cbind(lonco,bylon)
	bylat = cbind(latco,bylat)
	list(bylon=bylon,bylat=bylat,nbcenters=as.vector(nbcenters),coord=coord)
}
