distance2 = function(dataset=met1950)
{
	alpha = 0.05
	require(multicore)
#	require(gam)
	dataset = subset(dataset,!is.element(state,c("Alaska","Puerto Rico","Hawaii")))
	
	distance = function(c1=1,c2=2)
	{
		lon1 = dataset$lon[c1]
		lon2 = dataset$lon[c2]
		lat1 = dataset$lat[c1]
		lat2 = dataset$lat[c2]
		lambda1 = lon1*pi/180
		lambda2 = lon2*pi/180
		delta = lambda1-lambda2
		phi1 = lat1*pi/180
		phi2 = lat2*pi/180
		radius = 6378
		radius*atan(sqrt((cos(phi2)*sin(delta))^2+
			(cos(phi1)*sin(phi2)-sin(phi1)*cos(phi2)*cos(delta))^2)/
			(sin(phi1)*sin(phi2)+cos(phi1)*cos(phi2)*cos(delta)))
	}
	counties = 1:nrow(dataset)
	distancesfrom = function(y) unlist(lapply(counties[-y],function(x)distance(y,x)))
	out = unlist(mclapply(counties,function(x)distancesfrom(x)))
	out = data.frame(distances=out,longitudes=rep(dataset$lon,each=(nrow(dataset)-1)),latitudes=rep(dataset$lat,each=(nrow(dataset)-1)),state=rep(dataset$state,each=(nrow(dataset)-1)))
#	plot(out[,2],out[,1])

#	distances = out[,1]
#	X = out[,2]
#	regloess = loess(distances~X)
#	u = seq(min(X),max(X),length=100)
#	v = predict(regloess,data.frame(X=u),se=T)
#	vu=c(v$fit+qnorm(1-alpha/2)*v$se.fit,rev(v$fit-qnorm(1-alpha/2)*v$se.fit))
#	list(rawdata=out,u=u,vu=vu)

	out
}
