phasedifffig = function(state1="Washington",state2="Colorado",data=pertussis,from=1951,to=1963,lower=3.5,upper=4.5)
{
# Set the values of the time selection if needed:
#	if(missing(from)) from = floor(min(data$time))
#	if(missing(to)) to = ceiling(max(data$time))
# Performing the wavelet decomposition:
#	morlet1 = waveletanalysis(state1,from,to,data,F,lower,upper)
#	morlet2 = waveletanalysis(state2,from,to,data,F,lower,upper)
#	transf1 = morlet1$ys
#	transf2 = morlet2$ys
#	filter1 = morlet1$out2$filtr_ts
#	filter2 = morlet2$out2$filtr_ts
#	phase1 = morlet1$out2$phase_ts
#	phase2 = morlet2$out2$phase_ts	
	morlet1 = waveletanalysis(state1,from,to,data,F)
	transf1 = morlet1$y
	tmp = waveletfilter(morlet1,lower,upper)
	filter1 = tmp$filtr_ts
	phase1 = tmp$phase_ts
	morlet2 = waveletanalysis(state2,from,to,data,F)
	transf2 = morlet2$y
	tmp = waveletfilter(morlet2,lower,upper)
	filter2 = tmp$filtr_ts
	phase2 = tmp$phase_ts
# Drawing the plots:
	layout(matrix(c(0,1:5,0)),heights=c(0.3,rep(1,5),0.7))
#	par(plt=c(0.1,0.89,0.05,0.95),mgp=c(1.5,0.5,0),cex=0.9)
	par(plt=c(0.1,0.85,0.05,0.95),mgp=c(1.5,0.5,0),cex=0.9)
# The time series:
	legend = c(state1,state2)
	state1 = subset(data,state==state1 & time>=from & time<=to)
	state2 = subset(data,state==state2 & time>=from & time<=to)
	plot(state1[,1],state1[,2],type="l",col="blue",ylab="",axes=F,ylim=c(0,max(c(state1[,2],state2[,2]))))
	axis(2); box(); mtext("new cases",2,line=1.5)
	points(state2[,1],state2[,2],type="l",col="red")
	legend("topright",legend,col=c("blue","red"),bty="n",lty=1)
# The transformed data:
	plot(state1[,1],transf1,type="l",col="blue",ylab="",axes=F,ylim=range(c(transf1,transf2)))
	axis(4); box(); mtext("transformed cases",4,line=1.5)
	points(state2[,1],transf2,type="l",col="red")
# The quadriennal component:
	plot(state1[,1],filter1,type="l",col="blue",ylab="",axes=F,ylim=range(c(filter1,filter2)))
	axis(2); box(); mtext("quadriennal component",2,line=1.5)
	points(state2[,1],filter2,type="l",col="red")
# The phases:
	plot(state1[,1],phase1,type="l",col="blue",ylab="",axes=F,ylim=c(-pi,pi))
	axis(4); box(); mtext("phase",4,line=1.5)
	points(state2[,1],phase2,type="l",col="red")
# The phase difference:
	tmp = phasediff(phase2,phase1)
	tmp[which(tmp<(-pi))] = tmp[which(tmp<(-pi))]+2*pi
	tmp[which(tmp>pi)] = tmp[which(tmp>pi)]-2*pi
	plot(state1[,1],tmp,type="l",col="black",ylab="",ylim=c(-pi,pi),lty=3)
	mtext("phase diff.",2,line=1.5); mtext("year",1,line=1.5)
# The histogram of the phase differences:
	par(plt=c(0.85,0.98,0.05,0.95),new=T)
	barplot(hist(tmp,breaks=seq(-pi,pi,length=10),plot=F)$counts,horiz=T)
}
