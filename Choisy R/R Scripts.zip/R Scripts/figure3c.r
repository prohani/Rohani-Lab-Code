figure3c = function(a=dataphaseplot4)
# width = 6.9, height = 5.5
{
	bb = datafig5c
	state1 = "New York"
	state2 = "Colorado"
	from = 1951
	to = 1963
	nbcol = 12
	x1 = 0.07
	x2 = 0.17
	x3 = 0.17
	x4 = 0.5065
	x5 = 0.5065
	x6 = 0.825
	x7 = 0.825
	x8 = 0.925
	y1 = 0.083
	y2 = 0.35
	y3 = 0.35
	y4 = 0.625
	y5 = 0.76
	y6 = 0.97
	xlim = c(-125,-67); ylim = c(25,50)
	ylim2 = c(-2,2)
	b = which(a$states==state1 | a$states==state2)
# The plot of the time series of the 4-year component:
	par(plt=c(x1,x8,y5,y6),mgp=c(1.5,0.5,0))
	times = datafig5a$times
	filtered = datafig5a$filtered
	states = datafig5a$states
	plot(times,filtered[1,],type="l",xlab="year",ylab="quadriennal component",
		col="grey",ylim=range(as.vector(filtered),na.rm=T),axes=F)
	axis(1); axis(2)
	for(i in 2:length(states)) points(times,filtered[i,],type="l",col="grey")
	if(!state1=="") points(times,filtered[which(states==state1),],type="l",col="red")
	if(!state2=="") points(times,filtered[which(states==state2),],type="l",col="blue")
	polygon(c(1951,1963,1963,1951),c(-1.775,-1.775,1.7,1.7),col=rgb(1,0,0,0.1),border=NULL)
	polygon(c(2002,2008,2008,2002),c(-1.775,-1.775,1.7,1.7),col=rgb(0,0,1,0.1),border=NULL)
# The first phase-latitude plot on the left of the first map:
	par(plt=c(x1,x2,y3,y4),new=T,mgp=c(1.5,0.5,0))
	plot(a$phases,a$Y,pch=".",xlim=ylim2,ylim=ylim,xlab="",ylab="latitude (degree)",
		xaxs="i",yaxs="i",axes=F,type="n")
	axis(3,c(-2,-1,0,1,2),paste(c(-2,-1,0,1,2))); axis(2,seq(30,45,5))
	phases0 = as.vector(matrix(a$phases,nrow=length(unique(a$X)))[-b,])
	phases1 = as.vector(matrix(a$phases,nrow=length(unique(a$X)))[b[1],])
	phases2 = as.vector(matrix(a$phases,nrow=length(unique(a$X)))[b[2],])
	Y0 = as.vector(matrix(a$Y,nrow=length(unique(a$X)))[-b,])
	Y1 = as.vector(matrix(a$Y,nrow=length(unique(a$X)))[b[1],])
	Y2 = as.vector(matrix(a$Y,nrow=length(unique(a$X)))[b[2],])
	points(phases0,Y0,pch=".")
	points(phases1,Y1,pch=".",col="blue")
	points(phases2,Y2,pch=".",col="red")
	points(a$themeans[-b],a$centroids[a$states[-b],"Y"],pch=20)
	points(a$themeans[b[1]],a$centroids[a$states[b[1]],"Y"],pch=20,col="blue")
	points(a$themeans[b[2]],a$centroids[a$states[b[2]],"Y"],pch=20,col="red")
	mtext("    residual phase angle (radian)",line=1.5)

	foo = optimize(brokenlm2,c(30,45),dataset=a)
	lmconfint2(cbind(a$phases,a$Y),foo$min)
#	x = a$phases
#	y = a$Y
#	mod = lm(y~x)
#	x = sort(unique(x))
#	prd = predict(mod,data.frame(x=x),int="conf",level=.99)
#	lines(x,prd[,2],lty=2,col="red")
#	lines(x,prd[,3],lty=2,col="red")

# The first map:
	par(plt=c(x3,x4,y3,y4),new=T)
	foo = a$mv
	foo[foo>2]=2
	image(a$x,a$y,foo,col=rev(heat.colors(nbcol)),ann=F,axes=F)
#	image(a$x,a$y,a$mv,col=rev(heat.colors(nbcol)),ann=F,axes=F)
	contour(a$x,a$y,a$mv,add=T)
	polygon(c(a$tmp$x,a$tmp$x[1],a$tmp$x[1],-127,-127,-65,-65,a$tmp$x[1],
		a$tmp$x[1]),c(a$tmp$y,a$tmp$y[1],23,23,60,60,23,23,a$tmp$y[1]),
		col="white",border="white")
	points(a$tmp$x,a$tmp$y,type="l")
	for(i in a$states[-b]) points(a$centroids[i,"X"],a$centroids[i,"Y"],pch=20)
	points(a$centroids[state1,"X"],a$centroids[state1,"Y"],pch=20,col="red")
	points(a$centroids[state2,"X"],a$centroids[state2,"Y"],pch=20,col="blue")
# The second map:
	par(plt=c(x5,x6,y3,y4),new=T)
	foo = bb$mv
	foo[foo>2]=2
	image(bb$x,bb$y,foo,col=rev(heat.colors(nbcol)),ann=F,axes=F)
#	image(bb$x,bb$y,bb$mv,col=rev(heat.colors(nbcol)),ann=F,axes=F)
	contour(bb$x,bb$y,bb$mv,add=T,levels=c(-1.5,-1,0,0.5,1,1.5))
	polygon(c(bb$tmp$x,bb$tmp$x[1],bb$tmp$x[1],-127,-127,-65,-65,bb$tmp$x[1],
		bb$tmp$x[1]),c(bb$tmp$y,bb$tmp$y[1],23,23,60,60,23,23,bb$tmp$y[1]),
		col="white",border="white")
	points(bb$tmp$x,bb$tmp$y,type="l")
	for(i in bb$states[-b]) points(bb$centroids[i,"X"],bb$centroids[i,"Y"],pch=20)
	points(bb$centroids[state1,"X"],bb$centroids[state1,"Y"],pch=20,col="red")
	points(bb$centroids[state2,"X"],bb$centroids[state2,"Y"],pch=20,col="blue")
# The second phase-latitude plot on the right of the second map:
	par(plt=c(x7,x8,y3,y4),new=T,mgp=c(1.5,0.5,0))
	plot(bb$phases,bb$Y,pch=".",xlim=ylim2,ylim=ylim,xlab="",ylab="",
		xaxs="i",yaxs="i",axes=F,type="n")
	axis(3,c(-2,-1,0,1,2),paste(c(-2,-1,0,1,2))); axis(4,seq(30,45,5))
	mtext("latitude (degree)",4,1.5)
	phases0 = as.vector(matrix(bb$phases,nrow=length(unique(bb$X)))[-b,])
	phases1 = as.vector(matrix(bb$phases,nrow=length(unique(bb$X)))[b[1],])
	phases2 = as.vector(matrix(bb$phases,nrow=length(unique(bb$X)))[b[2],])
	Y0 = as.vector(matrix(bb$Y,nrow=length(unique(bb$X)))[-b,])
	Y1 = as.vector(matrix(bb$Y,nrow=length(unique(bb$X)))[b[1],])
	Y2 = as.vector(matrix(bb$Y,nrow=length(unique(bb$X)))[b[2],])
	points(phases0,Y0,pch=".")
	points(phases1,Y1,pch=".",col="blue")
	points(phases2,Y2,pch=".",col="red")
	points(bb$themeans[-b],bb$centroids[bb$states[-b],"Y"],pch=20)
	points(bb$themeans[b[1]],bb$centroids[bb$states[b[1]],"Y"],pch=20,col="blue")
	points(bb$themeans[b[2]],bb$centroids[bb$states[b[2]],"Y"],pch=20,col="red")
	mtext("residual phase angle (radian)   ",line=1.5)

	foo = optimize(brokenlm2,c(30,45),dataset=bb)
	lmconfint2(cbind(bb$phases,bb$Y),foo$min)
#	x = bb$phases
#	y = bb$Y
#	mod = lm(y~x)
#	x = sort(unique(x))
#	prd = predict(mod,data.frame(x=x),int="conf",level=.99)
#	lines(x,prd[,2],lty=2,col="red")
#	lines(x,prd[,3],lty=2,col="red")

# The first color scale:
	xx = 0.005
	yy = 0.03
	par(plt=c(x1+xx,x1+xx+yy,y1,y2),new=T,mgp=c(1.5,0.5,0))
#	colrange = seq(min(a$mv),max(a$mv),length=100)
	themin = min(a$mv)
	colrange = seq(themin,2,length=100)
	scalecol = matrix(rep(colrange,25),ncol=25)
	image(1:25,colrange,t(scalecol),col=rev(heat.colors(nbcol)),
		ylim=ylim2,ann=F,axes=F)
#	axis(2,c(themin,themin+pi/4,themin+pi/2,themin+3*pi/4,themin+pi),
#		c("0","0.5","1","1.5","2"),line=0.2)
	axis(2,c(2,2-pi/4,2-pi/2,2-3*pi/4),
		c("0","0.5","1","1.5"),line=0.2)
	mtext("          lag (year)",2,1.75)
	rect(1,max(colrange[1],ylim2[1]),25,min(colrange[length(colrange)],ylim2[2]))
# The first phase-longitude graph:
	par(plt=c(x3,x4,y1,y2),new=T,mgp=c(1.5,0.5,0))
	plot(a$X,a$phases,pch=".",xlim=xlim,ylim=ylim2,xlab="longitude (degree)",
		ylab="residual phase angle (radian)",xaxs="i",yaxs="i",axes=F,type="n")
	axis(1); axis(2)
	polygon(c(a$u,rev(a$u))[is.na(a$vu)==FALSE],a$vu[is.na(a$vu)==FALSE],
		col="light grey",border=FALSE)
	phases0 = as.vector(matrix(a$phases,nrow=length(unique(a$X)))[-b,])
	phases1 = as.vector(matrix(a$phases,nrow=length(unique(a$X)))[b[1],])
	phases2 = as.vector(matrix(a$phases,nrow=length(unique(a$X)))[b[2],])
	X0 = unique(a$X)[-b]
	X1 = unique(a$X)[b[1]]
	X2 = unique(a$X)[b[2]]
	X0 = rep(X0,12*(to-from))
	X1 = rep(X1,12*(to-from))
	X2 = rep(X2,12*(to-from))
	points(X0,phases0,pch=".")
	points(X1,phases1,pch=".",col="blue")
	points(X2,phases2,pch=".",col="red")
	points(a$centroids[a$states[-b],"X"],a$themeans[-b],pch=20)
	points(a$centroids[a$states[b[1]],"X"],a$themeans[b[1]],pch=20,col="blue")
	points(a$centroids[a$states[b[2]],"X"],a$themeans[b[2]],pch=20,col="red")
	lmconfint(cbind(a$X,a$phases))
# The second phase-longitude graph:
	par(plt=c(x5,x6,y1,y2),new=T,mgp=c(1.5,0.5,0))
	from = 2002
	to = 2008
	plot(bb$X,bb$phases,pch=".",xlim=xlim,ylim=ylim2,xlab="longitude (degree)",
		ylab="",xaxs="i",yaxs="i",axes=F,type="n")
	axis(1); axis(4)
	mtext("residual phase angle (radian)",4,1.25)
	polygon(c(bb$u,rev(bb$u))[is.na(bb$vu)==FALSE],bb$vu[is.na(bb$vu)==FALSE],
		col="light grey",border=FALSE)
	phases0 = as.vector(matrix(bb$phases,nrow=length(unique(bb$X)))[-b,])
	phases1 = as.vector(matrix(bb$phases,nrow=length(unique(bb$X)))[b[1],])
	phases2 = as.vector(matrix(bb$phases,nrow=length(unique(bb$X)))[b[2],])
	X0 = unique(bb$X)[-b]
	X1 = unique(bb$X)[b[1]]
	X2 = unique(bb$X)[b[2]]
	X0 = rep(X0,12*(to-from))
	X1 = rep(X1,12*(to-from))
	X2 = rep(X2,12*(to-from))
	points(X0,phases0,pch=".")
	points(X1,phases1,pch=".",col="blue")
	points(X2,phases2,pch=".",col="red")
	points(bb$centroids[bb$states[-b],"X"],bb$themeans[-b],pch=20)
	points(bb$centroids[bb$states[b[1]],"X"],bb$themeans[b[1]],pch=20,col="blue")
	points(bb$centroids[bb$states[b[2]],"X"],bb$themeans[b[2]],pch=20,col="red")
	lmconfint(cbind(bb$X,bb$phases))
# The second color scale:
	xx = 0.005
	yy = 0.03
	par(plt=c(x8-xx-yy,x8-xx,y1,y2),new=T,mgp=c(1.5,0.5,0))
	themin = min(bb$mv)
#	colrange = seq(themin,max(bb$mv),length=100)
	colrange = seq(themin,2,length=100)
	scalecol = matrix(rep(colrange,25),ncol=25)
	image(1:25,colrange,t(scalecol),col=rev(heat.colors(nbcol)),
		ylim=ylim2,ann=F,axes=F)
#	axis(4,c(themin,themin+pi/4,themin+pi/2,themin+3*pi/4,themin+pi),
#		c("0","0.5","1","1.5","2"),line=0.2)
	axis(4,c(2,2-pi/4,2-pi/2,2-3*pi/4,2-pi),
		c("0","0.5","1","1.5","2"),line=0.2)
	mtext("    lag (year)",4,1.75)
	rect(1,max(colrange[1],ylim2[1]),25,min(colrange[length(colrange)],ylim2[2]))
# Write the subfigure letters:
	par(plt=c(0.03,0.08,0.94,0.99),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(5,8,"A",font=2)
	par(plt=c(0.03,0.08,0.62,0.67),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(5,5,"B",font=2)
	par(plt=c(0.17,0.22,0.62,0.67),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(5,5,"C",font=2)
	par(plt=c(0.5065,0.5565,0.62,0.67),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(5,5,"D",font=2)
	par(plt=c(0.92,0.97,0.62,0.67),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(5,5,"E",font=2)
	par(plt=c(0.17,0.22,0.34,0.39),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(5,5,"F",font=2)
	par(plt=c(0.5065,0.5565,0.34,0.39),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(5,5,"G",font=2)
}
