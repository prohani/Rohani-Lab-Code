phaseplot1 = function(state="New York",data=pertussis,from=1951,to=1963,lower=3.5,upper=4.5,pad=128,method="method1")
# As for the filteredplot, there are two way of doing it: either we do the filtering only on the specified
# time period (method 1) or we do the filtering over the all time period and then select the time period
# we are interested in (method 2).
{
# Set the values of the time selection if needed:
#	if(missing(from)) from = floor(min(data$time))
#	if(missing(to)) to = ceiling(max(data$time))
	phases = NULL
	states = unique(selectstates(data)$state)
# The first method: we filter only on the specified time period:
	if(method=="method1")
		for(i in states)
		{
			tmp = waveletanalysis(i,from,to,data,F,pad=pad)
			phases = rbind(phases,waveletfilter(tmp,lower,upper)$phase_ts)
		}
# The second method: we first filter and then select the specified time period:
	else
	{
		for(i in states)
		{
			tmp = waveletanalysis(i,data=data,plot=F,pad=pad)
			phases = rbind(phases,waveletfilter(tmp,lower,upper)$phase_ts)
		}
# Note that the 
		phases = phases[,unique(data$time)>=from & unique(data$time)<=to]
#		for(i in states)
#			phases = rbind(phases,waveletfilter(waveletanalysis(i,from,to,data,F),lower,upper)$phase_ts)
	}
# The time vector:
	times = unique(subset(data,time>=from & time<=to)$time)
	par(mgp=c(1.5,0.5,0))
	plot(times,phases[1,],type="l",xlab="year",ylab="phase angle (radians)",col="grey")
	for(i in 2:length(states)) points(times,phases[i,],type="l",col="grey")
	points(times,phases[which(states==state),],type="l",col="red")
	points(times,phases[which(states=="Colorado"),],type="l",col="blue")
}
