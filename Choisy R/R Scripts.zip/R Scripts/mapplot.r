mapplot = function(data=selectstates(pertussis))
{
	thestates = unique(data$state)
	require(maps)
	map("usa")
	for(i in thestates) points(centroids[i,"X"],centroids[i,"Y"])
}
