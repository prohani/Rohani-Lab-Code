waveletoutput = function(object,lowPF,upPF)
# Computation of different "outputs" based on the Wavelet transform of the signal y
#
#----------- INPUTS
# wave		: wavelet transform computed by 'WaveletTransform'
# scale	: vector of the wavelet scale employed during the computation 
# y		: THE TIME SERIES
# variance	: variance of y
# dt		: observation time step
# dj		: frequency resolution (ie number of sub-octaves)
# lowerPF	: lower value of the period used for filtering some of the output
#			(filtr_ts, filtr_var, phase_ts)
# upperPF	: upper value of the period used for filtering some of the output
#			(filtr_ts, filtr_var, phase_ts)
#
#----------- OUTPUT
# power	: power wavelet spectrum
# realwav	: real part of the wavelet transform (ie the modulus)
# imagwav	: imaginary part of the wavelet transform
# global_ws	: average power wavelet spectrum
# filtr_ts	: filtered time series (the reconstructed serie) based on the components
#			which are between lowerPF and upperPF periods
# filtr_var	: average variance of the components between lowerPF and upperPF periods
# phase_ts	: filtered phase series between lowerPF and upperPF periods
{
# Reconstruction factor from table 2. Alternatively, it could also be calculated from
# equations 12 and 13:
	Cdelta = 0.776
# Retrieving the usefuul parameters from object object:
	n = length(object$y)
	variance = var(object$y)
	wave = object$wave
	scale = object$scale
	dt = object$dt
	dj = object$dj
# Selecting the scale range:
	avg = which(scale>=lowPF/object$fourier_factor & scale<upPF/object$fourier_factor)
# The wavelet power spectrum:
# Essayer avec Mod.
#	power   = abs(wave)^2
	power   = Mod(wave)^2
# The wavelet real part:
	realwav = Re(wave)
# The wavelet imaginary part:
	imagwav = Im(wave)
# Global wavelet spectrum (i.e. time-average over all times):
	global_ws = variance*apply(power,1,mean)
# Filtered time series (equation 11):
	tmp = realwav/sqrt(scale)%*%t(rep(1,n))
	filtr_ts = pi^(1/4)*dj*sqrt(dt)/Cdelta*apply(tmp[avg,],2,sum)
# Filtered variance:
	tmp = power/scale%*%t(rep(1,n))
	filtr_var = variance*dj*dt/Cdelta*apply(tmp[avg,],2,sum)
# Filtered phase:
# Essayer avec Arg:
#	tmp = atan2(imagwav,realwav)
	tmp = Arg(power)
	phase_ts = apply(tmp[avg,],2,mean)
# Give the output:
	list(power=power,realwav=realwav,imagwav=imagwav,global_ws=global_ws,
		filtr_ts=filtr_ts,filtr_var=filtr_var,phase_ts=phase_ts)
}
