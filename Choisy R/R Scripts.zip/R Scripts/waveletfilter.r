waveletfilter = function(object,lowPF,upPF)
# Computation of different "outputs" based on the Wavelet transform of the signal y
#
#----------- INPUTS
# lowerPF	: lower value of the period used for filtering some of the output
#			(filtr_ts, filtr_var, phase_ts)
# upperPF	: upper value of the period used for filtering some of the output
#			(filtr_ts, filtr_var, phase_ts)
#
#----------- OUTPUT
# filtr_ts	: filtered time series (the reconstructed serie) based on the components
#			which are between lowerPF and upperPF periods
# filtr_var	: average variance of the components between lowerPF and upperPF periods
# phase_ts	: filtered phase series between lowerPF and upperPF periods
{
# Reconstruction factor from table 2. Alternatively, it could also be calculated from
# equations 12 and 13:
	Cdelta = 0.776
# Retrieving the useful parameters from object object:
	n = length(object$y)
	scale = object$scale
	wave = object$wave
	dt = object$dt
	dj = object$dj
# Selecting the scale range:
	avg = which(scale>=lowPF/object$fourier_factor & scale<upPF/object$fourier_factor)
# The wavelet power spectrum:
	power = wavepower(object)
# Filtered time series (equation 11):
	tmp = Re(wave)/sqrt(scale)%*%t(rep(1,n))
	filtr_ts = pi^(1/4)*dj*sqrt(dt)/Cdelta*apply(tmp[avg,],2,sum)
# Filtered variance:
	tmp = power/scale%*%t(rep(1,n))
	filtr_var = var(object$y)*dj*dt/Cdelta*apply(tmp[avg,],2,sum)
# Filtered phase:
	tmp = Arg(wave)
	phase_ts = apply(tmp[avg,],2,mean)
# Give the output:
	list(filtr_ts=filtr_ts,filtr_var=filtr_var,phase_ts=phase_ts)
}
