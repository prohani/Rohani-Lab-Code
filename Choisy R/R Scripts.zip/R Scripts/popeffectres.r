popeffectres = function(data=pertussis,from=1951,to=1963,lower=3.5,upper=4.5,thresh=-100,angle=0.1317029,alpha=0.01,rotate=F)
{
# Set the values of the time selection if needed:
#	if(missing(from)) from = floor(min(data$time))
#	if(missing(to)) to = ceiling(max(data$time))
# Calculating the phases:
	phases = NULL
	states = unique(selectstates(data)$state)
	for(i in states)
		phases = cbind(phases,
			transfphase(waveletfilter(waveletanalysis(i,from,to,data,F),lower,upper)$phase_ts))
# Making the time vector:
	times = unique(subset(data,time>=from & time<=to)$time)
# Transforming the phase angles:
	phases = as.vector(t(phases-apply(phases,1,mean,na.rm=T)))
# Extracting the longitudes and latitudes:
	X = rep(centroids[states,"X"],length(times))
	Y = rep(centroids[states,"Y"],length(times))
# Making the population size vector:
	size = popsize[is.element(popsize$state,states) & is.element(popsize$year,trunc(times)),"size"]
	size = matrix(size,nrow=49)
	nbrep = table(trunc(times))
	tmp = NULL
	for(i in 1:length(nbrep)) tmp=c(tmp,rep(size[,i],nbrep[i]))
	size = tmp
# Getting rid off the NA values in the phases:
	tmp = na.exclude(cbind(X,Y,phases,size))
	X = tmp[,1]
	Y = tmp[,2]
	phases = tmp[,3]
	size = tmp[,4]
# We cut the dataset in two datasets:
# below the threshold:
	X1 = X[X<=thresh]
	Y1 = Y[X<=thresh]
	phases1 = phases[X<=thresh]
	size1 = size[X<=thresh]
# above the threshold:
	X2 = X[X>thresh]
	Y2 = Y[X>thresh]
	phases2 = phases[X>thresh]
	size2 = size[X>thresh]
# From here, we can do 2 alternative analyses:
	if(rotate)
	{
		X1r = X1*cos(angle) + Y1*sin(angle)
		X2r = X2*cos(angle) + Y2*sin(angle)
		mod1 = lm(phases1~X1r)
		mod2 = lm(phases2~X2r)
	}
	else
	{
# Linear regression with longitude, latitude and interaction:
		mod1 = lm(phases1~X1*Y1)
		mod2 = lm(phases2~X2*Y2)
	}
# We take the residuals:
	res = c(residuals(mod1),residuals(mod2))
	size = c(size1,size2)
	x = size = log(size)
	par(mgp=c(1.5,0.5,0),xlog=F)
	plot(size,res,xlab="log(population size)",ylab="residual phase angle (radian)",ylim=c(-2,2))
# The linear regression:
	mod = lm(phases~size)
	x = sort(unique(size))
	prd = predict(mod,data.frame(size=x),int="conf",level=1-alpha)
	lines(x,prd[,2],col="red")
	lines(x,prd[,3],col="red")
	mtext('residuals of the',2,2.5)

	mod1A = lm(phases1~X1*Y1)
	mod1B = lm(phases1~X1*Y1+log(size1))
	mod2A = lm(phases2~X2*Y2)
	mod2B = lm(phases2~X2*Y2+log(size2))
	list(mod1A,mod1B,mod2A,mod2B,mod)
}
