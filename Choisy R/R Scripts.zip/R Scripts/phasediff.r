phasediff = function(phase1,phase2)
{
# The following function transforms the phase time series into a monotonally increasing one,
# accounting for the irregularities in the phase time series:
	transf = function(phase)
	{
		A = which(diff(phase)<0)
		B = which(diff(A)==1)
		phase[A[B]+1] = NA
		A = which(phase<0)
		B = which(diff(A)>1)
		breaks = A[c(0,B)+1]
		breaks = breaks[breaks>1]
		end = length(phase)
		for(i in breaks) phase[i:end] = phase[i:end]+2*pi
		phase
	}
# Gives the time series of phase differences:
	transf(phase1)-transf(phase2)
}
