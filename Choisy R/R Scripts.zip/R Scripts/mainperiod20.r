mainperiod20 = function(start=1955,scaled=T,data=selectstates(pertussis))
{
	x11(width=7,height=10.5)
	par(mfrow=c(4,5),plt=c(0.27,0.93,0.2,0.9),mgp=c(1.5,0.5,0),cex=1/0.95)
	for(i in start:(start+19))
	{
		mainperiod1(last=i,scaled=scaled,data=data,titlerange=F)
		mtext(paste(i),line=0.2)
	}
}
