corrdistangleX = function(before=T,data=selectstates(pertussis))
# This function plots the spatial correlation function for one time period using Sncf.
{
	require(ncf)
	require(plotrix)
	if(is.data.frame(data))
	{
		states = unique(data$state)
		coord = centroids[states,]
		X = coord$X
		Y = coord$Y
		angles = seq(0,2*pi,length=100)
		angles2 = 180*(pi/2-angles)/pi
		if(before) themids = 1955:2008 else themids = 1951:2003
		x = y = vector("list",length(themids))
		ind = 0
		maxthemax = 0
		for(mid in themids)
		{
			show(mid)
			ind = ind+1
			if(before) datatmp = subset(data,time<mid)
	                else datatmp = subset(data,time>=mid)
			datatmp = t(matrix(datatmp$count,ncol=length(states)))
			out = Sncf2D(X,Y,datatmp,resamp=0,quiet=T,angle=angles2)
			themax = NULL
			for(i in 1:length(angles)) themax = c(themax,max(out$real[[i]]$predicted$y,na.rm=T))
			x[[ind]] = themax*cos(angles)
			y[[ind]] = themax*sin(angles)
			maxthemax = max(c(maxthemax,themax))
		}
	}
	else
	{
		before = data$before
		maxthemax = data$maxthemax
		x = data$x
		y = data$y
		themids = data$themids
	}
	if(before) color="red" else color="blue"
	par(pty="s",las=1,mar=rep(2,4))
	corrmax = ceiling(10*maxthemax)/10
	corrlim = c(-corrmax,corrmax)
	thecircles = seq(0.1,corrmax,0.1)
	plot(x[[1]],y[[1]],xlim=corrlim,ylim=corrlim,axes=F,ann=F,type="l",col=color)
	for(i in 2:length(themids)) points(x[[i]],y[[i]],type="l",col=color)
	abline(h=0)
	abline(v=0)
	for(i in thecircles) draw.circle(0,0,i,lty=2)
	mtext("S",1); mtext("W",2); mtext("N",3); mtext("E",4)
	if(is.data.frame(data)) list(themids=themids,before=before,maxthemax=maxthemax,x=x,y=y)
}
