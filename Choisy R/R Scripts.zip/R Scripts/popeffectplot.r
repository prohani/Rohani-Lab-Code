popeffectplot = function(object)
{
	size = object$size
	phases = object$phases
	x = object$x
	prd = object$prd
# Drawing the figure:
	par(mgp=c(1.5,0.5,0),xlog=F)
	plot(size,phases,xlab="log(population size)",ylab="residual phase angle (radian)",ylim=c(-2,2))
# The linear regression:
	lines(x,prd[,2],col="red")
	lines(x,prd[,3],col="red")
}
