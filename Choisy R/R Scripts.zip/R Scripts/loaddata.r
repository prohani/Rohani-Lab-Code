loaddata = function(data='pertussis.dat',cut=10)
# The original data should be a text file with 4 columns separated
# by tabulations. The first line should contain the names of each
# column: year, month, count, and state. Some month values are "99".
# They are discarded. For some years of some states, some month lines
# are missing. These are interpreted as 0 notification.
{
# Load the data from local directory:
	#data = read.table(data,sep='\t',header=T)
	data = read.table('pertussis.dat',sep='\t',header=T)
# Get rid off the "99" in the "month" column:	
#	data = data[data$month<13,]
	data = subset(data,month<13)
# Count the number of 0 notifications:
	cat(paste("There is", sum(data$count==0),"'0' notifications out of a total of",nrow(data),"\n"))
# This graph shows the number of missing values (increasing from white to red),
# by month (columns) and state (rows):
	
}
x11(width=7,height=7); par(mgp=c(1.5,0.5,0),mfrow=c(2,2),cex=1/0.83,plt=c(0.15,0.9,0.15,0.8))
	image(table(data[,c(2,4)]),main="number of missing values",xlab="months",ylab="states")
	image(table(data[,c(1,4)]),main="number of missing values",xlab="years",ylab="states")
	nbyears = diff(range(data[,1]))+1
	ts.plot(as.matrix(1-table(data[,c(2,4)])/nbyears),xlab="months",ylab="proportion of missing values",
		main="missing values for each state")
# Make the data with time as a real number instead of year and month:
	time = data$year+(data$month-0.5)/12
	data = cbind(time,data[,3:4])
# Add the missing values as 0 notification:
	tmp = data.frame(table(data[,c(1,3)]))
	tmp = tmp[tmp[,3]==0,]
	tmp = data.frame(cbind(
		as.character(tmp[,1]),
		rep(0,nrow(tmp)),
		as.character(tmp[,2])))
	names(tmp) = names(data)
	data = rbind(data,tmp)
# Give each column of the dataframe data the good format:
	data$time = as.numeric(data$time)
	data$count = as.integer(data$count)
	data$state = as.character(data$state)
# Re-order the data frame chronologically for each state:
	data = data[order(data$time),]
	data = data[order(data$state),]
# Re-initilize the row names of the data frame:	
# Test what explains the presence of missing values:
	nbstates = length(unique(data$state))
	years = as.factor(rep(rep(trunc(min(data$time)):trunc(max(data$time)),each=12),nbstates))
	months = as.factor(rep(1:12,nbstates*nbyears))
	missing = as.factor(data$count>0)
#	print(anova(glm(missing~years+as.factor(data$state)+months,binomial),test="Chi"))
# Look at the values before and after 0 notifications:	
	tmp = as.data.frame(matrix(data$count,ncol=length(unique(data$state))))
	tmp = c(as.vector(unlist(lapply(tmp,function(x)x[which(x==0)-1]))),
		as.vector(unlist(lapply(tmp,function(x)x[which(x==0)+1]))))
# Draw the histogram:
	data1 = table(tmp)
	data2 = table(data$count)
	foo = cbind(data1["1"],data2["1"])
	data1[paste(0:1)] = 0
	data2[paste(0:1)] = 0
	foo = rbind(foo,c(sum(data1),sum(data2)))
	show(fisher.test(foo))
	barplot(yyy,beside=T,col=c("red","blue"),names.arg=c("neighbor to 1","neighbor to value >1"),ylab="counts",
		main="proximity of missing values to 1")
	legend("topleft",c("missing value","non-missing value"),fill=c("red","blue"),bty="n")
# Count the number of missing values:
	cat(paste("There were", sum(data$count==0),"missing values out of a total of",nrow(data),"\n"))
# Give the dataframe as an output:
	data