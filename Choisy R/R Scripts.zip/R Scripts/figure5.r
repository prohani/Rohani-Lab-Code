figure5 = function()
{
# width=5.5, height=4.25
	y1 = 0.11
	y2 = 0.47
	x1 = 0.11
# Upper panel:
	opar = par(plt=c(x1,0.97,0.625,0.97),mgp=c(1.5,0.5,0))
	times = datafig5a$times
	filtered = datafig5a$filtered
	states = datafig5a$states
	state1 = datafig5a$state1
	state2 = datafig5a$state2
	plot(times,filtered[1,],type="l",xlab="year",ylab="quadriennal component",col="grey",ylim=range(as.vector(filtered),na.rm=T))
	for(i in 2:length(states)) points(times,filtered[i,],type="l",col="grey")
	if(!state1=="") points(times,filtered[which(states==state1),],type="l",col="red")
	if(!state2=="") points(times,filtered[which(states==state2),],type="l",col="blue")

	polygon(c(1951,1963,1963,1951),c(-2,-2,2,2),col=rgb(0,0,1,0.1),border=NA)
	polygon(c(2002,2008,2008,2002),c(-2,-2,2,2),col=rgb(1,0,0,0.1),border=NA)
# Second graph:
	par(plt=c(x1,0.49,y1,y2),new=T,mgp=c(1.5,0.5,0))
	a = dataphaseplot4
	xlim = c(-125,-67)
	from = 1951
	to = 1963
	b = which(a$states==state1 | a$states==state2)
	ylim2 = c(-2,2)
	plot(a$X,a$phases,pch=".",xlim=xlim,ylim=ylim2,xlab="longitude (degree)",
		ylab="residual phase angle (radian)",xaxs="i",yaxs="i",axes=F,type="n")
	axis(1); axis(2)
	polygon(c(a$u,rev(a$u))[is.na(a$vu)==FALSE],a$vu[is.na(a$vu)==FALSE],col="light grey",border=FALSE)
	X0 = unique(a$X)[-b]
	X1 = unique(a$X)[b[1]]
	X2 = unique(a$X)[b[2]]
	X0 = rep(X0,12*(to-from))
	X1 = rep(X1,12*(to-from))
	X2 = rep(X2,12*(to-from))
	phases0 = as.vector(matrix(a$phases,nrow=length(unique(a$X)))[-b,])
	phases1 = as.vector(matrix(a$phases,nrow=length(unique(a$X)))[b[1],])
	phases2 = as.vector(matrix(a$phases,nrow=length(unique(a$X)))[b[2],])
	points(X0,phases0,pch=".")
	points(X1,phases1,pch=".",col="blue")
	points(X2,phases2,pch=".",col="red")
	points(a$centroids[a$states[-b],"X"],a$themeans[-b],pch=20)
	points(a$centroids[a$states[b[1]],"X"],a$themeans[b[1]],pch=20,col="blue")
	points(a$centroids[a$states[b[2]],"X"],a$themeans[b[2]],pch=20,col="red")
	lmconfint(cbind(a$X,a$phases))
# Third graph:
	par(plt=c(0.61,0.99,y1,y2),new=T,mgp=c(1.5,0.5,0))
	a = datafig5c
	xlim = c(-125,-67)
	from = 2002
	to = 2008
	b = which(a$states==state1 | a$states==state2)
	ylim2 = c(-2,2)
	plot(a$X,a$phases,pch=".",xlim=xlim,ylim=ylim2,xlab="longitude (degree)",
		ylab="residual phase angle (radian)",xaxs="i",yaxs="i",axes=F,type="n")
	axis(1); axis(2)
	polygon(c(a$u,rev(a$u))[is.na(a$vu)==FALSE],a$vu[is.na(a$vu)==FALSE],col="light grey",border=FALSE)
	X0 = unique(a$X)[-b]
	X1 = unique(a$X)[b[1]]
	X2 = unique(a$X)[b[2]]
	X0 = rep(X0,12*(to-from))
	X1 = rep(X1,12*(to-from))
	X2 = rep(X2,12*(to-from))
	phases0 = as.vector(matrix(a$phases,nrow=length(unique(a$X)))[-b,])
	phases1 = as.vector(matrix(a$phases,nrow=length(unique(a$X)))[b[1],])
	phases2 = as.vector(matrix(a$phases,nrow=length(unique(a$X)))[b[2],])
	points(X0,phases0,pch=".")
	points(X1,phases1,pch=".",col="blue")
	points(X2,phases2,pch=".",col="red")
	points(a$centroids[a$states[-b],"X"],a$themeans[-b],pch=20)
	points(a$centroids[a$states[b[1]],"X"],a$themeans[b[1]],pch=20,col="blue")
	points(a$centroids[a$states[b[2]],"X"],a$themeans[b[2]],pch=20,col="red")
	lmconfint(cbind(a$X,a$phases))
# Write the subfigure letters:
	par(plt=c(0.0,0.05,0.93,0.98),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(5,8,"A",font=2)
	par(plt=c(0.0,0.05,y2-0.04,y2+0.01),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(5,8,"B",font=2)
	par(plt=c(0.5,0.55,y2-0.04,y2+0.01),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(5,8,"C",font=2)
# Back to the initial graph parameters:
	par(opar)
}
