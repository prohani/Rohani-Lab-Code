loadnewdata2 = function()
# This function loads the weekly cases on the 2003-2007 period, using a simpler
# method than the loadnewdata function.
{
	a = read.table('newdata0307.dat',sep='\t')
	names(a) = c("year","week","count","state")
	months = seq(2003,2008,1/12)
	data = NULL
	thestates = unique(a$state)
	for(thestate in thestates)
	{
		b = subset(a,state==thestate)
		time = b$year+b$week/53
		newcounts = NULL
		for(i in 1:(5*12))
			newcounts = c(newcounts,sum(b$count[time>months[i] & time<=months[i+1]]))
		data = rbind(data,cbind(months[-length(months)],newcounts))
	}
# Make it a data frame and give it the correct column names:
	data = data.frame(time=data[,1],count=data[,2],state=rep(thestates,each=5*12))
# Give each column of the dataframe data the good format:
#	data$time = as.numeric(data$time)
	data$count = as.integer(data$count)
	data$state = as.character(data$state)
# Re-order the data frame chronologically for each state:
	data = data[order(data$time),]
	data = data[order(data$state),]
# Re-initilize the row names of the data frame: 
	rownames(data) = as.character(1:nrow(data))
# Give the output:
	data
}
