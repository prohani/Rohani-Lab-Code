wavelettestnoise = function(y,lag,dt,dj,scale,lowPF,upPF,pvalue=0.05,fourier_factor)
# This function gives the p-values by comparing the signal y to a white (lag=0) or
# a red (lag=1) noise that has the same autocorrelation structure. This is base on the
# original function (see in particular the calculation of the AR1 coefficient).
# The new version is wavelettestnoise2 and it the one that should be used. The difference
# wavelettestnoise2 is that this function gives the p-value for a filtered version of the
# signal over a specific band (between lowPF and upPF).
#------------ INPUTS
# y		: input time series
# lag		: lag!=0 for a test with a red noise, the AR(1) parameter will be computed
# dt		: observation time step
# dj		: frequency resolution (ie number of sub-octaves)
# scale		: vector of the wavelet scale employed during the computation
# lowP		: lower period of the decomposition
# upP		: upper period of the decomposition
#
#------------ OUTPUT
# pv_scalog	: matrice of the p-values of the power wavelet at the level at the pvalue level.
# pv_spec	: pvalue significance level for the average wavelet spectrum of y.
# pv_var	: pvalue significance level for the average variance of y.
{
	n = length(y)
	var_y = var(y)
	ns = length(scale)-1
	alpha = 1-pvalue
# In case of red noise, we calculate the coefficient of the AR(1) process (equation 15).
# (Note the possibility of using a AR(2) with p=2 and X2=y(p+1-1:n-2); X=[X1 X2]).
	if(lag!=0)
	{
		p = 1
		Y = y[(p+1):n]
		X1 = y[(p+1-1):(n-1)]
		X = X1
		par = solve(t(X)%*%X)%*%t(X)%*%Y
		lag = par[1]
	}
	period = scale*fourier_factor
# Degrees of freedom with no smoothing:
	dof = 2
	dofmin = dof
# Reconstruction factor:
	Cdelta = 0.776
# Time-decorrelation factor:
	gamma_fac = 2.32
# Scale-decorrelation factor:
	dj0 = 0.6
# Normalized frequency:
	freq = dt/period
# Calculating the theoretical FFT (equation 16):
# Note that this spectrum has been normalized by N/(2*var_y). This means that this
# spectrum can be compared only to a power which has also been normalized.
	fft_theor = (1-lag^2)/(1-2*lag*cos(freq*2*pi)+lag^2)
# Normalization:
#	fft_theor = var_y*fft_theor @@@@@ Je pense que cette ligne est inutile.
# From equation 18:
	pv_scalog = fft_theor*qchisq(alpha,dof)/dof
# significance level associated to the time-averaged spectrum (section 5a)
	dof = n - scale
	dof[dof<1] = 1
# Equation 23:
	dof = dofmin*sqrt(1+(dof*dt/gamma_fac/scale)^2)
	dof[dof<dofmin] = dofmin
	pv_spec = fft_theor*qchisq(alpha,dof)/dof
# significance level associated to the time-averaged variance in a defined band
	pv_var = NA
	if(!is.na(lowPF) & !is.na(lowPF))
	{
		dof = 2
		avg = which(scale>=lowPF & scale<upPF)
		navg = length(avg)
		if(navg == 0) stop(paste('No valid scales between',lowPF,'and',upPF))
# Equation 25:
		Savg = 1/sum(1/scale[avg])
# Equation 28:
		Smid = exp((log(lowPF)+log(upPF))/2)
		dof = (dofmin*navg*Savg/Smid)*sqrt(1+(navg*dj/dj0)^2)
# Equation 27:
		fft_theor = Savg*sum(fft_theor[avg]/scale[avg])
# Equation 26:
		pv_var = (dj*dt/Cdelta/Savg)*fft_theor*qchisq(alpha,dof)/dof
	}
# Gives the output:
	list(pv_scalog=pv_scalog,pv_spec=pv_spec,pv_var=pv_var)
}
