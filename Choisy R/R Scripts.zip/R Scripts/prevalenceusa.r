prevalenceusa = function(pop=selectstates(popsize),data=selectstates(pertussis))
# This function calculates the prevalence of the USA as a whole.
{
	themin = round(min(data$time))
	themax = trunc(max(data$time))
	pop = subset(pop,year>=themin & year<=themax)
	pop = pop[order(pop$year),]
	pop = tapply(pop$size,pop$year,sum)
	data = data[order(data$time),]
	prev = tapply(data$count,data$time,sum)
	prev = prev/rep(pop,each=12)
	data.frame(time = unique(data$time),prev)
}
