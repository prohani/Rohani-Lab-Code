corrdistance1 = function(from=1951,to=2008,data=selectstates(pertussis),out=datacorrdistance1)
# This function plots the spatial correlation function for one time period using Sncf.
{
	require(ncf)
	showdata=F
	if(is.null(out))
	{
		showdata=T
# Set the values of the time selection if needed:
#		if(missing(from)) from = floor(min(data$time))
#		if(missing(to)) to = ceiling(max(data$time))
# Select the time range:
		data = subset(data,time>=from & time<to)
# Calculate the spatial correlation:
		states = unique(data$state)
		coord = centroids[states,]
		data = t(matrix(data$count,ncol=length(states)))
		out = Sncf(coord$X,coord$Y,data,latlon=T,quiet=F,resamp=1000)
	}
# Drawing the graph:
	par(mgp=c(1.5,0.5,0))
	plot(out$real$predicted$x,out$real$predicted$y,type="n",ylim=c(0,0.7),
		col="black",xlab="distance (km)",ylab="correlation",axes=T)
#	axis(1); axis(2)
	x = out$boot$boot.summary$predicted$x
	yl = out$boot$boot.summary$predicted$y["0.025",]
	yu = out$boot$boot.summary$predicted$y["0.975",]
#	polygon(c(x,rev(x)),c(yl,rev(yu)),col=rgb(0,0,1,0.1),border=NA)
	polygon(c(x,rev(x)),c(yl,rev(yu)),col="light grey",border=NA)
	points(out$real$predicted$x,out$real$predicted$y,type="l")
	lines(x,yl,lty=2,col="black")
	lines(x,yu,lty=2,col="black")
	abline(h=out$real$cbar)
# Giving the output:
	if(showdata) out
}
