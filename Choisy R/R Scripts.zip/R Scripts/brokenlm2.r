brokenlm2 = function(thresh=40,dataset=dataphaseplot4)
{
	data = cbind(dataset$Y,dataset$phases)
# We cut the dataset in two datasets:
# below the threshold:
	x1 = data[data[,1]<=thresh,1]
	y1 = data[data[,1]<=thresh,2]
# above the threshold:
	x2 = data[data[,1]>thresh,1]
	y2 = data[data[,1]>thresh,2]
# We do the two linear models:
	mod1 = lm(y1~x1)
	mod2 = lm(y2~x2)
# We output the total deviance of the model:
	deviance(mod1)+deviance(mod2)
}
