statdensmap = function(a=datastatdensmap)
# width = 6.9, height = 4
{
	require(maps)
	nbcol = 12
	t1 = 0.01
	t2 = 0.01
	x1 = 0.07-t1
	x2 = 0.17-t1
	x3 = 0.17-t1
	x4 = 0.5065-t1
	x5 = 0.5065+t2
	x6 = 0.825+t2
	x7 = 0.825+t2
	x8 = 0.925+t2
	y1 = 0.114125
	y2 = 0.48125
	y3 = 0.51125
	y4 = 0.889375
	xlim = c(-125,-67); ylim = c(25,50)

	tmp = map("usa",plot=F)
	end = which(is.na(tmp$x))[1]-1
	tmp$x = tmp$x[1:end]
	tmp$y = tmp$y[1:end]

	lwidth = 300
	lheight = 200
	x = seq(-125,-67,length=lwidth)
	x = seq(-125,-67,length=lwidth)
	y = seq(25,50,length=lheight)
	y = seq(25,50,length=lheight)
	xv = rep(x,lheight)
	yv = rep(y,each=lwidth)

	require(gam)
	
	statearea = subset(statearea,!is.element(state,c("Alaska","Puerto Rico","Hawaii","District of Columbia")))
	statenames = sort(statearea$state)
	statearea = statearea[order(statearea$state),"area"]
	popsize1950 = subset(popsize,year==1950 & !is.element(state,c("Alaska","Puerto Rico","Hawaii","District of Columbia")))
	popsize1950 = popsize1950[order(popsize1950$state),"size"]
	density1950 = popsize1950/statearea
	popsize2000 = subset(popsize,year==2000 & !is.element(state,c("Alaska","Puerto Rico","Hawaii","District of Columbia")))
	popsize2000 = popsize2000[order(popsize2000$state),"size"]
	density2000 = popsize2000/statearea
	X = centroids[statenames,"X"]
	Y = centroids[statenames,"Y"]

	if(is.null(a))
	{
		regamlolo = gam(density1950~lo(X)+lo(Y)+lo(X,Y),family=gaussian)
		v = predict(regamlolo,newdata=data.frame(Y=yv,X=xv))
		v[v<0]=0
		mv1950 = matrix(v,lwidth,lheight)

		regamlolo = gam(density2000~lo(X)+lo(Y)+lo(X,Y),family=gaussian)
		v = predict(regamlolo,newdata=data.frame(Y=yv,X=xv))
		v[v<0]=0
		mv2000 = matrix(v,lwidth,lheight)
	}
	else
	{
		mv1950 = a$mv1950
		mv2000 = a$mv2000
	}

#	densityrange = range(c(density1950,density2000))
	densityrange = c(0,1000)

#	themin = max(min(c(mv1950,mv2000)),0)
#	themax = max(c(mv1950,mv2000))
#	therange = range(c(mv1950,mv2000))

# The first distances-latitude plot on the left of the first map:
	par(plt=c(x1,x2,y3,y4),mgp=c(1.5,0.5,0))
	plot(density1950,Y,ylim=ylim,ylab="latitude (degree)",xlab="",xaxs="r",yaxs="i",axes=F,col="red",xlim=densityrange)
	axis(3); axis(2)
	mtext("state population density",line=1.5)

# The first map:
	par(plt=c(x3,x4,y3,y4),new=T)
	image(x,y,mv1950,col=rev(heat.colors(10)),ann=F,axes=F)
#	image(x,y,mv1950,col=rev(heat.colors(10))[round((min(mv1950)-themin)/diff(therange)+1):round(10-(themax-max(mv1950))/diff(therange))],ann=F,axes=F)
#	contour(x,y,mv1950,add=T)
	polygon(c(tmp$x,tmp$x[1],tmp$x[1],-127,-127,-65,-65,tmp$x[1],tmp$x[1]),
		c(tmp$y,tmp$y[1],23,23,60,60,23,23,tmp$y[1]),col="white",border="white")
	points(tmp$x,tmp$y,type="l")
	points(centroids[,"X"],centroids[,"Y"],pch=20)
	mtext("1950",3,0.3,col="red")

# The second map:
	par(plt=c(x5,x6,y3,y4),new=T)
	image(x,y,mv2000,col=rev(heat.colors(10)),ann=F,axes=F)
#	image(x,y,mv2000,col=rev(heat.colors(10))[round((min(mv2000)-themin)/diff(therange)+1):round(10-(themax-max(mv2000))/diff(therange))],ann=F,axes=F)
#	contour(x,y,mv2000,add=T)
	polygon(c(tmp$x,tmp$x[1],tmp$x[1],-127,-127,-65,-65,tmp$x[1],tmp$x[1]),
		c(tmp$y,tmp$y[1],23,23,60,60,23,23,tmp$y[1]),col="white",border="white")
	points(tmp$x,tmp$y,type="l")
	points(centroids[,"X"],centroids[,"Y"],pch=20)
	mtext("2000",3,0.3,col="blue")

# The second distances-latitude plot on the right of the second map:
	par(plt=c(x7,x8,y3,y4),new=T,mgp=c(1.5,0.5,0))
	plot(densityrange[2]-density2000,Y,ylim=ylim,ylab="",xlab="",xaxs="r",yaxs="i",axes=F,col="blue",xlim=densityrange)
	axis(3,pretty(seq(densityrange[1],densityrange[2],length=10)),paste(rev(pretty(seq(densityrange[1],densityrange[2],length=10))))); axis(4)
	mtext("latitude (degree)",4,1.5)
	mtext("state population density",line=1.5)

# The first color scale:
#	xx = 0.005
#	yy = 0.03
#	par(plt=c(x1+xx,x1+xx+yy,y1,y2),new=T,mgp=c(1.5,0.5,0))
#	colrange = seq(themin,themax,length=100)
#	scalecol = matrix(rep(colrange,25),ncol=25)
#	image(1:25,colrange,t(scalecol),col=rev(heat.colors(nbcol)),ann=F,axes=F,ylim=c(0,4))
#	axis(2,pretty(0:4))
#	rect(1,min(4,themax),25,themin)

# The first distances-longitude graph:
	par(plt=c(x3,x4,y1,y2),new=T,mgp=c(1.5,0.5,0))
	plot(X,density1950,xlim=xlim,xlab="longitude (degree)",ylab="state population density",xaxs="i",yaxs="r",axes=F,col="red",ylim=densityrange)
	axis(1); axis(2)
	state1 = X[X<(-100)]
	state2 = X[X>-100]
	mean1 = mean(density1950[X<(-100)])
	mean2 = mean(density1950[X>-100])
	segments(min(state1),mean1,max(state1),mean1,col=rgb(0,0.75,0,1),lwd=2)
	segments(min(state2),mean2,max(state2),mean2,col=rgb(0,0.75,0,1),lwd=2)
	show(mean1); show(mean2)

# The second distances-longitude graph:
	par(plt=c(x5,x6,y1,y2),new=T,mgp=c(1.5,0.5,0))
	plot(X,density2000,xlim=xlim,xlab="longitude (degree)",ylab="",xaxs="i",yaxs="r",axes=F,col="blue",ylim=densityrange)
	mtext("state population density",4,1.25)
	axis(1); axis(4)
	mean1 = mean(density2000[X<(-100)])
	mean2 = mean(density2000[X>-100])
	segments(min(state1),mean1,max(state1),mean1,col=rgb(0,0.75,0,1),lwd=2)
	segments(min(state2),mean2,max(state2),mean2,col=rgb(0,0.75,0,1),lwd=2)
	show(mean1); show(mean2)

# The second color scale:
#	xx = 0.005
#	yy = 0.03
#	par(plt=c(x8-xx-yy,x8-xx,y1,y2),new=T,mgp=c(1.5,0.5,0))
#	colrange = seq(themin,themax,length=100)
#	scalecol = matrix(rep(colrange,25),ncol=25)
#	image(1:25,colrange,t(scalecol),col=rev(heat.colors(nbcol)),ann=F,axes=F,ylim=c(0,4))
#	axis(4,pretty(0:4))
#	rect(1,min(4,themax),25,themin)

# Write the subfigure letters:
#	par(plt=c(0.03,0.08,0.94,0.99),new=T)
#	plot(1:10,1:10,type="n",axes=F,ann=F)
#	text(5,8,"A",font=2)

# Gives the output:
	list(mv1950=mv1950,mv2000=mv2000)
}
