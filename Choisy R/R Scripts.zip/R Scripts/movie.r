#movie = function(data1=prevalenceusa(),data2=prevalencestate())
movie = function(data1=prevalenceusa(),data2=selectstates(pertussis),datamod="filter")
# library(animation)
# saveMovie(moviesmooth(plot=T),interval=1/24,movietype="mpg",dev=png,outdir=paste(getwd(),"/movie",sep=""))
{
	require(maps)
# The function that transform the values into colors:
	colorfct = function(x,min,max)
		which(hist(x,breaks=seq(min,1.05*max,length=101),plot=F)$counts>0)
# The function that draws the graph:
	thegraph = function(time)
	{
# Plot the time series:
		par(plt=c(0.12,0.96,0.7,0.95),mgp=c(1.5,0.5,0))
		plot(data1$time,data1$prev,type="l",xlab="year",ylab="mean prevalence")
		abline(v=time,col="blue")
# Plot the map:
# Selecting the specific time point we analyse here:
		data2 = data2[abs(data2$time-time)<0.01,]
# Scaling the data:
		if(datamod=="scaling")
		{
			data2$count = data2$count/sum(data2$count)
# We then need to recalculate the min and max values:
			themin = min(data2$count)
			themax = max(data2$count)
		}
# Calculating the colors:
		thecolors = colorset[unlist(lapply(data2$count,function(x)colorfct(x,themin,themax)))]
# Graph parameters:
		plt = c(0.15,1,0.02,NA)
		plt[4] = plt[3]+(plt[2]-plt[1])*ratio
		par(plt=plt,new=T)
# Plotting each state of the map with the good color:
		thestates = data2$state
		nbstates = length(thestates)
	 	plot(themap$x,themap$y,type="n",axes=F,ann=F,ylim=ylim)
		for(i in 1:nbstates)
			map("state",translatestates[translatestates[,1]==thestates[i],2],col=thecolors[i],fill=T,add=T)
# Adding the month and the year in the top right corner:
		theyear = trunc(time)
		themonth = time-theyear
		text(-68,51,paste(month$name[abs(month$index-themonth)<0.01],theyear),adj=c(1,0.5))
# Plot the scale:
		par(plt=c(0.12,0.15,0.1,0.5),new=T)
		colrange = seq(themin,themax,length=100)
		scalecol = matrix(rep(colrange,25),ncol=25)
		image(1:25,colrange,t(scalecol),col=rev(heat.colors(100)),xlab="",ylab="prevalence",axes=F)
		axis(2)
		box()
	}
#############################################################
# Rounding the times:
	data2$time = round(data2$time,2)
# Selecting the time range we want to analyze (this is doubled online 76-77 for fixing purposes):
	thetimes = sort(unique(data2$time))#[1:1]
	data2 = subset(data2,time<=max(thetimes))
# Transforming, centering and reducing the data:
	if(datamod=="reduce")
	{
		data1$prev = (sqrt(data1$prev)-mean(sqrt(data1$prev)))/sd(sqrt(data1$prev))
		data2$count = (sqrt(data2$count)-mean(sqrt(data2$count)))/sd(sqrt(data2$count))
	}
# Filterting the data:
	if(datamod=="filtering")
	{
#		data1 = subset(data1,time>=1951 & time<=1965)
#		data2 = subset(data2,time>=1951 & time<=1965)
		states = unique(data2$state)
		lower = 3.5; upper = 4.5
		for(state in states)
			data2[data2$state==state,"count"] =
				waveletanalysis(state,data=data2,plot=F,lowerPF=lower,upperPF=upper)$out2$filtr_ts
	}
# Selecting the time range we want to analyze:
#	thetimes = sort(unique(data2$time))[1:1]
#	data2 = subset(data2,time<=max(thetimes))
# Calculate the colors:
	colorset = rev(heat.colors(100))
	themin = min(data2$count)
	themax = max(data2$count)
# Graphic parameters:
	themap = map("usa",plot=F)
	ylim = range(themap$y,na.rm=T)
	ylim[2] = 1.05*ylim[2]
	ratio = 4.5/7
# Months
	month = data.frame(index=round((0.5:11.5)/12,2),name=
		c("January","February","March","April","May","June",
			"July","August","September","October","November","December"))
# Draw the graphics:
	for(time in thetimes) thegraph(time)
}
