lmconfint2 = function(y,thresh=40,col="red",thresh2=45)
{
	x1 = y[y[,2]<=thresh,1]
	y1 = y[y[,2]<=thresh,2]
	x2 = y[y[,2]>thresh & y[,2]<thresh2,1]
	y2 = y[y[,2]>thresh & y[,2]<thresh2,2]
	mod1 = lm(x1~y1)
	mod2 = lm(x2~y2)
	y1 = sort(unique(y1))
	y2 = sort(unique(y2))
	prd1 = predict(mod1,data.frame(y1=y1),int="conf",level=.99)
	prd2 = predict(mod2,data.frame(y2=y2),int="conf",level=.99)
	lines(prd1[,2],y1,lty=1,col=col)
	lines(prd1[,3],y1,lty=1,col=col)
	lines(prd2[,2],y2,lty=1,col=col)
	lines(prd2[,3],y2,lty=1,col=col)
}
