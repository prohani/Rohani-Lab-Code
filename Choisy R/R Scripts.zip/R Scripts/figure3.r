figure3 = function(a=dataphaseplot4)
{
	nbcol = 12
# The maps:
	xlim = c(-125,-67); ylim = c(25,50)
	par(plt=c(0.32,0.95,0.495,0.9))
	image(a$x,a$y,a$mv,col=rev(heat.colors(nbcol)),ann=F,axes=F)
	contour(a$x,a$y,a$mv,add=T)
	polygon(c(a$tmp$x,a$tmp$x[1],a$tmp$x[1],-127,-127,-65,-65,a$tmp$x[1],a$tmp$x[1]),
		c(a$tmp$y,a$tmp$y[1],23,23,60,60,23,23,a$tmp$y[1]),col="white",border="white")
	points(a$tmp$x,a$tmp$y,type="l")
	for(i in a$states) points(a$centroids[i,"X"],a$centroids[i,"Y"],pch=20)
# The graph below the map:
	par(plt=c(0.32,0.95,0.12,0.495),new=T,mgp=c(1.5,0.5,0))
	ylim2 = c(-2,2)
	plot(a$X,a$phases,pch=".",xlim=xlim,ylim=ylim2,xlab="longitude (degree)",
		ylab="residual phase angle (radian)",xaxs="i",yaxs="i",axes=F,type="n")
	axis(1); axis(2)
	polygon(c(a$u,rev(a$u))[is.na(a$vu)==FALSE],a$vu[is.na(a$vu)==FALSE],col="light grey",border=FALSE)
	points(a$X,a$phases,pch=".")
	points(a$centroids[a$states,"X"],a$themeans,pch=20)
	lmconfint(cbind(a$X,a$phases))
# The graph on the left of the map:
	par(plt=c(0.1,0.304,0.495,0.9),new=T,mgp=c(1.5,0.5,0))
	plot(a$phases,a$Y,pch=".",xlim=ylim2,ylim=ylim,xlab="",ylab="latitude (degree)",
		xaxs="i",yaxs="i",axes=F,type="n")
	axis(3); axis(2,seq(30,45,5))
	points(a$phases,a$Y,pch=".")
	points(a$themeans,a$centroids[a$states,"Y"],pch=20)
	mtext("residual phase angle (radian)",line=1.5)
# The color scale:
	par(plt=c(0.15,0.2,0.12,0.495),new=T,mgp=c(1.5,0.5,0))
	colrange = seq(min(a$themeans),max(a$themeans),length=100)
	scalecol = matrix(rep(colrange,25),ncol=25)
	image(1:25,colrange,t(scalecol),col=rev(heat.colors(nbcol)),ylim=ylim2,ann=F,axes=F)
	themin = min(a$themeans)
	axis(2,c(themin,themin+pi/4,themin+pi/2,themin+3*pi/4,themin+pi),c("0","0.5","1","1.5","2"),line=1.35)
	mtext("        lag (year)",2,2.8)
	rect(1,max(colrange[1],ylim2[1]),25,min(colrange[length(colrange)],ylim2[2]))
}
