wavelettest2 = function(object,test=11,pvalue=0.05)
# NOTICE: this function is the function we will use until the function wavelettest
# is completed. Compared to wavelettest, it focuses only on the comparison with
# white (test=10) or red (test=11) noise.
# What this function does basically is nothing more that putting the pv values given
# by wavelettestnoise2 into a good shape (matrix) for plotting by waveletplot. All the
# work is actually performed by wavelettestnoise2.

# Arguments:
# test     : test options: 	10 comparison with white noise
#				11 with red noise
# Value:
# pv      : matrice of the Pvalue of the power wavelet, for test = 10,11 it's just the pvalue level
# gm_ws   : pvalue significance level for the average wavelet spectrum of y
# fm_var  : pvalue significance level for the average variance of the series
{
	del = 0.776
	y = object$y
	n_y = length(y)
	if(abs(mean(y))>0.0000001)
	{      
		message('the use of noise tests needs signal with zero mean')
		message('you will not be able to interpret the results of the test')
		message('you must employ bootstrap approaches or normalized signal')
	}
# white noise:
	if(test==10) lag = 0
# red noise:
	else if(test==11) lag = 1
	out = wavelettestnoise2(y,lag,object$dt,object$scale,pvalue,object$fourier_factor)
	pv = out$pv_scalog%*%t(rep(1,n_y))
	pv = pvalue*pv/wavepower(object)	# pv = power/pv
#	pv = wavepower(object)/var(y)/pvi
	list(pv=pv,gm_ws=out$pv_spec)
}
