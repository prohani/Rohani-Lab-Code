slopechangesm1 = function(data=pertussis,from,to,lower=3.5,upper=4.5,alpha=0.05,pad=128,rev=F,graph=T)
{
	require(multicore)
	thresh = -100
# Set the values of the time selection if needed:
	if(missing(from)) from = floor(min(data$time))
	if(missing(to)) to = ceiling(max(data$time))
	states = unique(selectstates(data)$state)
	nbstates = length(states)
	time = unique(data$time)
	thelength = length(time)
# Make the latitude and longitude matrices:
	X = centroids[states,"X"]
	Y = centroids[states,"Y"]
# Function that does the regression lines:
	if(rev)
	{
		reg = function(y)
		{
# Calculate and linearly transform the phases for all the states:
			phases = NULL
			for(i in states)
				phases = cbind(phases,transfphase(waveletfilter(
					waveletanalysis(i,y,to,data,F,pad=pad),lower,upper)$phase_ts))
# Take the residuals of the phases:
			phases = phases - apply(phases,1,mean,na.rm=T)
			phases1 = as.vector(phases[,X<=thresh])
			phases2 = as.vector(phases[,X>thresh])
			X1 = rep(X[X<=thresh],each=nrow(phases))
			X2 = rep(X[X>thresh],each=nrow(phases))
			reg1 = lm(phases1~X1)
			reg2 = lm(phases2~X2)
			c(coef(reg1)[2],coef(reg2)[2],
				summary(reg1)$coef[2,2],summary(reg2)$coef[2,2],
				summary(reg1)$coef[2,4],summary(reg2)$coef[2,4])
		}
		times = time[1:(thelength-48)]
#		slopes = NULL
#		for(i in times) slopes= rbind(slopes,reg(i))
		slopes = matrix(unlist(mclapply(times,function(x)reg(x))),nrow=length(times),byrow=T)
	}
	else
	{
		reg = function(y)
		{
# Calculate and linearly transform the phases for all the states:
			phases = NULL
			for(i in states)
				phases = cbind(phases,transfphase(waveletfilter(
					waveletanalysis(i,from,y,data,F,pad=pad),lower,upper)$phase_ts))
# Take the residuals of the phases:
			phases = phases - apply(phases,1,mean,na.rm=T)
			phases1 = as.vector(phases[,X<=thresh])
			phases2 = as.vector(phases[,X>thresh])
			X1 = rep(X[X<=thresh],each=nrow(phases))
			X2 = rep(X[X>thresh],each=nrow(phases))
			reg1 = lm(phases1~X1)
			reg2 = lm(phases2~X2)
			c(coef(reg1)[2],coef(reg2)[2],
				summary(reg1)$coef[2,2],summary(reg2)$coef[2,2],
				summary(reg1)$coef[2,4],summary(reg2)$coef[2,4])
		}
		times = time[49:thelength]
#		slopes = NULL
#		for(i in times) slopes = rbind(slopes,reg(i))
		slopes = matrix(unlist(mclapply(times,function(x)reg(x))),nrow=length(times),byrow=T)
	}
#	slopes[,3:4] = slopes[,3:4]*qnorm(1-alpha/2)
# The graph:
	if(graph)
	{
		opar = par(mgp=c(1.5,0.5,0))
# Western slopes:
		upper = slopes[,1]+slopes[,3]*qnorm(1-alpha/2)
		lower = slopes[,1]-slopes[,3]*qnorm(1-alpha/2)
		plot(times,slopes[,1],type="l",col="blue",xlab="year",ylab="estimated slopes",axes=T,ylim=c(-0.1,0.3))
		polygon(c(times,rev(times)),c(lower,rev(upper)),col=rgb(0,0,1,0.5),border=NA)
# Eastern slopes:
		upper = slopes[,2]+slopes[,4]*qnorm(1-alpha/2)
		lower = slopes[,2]-slopes[,4]*qnorm(1-alpha/2)
		points(times,slopes[,2],type="l",col="red")
		polygon(c(times,rev(times)),c(lower,rev(upper)),col=rgb(1,0,0,0.5),border=NA)
# Back to initial graph parameters:
		par(opar)
	}
# Give the output:
	list(times=times,slopes=slopes)
}
