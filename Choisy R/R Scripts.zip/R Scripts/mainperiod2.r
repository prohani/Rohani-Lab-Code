mainperiod2 = function(mid=1965,scaled=T,data=selectstates(pertussis),out=NULL)
{
	par(mfrow=c(1,2),plt=c(0.25,0.95,0.2,0.9),cex=1/0.88)
	if(is.null(out))
	{	
		out1 = NULL
		out2 = NULL
		showresults = T
	}
	else
	{
		out1 = out$out1
		out2 = out$out2
		showresults = F	
	}
	out1 = mainperiod1(to=mid,scaled=scaled,data=data,titlerange=F,out=out1)
	mtext(paste("before",mid),cex=1.5,line=0.2)
	out2 = mainperiod1(from=mid,scaled=scaled,data=data,titlerange=F,out=out2)
	mtext(paste("after",mid),cex=1.5,line=0.2)
	if(showresults) list(out1=out1,out2=out2)
}
