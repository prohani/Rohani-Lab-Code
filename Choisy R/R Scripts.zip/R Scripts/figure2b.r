figure2b = function(disease=selectstates(pertussis),pop=selectstates(popsize),
	from=1951,mid=1963,to=2008,pdf=F,graph=T,fact=1000)
# width = 5.25, height = 4.75
{
	from1 = 1951
	to1 = 1963
	from2 = 1963
	to2 = 2002
	from3 = 2002
	to3 = 2008
# The graph parameters:
	opar = par()
	x1 = 0.141
	x2 = x1+0.1619
	x3 = x2+0.15265
#	x4 = 0.493
	x4 = 0.494
#	x5 = 0.578
	x5 = 0.579
	x6 = x3+0.1619
	x8 = 0.932
	x7 = x8-0.1619
	y1 = 0.1
	y2 = 0.51
	y3 = 0.66
	y4 = 0.96
# First graph (CCS):
	par(plt=c(x1,x4,y3,y4),mgp=c(1.5,0.5,0))
	pop1 = subset(pop,year>=from1 & year<to1)
	pop2 = subset(pop,year>=from2 & year<to2)
	pop3 = subset(pop,year>=from3 & year<to3)
	disease1 = subset(disease,time>=from1 & time<to1)
	disease2 = subset(disease,time>=from2 & time<to2)
	disease3 = subset(disease,time>=from3 & time<to3)
	out1 = ccs1(disease=selectstates(disease1),pop=selectstates(pop1),graph=F)
	out2 = ccs1(disease=selectstates(disease2),pop=selectstates(pop2),graph=F)
	out3 = ccs1(disease=selectstates(disease3),pop=selectstates(pop3),graph=F)
	pop1 = out1$pop
	pop2 = out2$pop
	pop3 = out3$pop
	fadeout1 = out1$fadeout
	fadeout2 = out2$fadeout
	fadeout3 = out3$fadeout
	param1 = out1$param
	param2 = out2$param
	param3 = out3$param
	the.x1 = seq(min(pop1),max(pop1),length=100)
	the.x2 = seq(min(pop2),max(pop2),length=100)
	the.x3 = seq(min(pop3),max(pop3),length=100)
#	the.y1 = param1[1]*exp(param1[2]*the.x1)
#	the.y2 = param2[1]*exp(param2[2]*the.x2)
#	the.y3 = param3[1]*exp(param3[2]*the.x3)
	the.y1 = log(param1[1])+param1[2]*the.x1
	the.y2 = log(param2[1])+param2[2]*the.x2
	the.y3 = log(param3[1])+param3[2]*the.x3
#	plot(c(pop1,pop2,pop3)/fact,c(fadeout1,fadeout2,fadeout3),type="n",
	plot(c(pop1,pop2,pop3)/fact,log(c(fadeout1,fadeout2,fadeout3)),type="n",
		xlab=paste("population size x",fact,sep=""),
		ylab="with zero notification)",axes=F,xlim=c(0,30000))
	axis(1); axis(2)
	mtext("log(proportion of months",2,2.4)
#	legend("topright",legend=c(paste(from1,"-",to1-1,"      ",sep=""),
#		paste(from2,"-",to2-1,"      ",sep=""),paste(from3,"-",to3-1,"      ",sep="")),
#		col=c("red","black","blue"),text.col=c("red","black","blue"),bg="white",lty=1,box.col="white")
	legend(9000,0.07,legend=c(paste(from1,"-",to1-1,sep=""),
		paste(from2,"-",to2-1,sep=""),paste(from3,"-",to3-1,"      ",sep="")),
		col=c("red","black","blue"),text.col=c("red","black","blue"),bg="white",lty=1,box.col="white")
#	points(pop2/fact,fadeout2,col=rgb(0,0,0,0.5))
#	points(pop3/fact,fadeout3,col=rgb(0,0,1,0.5))
#	points(pop1/fact,fadeout1,col=rgb(1,0,0,0.5))
	points(pop2/fact,log(fadeout2),col=rgb(0,0,0,1))
	points(pop3/fact,log(fadeout3),col=rgb(0,0,1,1))
	points(pop1/fact,log(fadeout1),col=rgb(1,0,0,1))
	points(the.x2/fact,the.y2,type='l',col="black")
	points(the.x3/fact,the.y3,type='l',col="blue")
	points(the.x1/fact,the.y1,type='l',col="red")
#	segments(out2$CCS/1000,-0.1,out2$CCS/1000,0.45,lty=2,col="black")
	segments(out2$CCS/1000,-7,out2$CCS/1000,-3,lty=2,col="black")
	abline(v=out3$CCS/1000,lty=2,col="blue")
	abline(v=out1$CCS/1000,lty=2,col="red")
	segments(-5000,log(out1$thresh),6000,log(out1$thresh),lty=1,col="red")
	segments(-5000,log(out2$thresh),30000,log(out2$thresh),lty=1,col="black")
	segments(-5000,log(out3$thresh),12000,log(out3$thresh),lty=1,col="blue")
#	abline(h=log(out1$thresh),lty=2,col="red")
#	abline(h=log(out2$thresh),lty=2,col="black")
#	abline(h=log(out3$thresh),lty=2,col="blue")
# Second graph (Sncf):
	par(plt=c(x5,x8,y3,y4),mgp=c(1.5,0.5,0),new=T)
	corrdistance3()
# Third graph (main period for 1951-1962):
	par(plt=c(x1,x2,y1,y2),mgp=c(1.5,0.5,0),new=T)
	out = datamainperiod1nopad_before1963
	spectrum = out$spectrum
	spectrum = spectrum/out$variance%*%t(rep(1,ncol(spectrum)))
	nbstates = nrow(spectrum)
	theticks = c(nbstates,seq(nbstates+1,1,by=-10)[-1],1)
#	spectrum = spectrum^0.3
	image(seq(0.1,out$upperP,length=ncol(spectrum)),1:nbstates,t(spectrum[nbstates:1,]),
		col=rev(heat.colors(100)),xlab="period (years)",ylab="",axes=F)
	mtext(paste(out$from,"-",out$to-1,sep=""),3,0.3,col="red")
	axis(4,at=theticks,labels=as.character(rev(theticks)))
	axis(1); box()
	abline(v=1,lty=2)
	abline(v=4,lty=2)
# The scale of the third graph:
	par(plt=c(x1-0.03,x1-0.01,y1,y2),new=T)
	colrange = seq(min(spectrum),max(spectrum),length=100)
	scalecol = matrix(rep(colrange,25),ncol=25)
	image(1:25,colrange,t(scalecol),col=rev(heat.colors(100)),ann=F,axes=F)
	axis(2)
	mtext("global power",2,line=1.3); box()
# Fourth graph (main period for 1963-2001):
	par(plt=c(x3,x6,y1,y2),mgp=c(1.5,0.5,0),new=T)
	out = datamainperiod1nopad_1963_2001
	spectrum = out$spectrum
	spectrum = spectrum/out$variance%*%t(rep(1,ncol(spectrum)))
	nbstates = nrow(spectrum)
	theticks = c(nbstates,seq(nbstates+1,1,by=-10)[-1],1)
#	spectrum = spectrum^0.3
	image(seq(0.1,out$upperP,length=ncol(spectrum)),1:nbstates,t(spectrum[nbstates:1,]),
		col=rev(heat.colors(100)),xlab="period (years)",ylab="",axes=F)
	mtext(paste(out$from,"-",out$to-1,sep=""),3,0.3)
	axis(4,at=theticks,labels=as.character(rev(theticks)))
	axis(1); box()
	abline(v=1,lty=2)
	abline(v=4,lty=2)
# The scale of the fourth graph:
	par(plt=c(x3-0.03,x3-0.01,y1,y2),new=T)
	colrange = seq(min(spectrum),max(spectrum),length=100)
	scalecol = matrix(rep(colrange,25),ncol=25)
	image(1:25,colrange,t(scalecol),col=rev(heat.colors(100)),ann=F,axes=F)
	axis(2)
	mtext("global power",2,line=1.3); box()
# Fifth graph (main period for 2002-2007):
	par(plt=c(x7,x8,y1,y2),mgp=c(1.5,0.5,0),new=T)
	out = datamainperiod1nopad_2002_2007
	spectrum = out$spectrum
#	spectrum = spectrum/out$variance%*%t(rep(1,ncol(spectrum)))
	nbstates = nrow(spectrum)
	theticks = c(nbstates,seq(nbstates+1,1,by=-10)[-1],1)
#	spectrum = spectrum^0.3
	image(seq(0.1,out$upperP,length=ncol(spectrum)),1:nbstates,t(spectrum[nbstates:1,]),
		col=rev(heat.colors(100)),xlab="period (years)",ylab="",axes=F)
	mtext(paste(out$from,"-",out$to-1,sep=""),3,0.3,col="blue")
	axis(4,at=theticks,labels=as.character(rev(theticks)))
	axis(1); box()
	abline(v=1,lty=2)
	abline(v=4,lty=2)
# The scale of the fifth graph:
	par(plt=c(x7-0.03,x7-0.01,y1,y2),new=T)
	colrange = seq(min(spectrum),max(spectrum),length=100)
	scalecol = matrix(rep(colrange,25),ncol=25)
	image(1:25,colrange,t(scalecol),col=rev(heat.colors(100)),ann=F,axes=F)
	axis(2)
	mtext("global power",2,line=1.3); box()
# Write the subfigure letters:
	tt = 0.08
	par(plt=c(x1-tt,x1-tt+0.05,0.95,1),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(5,6,"A",font=2)
	par(plt=c(0.498,0.548,0.95,1),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(5,6,"B",font=2)
	par(plt=c(x1-tt,x1-tt+0.05,0.52,0.57),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(5,5,"C",font=2)
	par(plt=c(x3-tt,x3-tt+0.05,0.52,0.57),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(5,5,"D",font=2)
	par(plt=c(x7-tt,x7-tt+0.05,0.52,0.57),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(5,5,"E",font=2)
# Restaure the initial graph parameters:
	par(opar)
}
