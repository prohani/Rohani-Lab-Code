popeffect = function(data=pertussis,from=1951,to=1963,lower=3.5,upper=4.5,alpha=0.01,pad=128,method="method1")
{
# Set the values of the time selection if needed:
#	if(missing(from)) from = floor(min(data$time))
#	if(missing(to)) to = ceiling(max(data$time))
# Calculating the phases:
	states = unique(selectstates(data)$state)
	phases = NULL
	if(method=="method1")
		for(i in states)
			phases = cbind(phases,
				transfphase(waveletfilter(waveletanalysis(i,from,to,data,F,pad=pad),lower,upper)$phase_ts))
	else
	{
		for(i in states)
			phases = cbind(phases,
				transfphase(waveletfilter(waveletanalysis(i,data=data,plot=F,pad=pad),lower,upper)$phase_ts))
		phases = phases[unique(data$time)>=from & unique(data$time)<=to,]
	}
# phases is a matrix where each column corresponds to a state and each row corresponds to a month.
# Making the time vector:
	times = unique(subset(data,time>=from & time<=to)$time)
# Transforming the phase angles:
#	phases = as.vector(t(phases-apply(phases,1,mean,na.rm=T)))
	phases = as.vector(phases-apply(phases,1,mean,na.rm=T))
# Making the population size vector:
#	size = matrix(unlist(as.vector(subset(popsize[is.element(popsize$state,states),],
#		year>=from & year<=to,size))),nrow=length(states))
	size = popsize[is.element(popsize$state,states) & is.element(popsize$year,trunc(times)),"size"]
	size = matrix(size,nrow=length(states))
# Size is a matrix where each column is a year and each row is a state.
# The states are is the same order as for the phases matrix.
# This is the number of times each year should be repeated:
	nbrep = table(trunc(times))
	tmp = NULL
#	for(i in 1:length(nbrep)) tmp=c(tmp,rep(size[,i],nbrep[i]))
	for(i in 1:length(states)) tmp = c(tmp,rep(size[i,],each=nbrep))
	size = tmp
# Making the vector of state names:
	statenames = rep(states,each=sum(nbrep))
# Drawing the figure:
	size=log10(size)
	par(mgp=c(1.5,0.5,0),xlog=F)
	plot(size,phases,xlab="log(population size)",ylab="residual phase angle (radian)",ylim=c(-2,2),col=rgb(0,0,0,0.05),pch=19)
	points(size[statenames=="New York"],phases[statenames=="New York"],col=rgb(1,0,0,0.05),pch=19)
	points(size[statenames=="Colorado"],phases[statenames=="Colorado"],col=rgb(0,0,1,0.05),pch=19)
# The linear regression:
	mod = lm(phases~size)
	x = sort(unique(size))
	prd = predict(mod,data.frame(size=x),int="conf",level=1-alpha)
	lines(x,prd[,2])
	lines(x,prd[,3])
	list(size=size,phases=phases,x=x,prd=prd,statenames=statenames)
}
