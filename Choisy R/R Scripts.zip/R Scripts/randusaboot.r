randusaboot = function(nbcounties=50,B=2)
{
	out = NULL
	for(i in 1:B)
	{
		foo = randusa(nbcounties)
		bar = randusaanal(foo)
		out = rbind(out,cbind(foo,bar))
	}
	out[,1] = round(out[,1])
	foo = unique(out[,1])
	for(i in 1:length(foo))
	{
		bar = out[out[,1]==foo[i],3]
		sort(bar)
		
	}
}
