phaserotation = function(data=pertussis,from=1951,to=1963,lower=3.5,upper=4.5)
{
# The following function transforms the phase time series into a monotonally increasing one,
# accounting for the irregularities in the phase time series. Then it performs a linear
# regression over of phases as a function of time (this is the mean phase averaged over all
# states. Then it calculates the residuals against this mean trend and plot it as a function
# of the longitude.
	require(plotrix)
	transf = function(phase)
	{
		A = which(diff(phase)<0)
		B = which(diff(A)==1)
		phase[A[B]+1] = NA
		A = which(phase<0)
		B = which(diff(A)>1)
		breaks = A[c(0,B)+1]
		breaks = breaks[breaks>1]
		end = length(phase)
		for(i in breaks) phase[i:end] = phase[i:end]+2*pi
		phase
	}
# Set the values of the time selection if needed:
#	if(missing(from)) from = floor(min(data$time))
#	if(missing(to)) to = ceiling(max(data$time))
	phases = NULL
	states = unique(selectstates(data)$state)
	for(i in states)
		phases = cbind(phases,transf(waveletfilter(waveletanalysis(i,from,to,data,F),lower,upper)$phase_ts))
# Creates the time vector:
	times = unique(subset(data,time>=from & time<=to)$time)
# Performs the linear regression:
	mod = lm(as.vector(phases)~rep(times,49))
# And calculate the residuals:
	pred = mod$coef[1]+mod$coef[2]*times
	pred = matrix(rep(pred,49),ncol=49)
# Put the data in shape for further analysis:
	phases = phases1 = phases-pred
	phases = as.vector(t(phases))
	X = rep(centroids[states,"X"],144)
	Y = rep(centroids[states,"Y"],144)
	data = cbind(X,Y,phases)
# Calculates the angle that minimize the deviance of the broken model:
	miniangle = optimize(brokenlm,c(0,pi),data=data,thresh=-100)$minimum
# Calculates the deviance as the rotation angle varies from 0 to 2*pi:
	dev = NULL
	angles = seq(0,2*pi,length=1000)
	for(i in angles) dev = c(dev,brokenlm(data,angle=i))
# Draws the graph:
	par(pty="s",las=1,mar=rep(2,4))
	plot(dev*cos(angles),dev*sin(angles),type="l",ann=F,axes=F,xlim=c(-4200,4200),ylim=c(-4200,4200),col="blue")
	mtext("S",1); mtext("W",2); mtext("N",3); mtext("E",4)
	for(i in seq(1000,4000,1000)) draw.circle(0,0,i,lty=2)
	abline(h=0); abline(v=0)
	abline(0,sin(miniangle)/cos(miniangle),col="red")
# Give the output:
	list(data=data,dev=dev,angles=angles,miniangle=miniangle)
}
