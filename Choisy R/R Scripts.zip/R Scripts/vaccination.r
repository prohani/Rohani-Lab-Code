vaccination = function(disease=selectstates(pertussis),pop=selectstates(popsize),transf="none",prevalence=T)
{
	require(akima)
# Load the vaccine coverage data:
	vacccov = read.table("pertussis vaccine coverage.dat",header=T)
# Calculate the time range of the vaccine coverage data:
	timerange = range(vacccov$year)
# Calculate the mean vaccine coverage by year (averaging over all vaccine coverage sources):
	vacccov = tapply(vacccov$coverage,vacccov$year,mean)
# Select the population sizes on the vaccine time range:
	pop = subset(pop,year>=timerange[1] & year<=timerange[2])
# Select the disease counts on the vaccine time range:
	disease = subset(disease,time>=timerange[1] & time<=timerange[2]+1)
# Calculate the number of states:
	nbstates = length(unique(disease$state))
# Calculate the annual mean number of disease cases by state:
	disease = as.vector(tapply(disease$count,list(disease$state,trunc(disease$time)),mean))
# Optionally replace the disease cases by the disease prevalence:
	if(prevalence) disease = disease/pop$size
# Calculate the mean number of disease cases (or prevalence) by year:
	years = rep(timerange[1]:timerange[2],each=nbstates)
	disease = tapply(disease,years,mean)
# Put the vaccine and disease data as two columns of a same matrix (accounting for missing
# values in the vaccine coverage):
	tmp = rep(NA,diff(timerange)+1)
	years = timerange[1]:timerange[2]
	names(tmp) = paste(years)
	for(i in 1:length(vacccov)) tmp[names(vacccov)[i]] = vacccov[i]
	table = cbind(years,disease,tmp)
	colnames(table) = c("year","disease","vaccine")
	rownames(table) = 1:nrow(table)
	table = as.data.frame(table)
# Optionally transform the data:
	if(transf=="log") table$disease = log(table$disease+1)
	if(transf=="sqrt") table$disease = sqrt(table$disease)
# Plot the graph:
	par(mgp=c(1.5,0.5,0))
	plot(table$year,table$disease,type="l",xlab="year",ylab="pertussis cases")
	disspline = smooth.spline(table$year,table$disease,spar=0.5)
	points(disspline$x,disspline$y,type="l",col="blue",lty=2)
	par(new=T)
	plot(table$year,table$vaccine,type="l",col="red",ann=F,axes=F)
	interp = aspline(table$year,table$vaccine,1985:1991)
	table$vaccine[table$year>1985 & table$year<1991] = interp$y[2:6]
	vacspline = smooth.spline(table$year,table$vaccine,spar=0.5)
	points(interp$x,interp$y,type="l",col="red",lty=2)
	points(vacspline$x,vacspline$y,type="l",col="blue",lty=2)
# Calculate the correlation:
	show(cor.test(table$disease,table$vaccine))
#	show(ccf(table$disease,table$vaccine))
#	show(ccf(disspline$y,vacspline$y))
}
