brokenlm = function(data,thresh=-100,angle=0)
{
# We cut the dataset in two datasets:
# below the threshold:
	x1 = data[data[,1]<=thresh,1]
	y1 = data[data[,1]<=thresh,2]
	z1 = data[data[,1]<=thresh,3]
# above the threshold:
	x2 = data[data[,1]>thresh,1]
	y2 = data[data[,1]>thresh,2]
	z2 = data[data[,1]>thresh,3]
# We rotate the plan:
	x1 = x1*cos(angle) + y1*sin(angle)
	x2 = x2*cos(angle) + y2*sin(angle)
# We do the two linear models:
	mod1 = lm(z1~x1)
	mod2 = lm(z2~x2)
# We output the total deviance of the model:
	deviance(mod1)+deviance(mod2)
}
