loadnewdata = function()
# This functions load the recent 2003-2007 weekly data and transform them into monthly data.
{
# Make the newdataset adding 0 notifications for each week and each state of the whole time period:
	newdata = read.table('newdata0307.dat',sep='\t')
	names(newdata) = c("year","week","count","state")
	theyears = sort(unique(newdata$year))
	theweeks = sort(unique(newdata$week))
	thestates = sort(unique(newdata$state))
	thestates2 = rep(rep(thestates,each=length(theweeks)),length(theyears))
	theyears2 = rep(theyears,each=length(theweeks)*length(thestates))
	theweeks2 = rep(theweeks,length(thestates)*length(theyears))
	thecounts2 = rep(0,length(theweeks2))
	for(i in 1:nrow(newdata))
	{
		year = newdata[i,"year"]
		week = newdata[i,"week"]
		state = newdata[i,"state"]
		thecounts2[theyears2==year & theweeks2==week & thestates2==state] = newdata[i,"count"]
	}
	newdata = data.frame(year=theyears2,week=theweeks2,counts=thecounts2,state=thestates2)
# Creates the matrix of the contribution of each week to each month.
# The year of 2003:
	jan = feb = mar = apr = may = jun = jul = aug = sep = oct = nov = dec = rep(0,length(theweeks))
	jan[1] = 5; jan[2:4] = 7; jan[5] = 5
	feb[5] = 2; feb[6:8] = 7; feb[9] = 5
	mar[9] = 2; mar[10:13] = 7; mar[14] = 1
	apr[14] = 6; apr[15:17] = 7; apr[18] = 3
	may[18] = 4; may[19:21] = 7; may[22] = 6
	jun[22] = 1; jun[23:26] = 7; jun[27] = 1
	jul[27] = 6; jul[28:30] = 7; jul[31] = 4
	aug[31] = 3; aug[32:35] = 7
	sep[36:39] = 7; sep[40] = 2
	oct[40] = 5; oct[41:43] = 7; oct[44] = 5
	nov[44] = 2; nov[45:48] = 7
	dec[49:52] = 7; dec[53] = 3
	y2003 = cbind(jan,feb,mar,apr,may,jun,jul,aug,sep,oct,nov,dec)
# The year of 2004:
	jan = feb = mar = apr = may = jun = jul = aug = sep = oct = nov = dec = rep(0,length(theweeks))
	jan[1] = 4; jan[2:4] = 7; jan[5] = 6
	feb[5] = 1; feb[6:9] = 7
	mar[10:13] = 7; mar[14] = 3
	apr[14] = 4; apr[15:17] = 7; apr[18] = 5
	may[18] = 2; may[19:22] = 7; may[23] = 1
	jun[23] = 6; jun[24:26] = 7; jun[27] = 3
	jul[27] = 4; jul[28:30] = 7; jul[31] = 6
	aug[31] = 1; aug[32:35] = 7; aug[36] = 2
	sep[36] = 5; sep[37:39] = 7; sep[40] = 4
	oct[40] = 3; oct[41:44] = 7
	nov[45:48] = 7; nov[49] = 2
	dec[49] = 5; dec[50:52] = 7; dec[53] = 5
	y2004 = cbind(jan,feb,mar,apr,may,jun,jul,aug,sep,oct,nov,dec)
# The year of 2005:
	jan = feb = mar = apr = may = jun = jul = aug = sep = oct = nov = dec = rep(0,length(theweeks))
# For January, we need to add 2 from the month of december 2004, see below.
	jan[1:4] = 7; jan[5] = 1
	feb[5] = 6; feb[6:8] = 7; feb[9] = 1
	mar[9] = 6; mar[10-12] = 7; mar[13] = 4
	apr[13] = 3; apr[14:16] = 7; apr[17] = 6
	may[17] = 1; may[18:21] = 7; may[22] = 2
	jun[22] = 5; jun[23:25] = 7; jun[26] = 4
	jul[26] = 3; jul[27:30] = 7
	aug[31:34] = 7; aug[35] = 3
	sep[35] = 4; sep[36:38] = 7; sep[39] = 5
	oct[39] = 2; oct[40:43] = 7; oct[44] = 1
	nov[44] = 6; nov[45:47] = 7; nov[48] = 3
	dec[48] = 4; dec[49:51] = 7; dec[52] = 6
	y2005 = cbind(jan,feb,mar,apr,may,jun,jul,aug,sep,oct,nov,dec)
# The year of 2006:
	jan = feb = mar = apr = may = jun = jul = aug = sep = oct = nov = dec = rep(0,length(theweeks))
# For January, we need to add 1 from the month of december 2005, see below.
	jan[1:4] = 7; jan[5] = 2
	feb[5] = 5; feb[6:8] = 7; feb[9] = 2
	mar[9] = 5; mar[10:12] = 7; mar[13] = 5
	apr[13] = 2; apr[14:17] = 7
	may[18:21] = 7; may[22] = 3
	jun[22] = 4; jun[23:25] = 7; jun[26] = 5
	jul[26] = 2; jul[27:30] = 7; jul[31] = 1
	aug[31] = 6; aug[32:34] = 7; aug[35] = 4
	sep[35] = 3; sep[36:38] = 7; sep[39] = 6
	oct[39] = 1; oct[40:43] = 7; oct[44] = 2
	nov[44] = 5; nov[45:47] = 7; nov[48] = 4
	dec[48] = 3; dec[49:52] = 7
	y2006 = cbind(jan,feb,mar,apr,may,jun,jul,aug,sep,oct,nov,dec)
# The year of 2007:
	jan = feb = mar = apr = may = jun = jul = aug = sep = oct = nov = dec = rep(0,length(theweeks))
	jan[1:4] = 7; jan[5] = 3
	feb[5] = 4; feb[6:8] = 7; feb[9] = 3
	mar[9] = 4; mar[10:12] = 7; mar[13] = 6
	apr[13] = 1; apr[14:17] = 7; apr[18] = 1
	may[18] = 6; may[19:21] = 7; may[22] = 4
	jun[22] = 3; jun[23:25] = 7; jun[26] = 6
	jul[26] = 1; jul[27:30] = 7; jul[31] = 2
	aug[31] = 5; aug[32:34] = 7; aug[35] = 5
	sep[35] = 2; sep[36:39] = 7
	oct[40:43] = 7; oct[44] = 3
	nov[44] = 4; nov[45:47] = 7; nov[48] = 5
	dec[48] = 2; dec[49:52] = 7; dec[53] = 1
	y2007 = cbind(jan,feb,mar,apr,may,jun,jul,aug,sep,oct,nov,dec)
# Since the contributions to the months january and december are sometimes on two different years,
# we have to extend each year contribution to the all time period.
	y2003 = rbind(y2003,matrix(rep(0,53*12*4),ncol=12))
	y2004 = rbind(matrix(rep(0,53*12),ncol=12),y2004,matrix(rep(0,53*12*3),ncol=12))
	y2005 = rbind(matrix(rep(0,53*12*2),ncol=12),y2005,matrix(rep(0,53*12*2),ncol=12))
	y2006 = rbind(matrix(rep(0,53*12*3),ncol=12),y2006,matrix(rep(0,53*12),ncol=12))
	y2007 = rbind(matrix(rep(0,53*12*4),ncol=12),y2007)
# We put everything altogether, and add the too contributions from months of December to months of January:
	y2005[106,1] = 2
	y2006[159,1] = 1
# We divide by 7, the number of days per week:
	y2003 = y2003/7
	y2004 = y2004/7
	y2005 = y2005/7
	y2006 = y2006/7
	y2007 = y2007/7
# We put the contributions of all the year into a single list:
	foo = list(y2003,y2004,y2005,y2006,y2007)
# We now transform the weekly data into monthly data:
	newcounts = NULL
	for(j in thestates)
		for(i in 1:length(theyears))
			newcounts = c(newcounts,round(apply(subset(newdata,state==j)$counts*foo[[i]],2,sum)))
# Make the new data frame:
	data = data.frame(time=rep(rep(theyears,each=12)+rep(seq(1,24,2)/24,length(theyears)),length(thestates)),
		count=newcounts,state=rep(thestates,each=12*length(theyears)))
# Give each column of the dataframe data the good format:
	data$time = as.numeric(data$time)
	data$count = as.integer(data$count)
	data$state = as.character(data$state)
# Re-order the data frame chronologically for each state:
	data = data[order(data$time),]
	data = data[order(data$state),]
# Re-initilize the row names of the data frame: 
	rownames(data) = as.character(1:nrow(data))
# Give the output:
	data
}
