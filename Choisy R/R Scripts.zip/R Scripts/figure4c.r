figure4c = function()
# width = 5.5, height = 4.5
{
	x1 = 0.08
	x4 = 0.91
	deltax = 0.355
	x2 = x1+deltax
	x3 = x4-deltax
	y1 = 0.11
	y4 = 0.94
	deltay = 0.34
	y2 = y1+deltay
	y3 = y4-deltay

	alpha = 0.01
	ylim = c(-pi,pi)

	crosses = function(x,alpha=0.05)
	{
		confint = function(vect)
		{
			vect = sort(vect)
			thelength = length(vect)
			vect[round(c(thelength*alpha/2,thelength*(1-alpha/2)))]
		}
		a = size[statenames==x]
		b = phases[statenames==x]
		c(mean(a,na.rm=T),confint(a),mean(b,na.rm=T),confint(b))
	}

# First graph:
	par(plt=c(x1,x2,y3,y4),mgp=c(1.5,0.5,0))
	size = datapopeffect1$size
	phases = datapopeffect1$phases
	statenames = datapopeffect1$statenames
	plot(size,phases,xlab="log(population size)",ylab="residual phase angle (radian)",
		ylim=ylim,col=rgb(0,0,0,0.05),pch=19,type="n")
#	points(size[statenames=="New York"],phases[statenames=="New York"],col=rgb(1,0,0,0.05),pch=19)
#	points(size[statenames=="Colorado"],phases[statenames=="Colorado"],col=rgb(0,0,1,0.05),pch=19)
	foo = matrix(unlist(lapply(unique(statenames),function(x)crosses(x))),byrow=T,ncol=6)
	mod = lm(phases~size)
	x = sort(unique(size))
	prd = predict(mod,data.frame(size=x),int="conf",level=1-alpha)
	lines(x,prd[,2],col="red")
	lines(x,prd[,3],col="red")
	segments(foo[,2],foo[,4],foo[,3],foo[,4])
	segments(foo[,1],foo[,5],foo[,1],foo[,6])
	points(foo[,1],foo[,4])
	points(foo[unique(statenames)=="New York",1],foo[unique(statenames)=="New York",4],col=heat.colors(12)[5],pch=20)
	points(foo[unique(statenames)=="Colorado",1],foo[unique(statenames)=="Colorado",4],col=heat.colors(12)[11],pch=20)

# Second graph:
	par(plt=c(x3,x4,y3,y4),mgp=c(1.5,0.5,0),new=T)
	size = datapopeffect2$size
	phases = datapopeffect2$phases
	statenames = datapopeffect2$statenames
	plot(size,phases,xlab="log(population size)",ylab="residual phase angle (radian)",
		ylim=ylim,col=rgb(0,0,0,0.05),pch=19,type="n")
#	points(size[statenames=="New York"],phases[statenames=="New York"],col=rgb(1,0,0,0.05),pch=19)
#	points(size[statenames=="Colorado"],phases[statenames=="Colorado"],col=rgb(0,0,1,0.05),pch=19)
	foo = matrix(unlist(lapply(unique(statenames),function(x)crosses(x))),byrow=T,ncol=6)
	mod = lm(phases~size)
	x = sort(unique(size))
	prd = predict(mod,data.frame(size=x),int="conf",level=1-alpha)
	lines(x,prd[,2],col="blue")
	lines(x,prd[,3],col="blue")
	segments(foo[,2],foo[,4],foo[,3],foo[,4])
	segments(foo[,1],foo[,5],foo[,1],foo[,6])
	points(foo[,1],foo[,4])
	points(foo[unique(statenames)=="New York",1],foo[unique(statenames)=="New York",4],col=heat.colors(12)[5],pch=20)
	points(foo[unique(statenames)=="Colorado",1],foo[unique(statenames)=="Colorado",4],col=heat.colors(12)[11],pch=20)

# This function calculates the longitudinal speed of propagation at a given latitude (Y).
	speed = function(slope,X1=-120,X2=-70,Y=40)
	{
# Calculates the number of km by longitude degree at the Y latitude:
		lambda1 = X1*pi/180
		lambda2 = X2*pi/180
		delta = lambda1-lambda2
		phi1 = phi2 = Y*pi/180
		radius = 6378
		distance = radius*atan(sqrt((cos(phi2)*sin(delta))^2+
			(cos(phi1)*sin(phi2)-sin(phi1)*cos(phi2)*cos(delta))^2)/
			(sin(phi1)*sin(phi2)+cos(phi1)*cos(phi2)*cos(delta)))
		distance = distance/abs(X1-X2)
# Transforms the slope into speed:
		pi*distance/(2*abs(slope))
	}

	calcdistr = function(i)
	{
		tmp = sort(rnorm(B,abs(slopes[i,1]),slopes[i,3])/rnorm(B,slopes[i,2],slopes[i,4]))
		c(mean(tmp),tmp[round(B*c(alpha/2,1-alpha/2))])
	}

	alpha = 0.05
	B = 10000
	ylim = c(0,600)
# Third graph:
	par(plt=c(x1,x2,y1,y2),mgp=c(1.5,0.5,0),new=T)
	time = dataslopechangescumbefore$time
	sel = time>=1951 & time<1970
	slopes = dataslopechangescumbefore$slopes
# Transform the data:
	tr1 = -0.07311/slopes[132,1]
	tr2 = 0.03581/slopes[132,2]
	slopes[,1] = tr1*slopes[,1]
	slopes[,2] = tr2*slopes[,2]
# Transform the slopes into speeds:
	speeds = speed(slopes)/12
# The western slopes:
	upper = speed(slopes[sel,1]+slopes[sel,3]*qnorm(1-alpha/2))/12
	lower = speed(slopes[sel,1]-slopes[sel,3]*qnorm(1-alpha/2))/12
#	plot(time[sel],speeds[sel,1],type="l",col="blue",xlab="year",ylab="longitudinal speed (km/month)",axes=T,xlim=c(1950,1970),ylim=ylim)
	plot(time[sel],speeds[sel,1],type="l",col=heat.colors(12)[11],xlab="year",ylab="longitudinal speed (km/month)",axes=T,xlim=c(1950,1970),ylim=ylim)
#	polygon(c(time[sel],rev(time[sel])),c(lower,rev(upper)),col=rgb(0,0,1,0.5),border=NA)
	polygon(c(time[sel],rev(time[sel])),c(lower,rev(upper)),col=heat.colors(12,0.7)[11],border=NA)
	points(time[sel],speeds[sel,1],type="l",col=heat.colors(12)[8])
# The eastern slopes:
	upper = speed(slopes[sel,2]+slopes[sel,4]*qnorm(1-alpha/2))/12
	lower = speed(slopes[sel,2]-slopes[sel,4]*qnorm(1-alpha/2))/12
#	points(time[sel],speeds[sel,2],type="l",col="red")
	points(time[sel],speeds[sel,2],type="l",col=heat.colors(12)[4])
#	polygon(c(time[sel],rev(time[sel])),c(lower,rev(upper)),col=rgb(1,0,0,0.5),border=NA)
	polygon(c(time[sel],rev(time[sel])),c(lower,rev(upper)),col=heat.colors(12,0.5)[5],border=NA)
#The speed ratio with its confidence interval:
	par(new=T)
#	sel = time>=1956 & time<1967
	sel = time>=1951 & time<1970
	plot(time[sel],abs(speeds[sel,1])/speeds[sel,2],type="n",xlim=c(1950,1970),ylim=c(0,3),ann=F,axes=F)
	axis(4); #mtext("eastern over western speed ratio",4,1.5)
	out = NULL
	for(y in (1:length(time))[sel]) out = rbind(out,calcdistr(y))
#	polygon(c(time[sel],rev(time[sel])),c(out[,2],rev(out[,3])),col=rgb(0,0,0,0.5),border=NA)
	points(time[sel],out[,1],type="l")
	points(time[sel],out[,2],type="l",lty=2,lwd=1)
	points(time[sel],out[,3],type="l",lty=2,lwd=1)

# Fourth graph:
	par(plt=c(x3,x4,y1,y2),mgp=c(1.5,0.5,0),new=T)
	time = dataslopechangescumafter$time
	sel = time>=1988 & time<2008
	slopes = dataslopechangescumafter$slopes
# Transform the data:
	tr1 = -0.07311/slopes[132,1]
	tr2 = 0.03581/slopes[132,2]
#	slopes[,1] = tr1*slopes[,1]
#	slopes[,2] = tr2*slopes[,2]
# Transform the slopes into speeds:
	speeds = speed(slopes)/12
# The western slopes:
#	upper = speed(slopes[sel,1]+slopes[sel,3]*qnorm(1-alpha/2))/12
#	lower = speed(slopes[sel,1]-slopes[sel,3]*qnorm(1-alpha/2))/12
	upper = slopes[sel,1]+slopes[sel,3]*qnorm(1-alpha/2)
	lower = slopes[sel,1]-slopes[sel,3]*qnorm(1-alpha/2)
	lower[lower<0] = 1e-6
	upper = speed(upper)/12
	lower = speed(lower)/12
#	plot(time[sel],speeds[sel,1],type="l",col="blue",xlab="year",ylab="",axes=F,xlim=c(1988,2008),ylim=ylim)
	plot(time[sel],speeds[sel,1],type="l",col=heat.colors(12)[11],xlab="year",ylab="",axes=F,xlim=c(1988,2008),ylim=ylim)
	axis(1); axis(4); box(); mtext("longitudinal speed (km/month)",4,1.5)
#	polygon(c(time[sel],rev(time[sel])),c(lower,rev(upper)),col=rgb(0,0,1,0.5),border=NA)
	polygon(c(time[sel],rev(time[sel])),c(lower,rev(upper)),col=heat.colors(12,0.7)[11],border=NA)
	points(time[sel],speeds[sel,1],type="l",col=heat.colors(12)[8])
# The eastern slopes:
#	upper = speed(slopes[sel,2]+slopes[sel,4]*qnorm(1-alpha/2))/12
#	lower = speed(slopes[sel,2]-slopes[sel,4]*qnorm(1-alpha/2))/12
	upper = slopes[sel,2]+slopes[sel,4]*qnorm(1-alpha/2)
	lower = slopes[sel,2]-slopes[sel,4]*qnorm(1-alpha/2)
	lower[lower<0] = 1e-6
	upper = speed(upper)/12
	lower = speed(lower)/12
#	points(time[sel],speeds[sel,2],type="l",col="red")
	points(time[sel],speeds[sel,2],type="l",col=heat.colors(12)[4])
#	polygon(c(time[sel],rev(time[sel])),c(lower,rev(upper)),col=rgb(1,0,0,0.5),border=NA)
	polygon(c(time[sel],rev(time[sel])),c(lower,rev(upper)),col=heat.colors(12,0.5)[5],border=NA)
#	abline(h=0,lty=2)
#	abline(v=time[132])
#	abline(h=slopes[132,1])
#	abline(h=slopes[132,2])
# The speed ratio with its confidence interval:
	par(new=T)
	sel = time>=1988 & time<2008
	plot(time[sel],abs(speeds[sel,1])/speeds[sel,2],type="n",xlim=c(1988,2008),ylim=c(0,3),ann=F,axes=F)
	axis(2); mtext("eastern over western speed ratio",2,1.5)
	out = NULL
	for(y in (1:length(time))[sel]) out = rbind(out,calcdistr(y))
#	polygon(c(time[sel],rev(time[sel])),c(out[,2],rev(out[,3])),col=rgb(0,0,0,0.5),border=NA)
	points(time[sel],out[,1],type="l")
	points(time[sel],out[,2],type="l",lty=2)
	points(time[sel],out[,3],type="l",lty=2)


# Write the subfigure letters:
	x = 0.025
	y = 0.01
	par(plt=c(x1-x,x1-x+0.05,y4+y,y4+y+0.05),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(5,5,"A",font=2)
	par(plt=c(x3-x,x3-x+0.05,y4+y,y4+y+0.05),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(5,5,"B",font=2)
	par(plt=c(x1-x,x1-x+0.05,y2+y,y2+y+0.05),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(5,5,"C",font=2)
	par(plt=c(x3-x,x3-x+0.05,y2+y,y2+y+0.05),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(5,5,"D",font=2)
}
