figure4b = function()
# width = 5.5, height = 2.25
{
	y1 = 0.235
#	y2 = 0.91
	y2 = 0.89
	t = 0.02
# First graph:
	alpha = 0.01
	size = datapopeffect$size
	phases = datapopeffect$phases
	statenames = datapopeffect$statenames
#	par(plt=c(0.115,0.485,y1-0.01,y2-0.01),mgp=c(1.5,0.5,0))
	par(plt=c(0.105,0.44,y1-0.01,y2-0.01),mgp=c(1.5,0.5,0))
#	plot(size,phases,xlab="log(population size)",ylab="residual phase angle (radian)",
#		ylim=c(-2,2),col=rgb(0,0,0,0.05),pch=19)
	plot(size,phases,xlab="log(population size)",ylab="residual phase angle (radian)",
		ylim=c(-2,2),col=rgb(0,0,0,0.05),pch=19)
	points(size[statenames=="New York"],phases[statenames=="New York"],col=rgb(1,0,0,0.05),pch=19)
	points(size[statenames=="Colorado"],phases[statenames=="Colorado"],col=rgb(0,0,1,0.05),pch=19)
	mod = lm(phases~size)
	x = sort(unique(size))
	prd = predict(mod,data.frame(size=x),int="conf",level=1-alpha)
	lines(x,prd[,2])
	lines(x,prd[,3])
# Second graph:
#	par(plt=c(0.61,0.98,y1-0.01,y2-0.01),mgp=c(1.5,0.5,0),new=T)
	par(plt=c(0.57,0.905,y1-0.01,y2-0.01),mgp=c(1.5,0.5,0),new=T)
	time = dataslopechangescumbefore$time
#	sel = dataslopechangescumbefore$sel
	sel = time>=1951 & time<1970
	slopes = dataslopechangescumbefore$slopes
# Transform the data:
	tr1 = -0.07311/slopes[132,1]
	tr2 = 0.03581/slopes[132,2]
	slopes[,c(1,3)] = tr1*slopes[,c(1,3)]
	slopes[,c(2,4)] = tr2*slopes[,c(2,4)]
# The western slopes:
	upper = slopes[sel,1]+slopes[sel,3]
	lower = slopes[sel,1]-slopes[sel,3]
#	plot(time[sel],slopes[sel,1],type="l",col="blue",xlab="year",ylab="estimated slopes",axes=T,ylim=c(-0.1,0.15))
	plot(time[sel],slopes[sel,1],type="l",col="blue",xlab="year",ylab="estimated slopes",axes=T,ylim=c(-0.1,0.1),xlim=c(1950,1970))
	polygon(c(time[sel],rev(time[sel])),c(lower,rev(upper)),col=rgb(0,0,1,0.5),border=NA)
# The eastern slopes:
	upper = slopes[sel,2]+slopes[sel,4]
	lower = slopes[sel,2]-slopes[sel,4]
	points(time[sel],slopes[sel,2],type="l",col="red")
	polygon(c(time[sel],rev(time[sel])),c(lower,rev(upper)),col=rgb(1,0,0,0.5),border=NA)
	abline(h=0,lty=2)
#	abline(v=time[132])
#	abline(h=slopes[132,1])
#	abline(h=slopes[132,2])
	par(new=T)
	sel = time>=1956 & time<1967
#	plot(time[sel],abs(slopes[sel,1])/slopes[sel,2],type="n",xlim=c(1951,2008),ylim=c(0.34,2),ann=F,axes=F)
	plot(time[sel],abs(slopes[sel,1])/slopes[sel,2],type="n",xlim=c(1950,1970),ylim=c(-1,3),ann=F,axes=F)
	axis(4)
	mtext("western over eastern speed ratio",4,1.5)
# The speed ratio with its confidence interval:
	alpha = 0.05
	B = 10000
	slopes[,3] = slopes[,3]/qnorm(1-alpha/2)
	slopes[,4] = slopes[,4]/qnorm(1-alpha/2)
	calcdistr = function(i)
	{
		tmp = sort(rnorm(B,abs(slopes[i,1]),slopes[i,3])/rnorm(B,slopes[i,2],slopes[i,4]))
		c(mean(tmp),tmp[round(B*c(alpha/2,1-alpha/2))])
	}
	out = NULL
	for(y in (1:length(time))[sel]) out = rbind(out,calcdistr(y))
	points(time[sel],out[,1],type="l")
	points(time[sel],out[,2],type="l",lty=1,lwd=0.5)
	points(time[sel],out[,3],type="l",lty=1,lwd=0.5)
# Write the subfigure letters:
	par(plt=c(0,0.05,0.88,0.93),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(5,5,"A",font=2)
	par(plt=c(0.465,0.515,0.88,0.93),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(5,5,"B",font=2)
}
