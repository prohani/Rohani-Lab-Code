phaseplot2 = function(state="New York",data=pertussis,from=1951,to=1963,lower=3.5,upper=4.5,pad=128)
{
# Set the values of the time selection if needed:
#	if(missing(from)) from = floor(min(data$time))
#	if(missing(to)) to = ceiling(max(data$time))
	phases = NULL
	states = unique(selectstates(data)$state)
	for(i in states)
	{
		phases = rbind(phases,transfphase(waveletfilter(waveletanalysis(i,from,to,data,F,pad=pad),lower,upper)$phase_ts))
	}
	times = unique(subset(data,time>=from & time<=to)$time)
	par(mgp=c(1.5,0.5,0))
	plot(times,phases[1,],type="l",xlab="year",ylab="phase angle (radians)",col="grey",ylim=range(as.vector(phases),na.rm=T))
	for(i in 2:length(states)) points(times,phases[i,],type="l",col="grey")
	points(times,phases[which(states==state),],type="l",col="red")
	points(times,phases[which(states=="Colorado"),],type="l",col="blue")
	points(times,apply(phases,2,mean,na.rm=T),type="l")

# Perform the linear regression:
#	times = unique(subset(data,time>=from & time<=to)$time)
#	mod = lm(as.vector(t(phases))~rep(times,49))
#	abline(mod)
}
