figureS4 = function(data=selectstates(pertussis))
# width=5, height=2.5
{
	x1 = 0.08
	x4 = 0.78
	x5 = 0.88
	x6 = 0.91
	int = 0.01
	y1 = 0.18
	y2 = 0.96
	foo = (x4-x1-int)
	x2 = x1 + 2*foo/3
	x3 = x2 + int
# The function laglong:
	laglong = function(from,to)
	{
		states = unique(data$state)
		nbstates = length(states)
# Time selection:
		sel = unique(data$time)>=from & unique(data$time)<to
		cases = matrix(data$count,ncol=nbstates)[sel,]
# The time vector:
		thetime = unique(data$time)[sel]
# Rank the states according to their longitude:
		X = centroids[states,"X"]
		orderedstates = states[order(X)]
		cases = cases[,order(X)]
		nbtime = length(thetime)
		themin = matrix(rep(apply(cases,2,min),nbtime),nrow=nbtime,byrow=T)
		themax = matrix(rep(apply(cases,2,max),nbtime),nrow=nbtime,byrow=T)
		cases = (cases-themin)/themax
		image(thetime,1:nbstates,cases,xlab="year",ylab="state",col=rev(heat.colors(100)),axes=F,ann=F)
# Gives the order of the states as an output:
		orderedstates
	}
# The graph:
# First time period:
	opar = par(plt=c(x1,x2,y1,y2),mgp=c(1.5,0.5,0))
	laglong(1951,1963)
	axis(1); axis(2); box(); mtext("                             year",1,1.5); mtext("state",2,1.5)
# Second time period:
	par(plt=c(x3,x4,y1,y2),mgp=c(1.5,0.5,0),new=T)
	orderedstates = laglong(2002,2008)	
	axis(1,c(2003,2005,2007)); axis(4); box(); mtext("state",4,1.5)
# Plot the scale:
	par(plt=c(x5,x6,y1,y2),mgp=c(1.5,0.5,0),new=T)
	colrange = seq(0,1,length=100)
	scalecol = matrix(rep(colrange,25),ncol=25)
	image(1:25,colrange,t(scalecol),col=rev(heat.colors(100)),axes=F,ann=F)
	box(); axis(4); mtext("relative number of cases",4,1.5)
# Back to the initial graph parameter values:
	par(opar)
# Show the state names:
	orderedstates
}
