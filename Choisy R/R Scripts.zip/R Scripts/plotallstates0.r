plotallstates = function(data=selectstates(pertussis),pop=selectstates(popsize),
	from,to,transfmat='log',transfts)
### Il faut sélectionner la bonne période de temps pour les tailles de populations.
### un peu comme il a été fait pour les CCS.
{
	require(Hmisc)
# Read the vaccine coverage from the current directory file and the birth rates:
	vacccov = read.table('pertussis vaccine coverage.dat',header=T)
	births = read.table('birth rates.dat',header=T)
# Set the values of the time selection if needed:
	if(missing(from)) from = floor(min(data$time))
	if(missing(to)) to = ceiling(max(data$time))
# Select the data to plot:
	data = subset(data,time>=from & time<=to)
	pop = subset(pop,year>=from & year<=to)
	birhts = subset(births,year>=from & year<=to)
# Sort the 2 datasets so their state names match:
	pop = pop[order(pop$state),] ; pop = pop[order(pop$year),]
	data = data[order(data$time),] ; data = data[order(data$state),]
# Save the states names and
# order the data dataframe according the size of the states:
	thenames = unique(pop$state)
	pop = matrix(pop$size,nrow=length(thenames))
	thesum = apply(pop,1,sum)
	thesum2 = rep(rank(thesum),
		rep(length(unique(data$time)),
			length(unique(data$state))))
	data = data[order(thesum2),]
# Save the times and the time series of the largest state and transform it:
# Instead of the largest state, we can consider the sum of the number of cases:
	thetime = unique(data$time)
#	timeseries = idata$count[data$state==tail(data$state,1)]
	timeseries = as.vector(tapply(data$count,data$time,sum))
	if(!missing(transfts))
	{	
		if(transfts=='log') timeseries = log(timeseries+1)
		if(transfts=='sqrt') timeseries = sqrt(timeseries)
	}
# Set the graphic and device parameters:
	parplt = c(0.14,0.88,0.2,0.65)
	par(plt=parplt,mgp=c(1.5,0.5,0))
# Create the matrix, transform and plot it:	
	data = matrix(data$count,ncol=length(thenames))
	nbcol = ncol(data)
	if(transfmat=='log') data = log(data+1)
	if(transfmat=='sqrt') data = sqrt(data)
	image(x=thetime,y=1:nbcol,z=data,col=rev(heat.colors(100)),axes=F,xlab="year",ylab="state")
	theticks = c(nbcol,seq(nbcol+1,1,by=-10)[-1],1)
	axis(1)
	axis(2,at=theticks,labels=as.character(rev(theticks)))
	box()
	abline(v=1965,lty=2)#,col="blue")
#	abline(v=1973,lty=2,col="red")
# Plot the time series:
	parplt[3]=0.65
	parplt[4]=0.85
	par(plt=parplt,new='T')
# First the vaccine coverage:
	vacccov = subset(vacccov,year>=from & year<=to)
	attach(vacccov)
	plot(year,coverage,axes=F,type="n",xlim=range(thetime),xaxs='i',
		xlab="",ylab="")
	for(i in 1:length(unique(source)))
		points(year[source==i],
			coverage[source==i],type="l",col="red")
	abline(v=1965,lty=2)#,col="blue")
#	abline(v=1973,lty=2,col="red")
	detach()
	box()
	mgp.axis(4,col="red",col.axis="red",mgp=c(1.5,0.2,0))
	mtext("vaccine coverage",4,1,col="red")

	par(new=T)
	plot(births$year,births$rate,type="l",col="blue",ann=F,axes=F,xaxs="i")

# And second the number of cases:
	par(new=T)
	plot(thetime,timeseries,axes=F,xlab="",type="l",ylab="",xaxs='i')
	if(missing(transfts)) title(ylab="pertussis cases")
	else
	{
		if(transfts=='log') title(ylab="Log(cases+1)")
		if(transfts=='sqrt') title(ylab="Sqrt(cases)")
	}
	axis(2)
# Show the names of the states from decreasing population size:
	cat(paste("\n\tStates ranked according to population size\n\nPeriod: ",from,"-",to,"\n\n"))
	print(thenames[order(-thesum)]) ; cat("\n")
}
