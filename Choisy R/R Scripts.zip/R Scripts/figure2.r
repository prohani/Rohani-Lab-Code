figure2 = function(disease=selectstates(pertussis),pop=selectstates(popsize),
	from=1951,mid=1963,to=2008,pdf=F,graph=T,fact=1000)
# width = 5, height = 4.5
{
# The graph parameters:
	opar = par()
# For height=4.5:
#	x1 = 0.15
#	x2 = 0.52
#	x3 = 0.61
#	x4 = 0.98
#	y1 = 0.12
#	y2 = 0.49
#	y3 = 0.64
#	y4 = 0.96
# For height=4.75: 
	x1 = 0.15
	x2 = 0.52
	x3 = 0.61
	x4 = 0.98
	y1 = 0.11
	y2 = 0.52
	y3 = 0.66
	y4 = 0.96
#	tr = 0.09
	tr = -0.164
# First graph (CCS):
	par(plt=c(x1,x2,y3,y4),mgp=c(1.5,0.5,0))
	pop1 = subset(pop,year>=from & year<mid)
	pop2 = subset(pop,year>=mid & year<to)
	disease1 = subset(disease,time>=from & time<mid)
	disease2 = subset(disease,time>=mid & time<to)
	out1 = ccs1(disease=selectstates(disease1),pop=selectstates(pop1),graph=F)
	out2 = ccs1(disease=selectstates(disease2),pop=selectstates(pop2),graph=F)
	pop1 = out1$pop
	pop2 = out2$pop
	fadeout1 = out1$fadeout
	fadeout2 = out2$fadeout
	param1 = out1$param
	param2 = out2$param
	the.x1 = seq(min(pop1),max(pop1),length=100)
	the.x2 = seq(min(pop2),max(pop2),length=100)
	the.y1 = param1[1]*exp(param1[2]*the.x1)
	the.y2 = param2[1]*exp(param2[2]*the.x2)
	plot(c(pop1,pop2)/fact,c(fadeout1,fadeout2),type="n",
		xlab=paste("population size x",fact,sep=""),
		ylab="with zero notification",axes=F)
	axis(1); axis(2)
	mtext("proportion of months",2,2.5)
	points(pop1/fact,fadeout1,col="red")
	points(pop2/fact,fadeout2,col="blue")
	points(the.x1/fact,the.y1,type='l',col="red")
	points(the.x2/fact,the.y2,type='l',col="blue")
	abline(v=out1$CCS/1000,lty=2,col="red")
	abline(v=out2$CCS/1000,lty=2,col="blue")
	legend("topright",legend=c(paste(from,"-",mid-1,"      ",sep=""),
		paste(mid,"-",to-1,"      ",sep="")),col=c("red","blue"),
		text.col=c("red","blue"),bg="white",lty=1,box.col="white")
# Second graph (Sncf):
	par(plt=c(x3,x4,y3,y4),mgp=c(1.5,0.5,0),new=T)
	corrdistance2(out=datacorrdistance2_1962)
# Third graph (main period before):
	par(plt=c(x2-0.21+tr,x2-0.04+tr,y1,y2),mgp=c(1.5,0.5,0),new=T)
	out = datamainperiod1nopad_before1963
	spectrum = out$spectrum
	spectrum = spectrum/out$variance%*%t(rep(1,ncol(spectrum)))
	nbstates = nrow(spectrum)
	theticks = c(nbstates,seq(nbstates+1,1,by=-10)[-1],1)
#	spectrum = spectrum^0.3
	image(seq(0.1,out$upperP,length=ncol(spectrum)),1:nbstates,t(spectrum[nbstates:1,]),
		col=rev(heat.colors(100)),xlab="period (years)",ylab="",axes=F)
	mtext(paste(out$from,"-",out$to-1,sep=""),3,0.3)
	axis(4,at=theticks,labels=as.character(rev(theticks)))
	axis(1); box()
	abline(v=1,lty=2)
	abline(v=4,lty=2)
# The scale of the third graph:
	par(plt=c(x2-0.24+tr,x2-0.22+tr,y1,y2),new=T)
	colrange = seq(min(spectrum),max(spectrum),length=100)
	scalecol = matrix(rep(colrange,25),ncol=25)
	image(1:25,colrange,t(scalecol),col=rev(heat.colors(100)),ann=F,axes=F)
	axis(2)
	mtext("global power",2,line=1.5); box()
# Fourth graph (main period after):
	par(plt=c(x3+tr,x3+0.17+tr,y1,y2),mgp=c(1.5,0.5,0),new=T)
	out = datamainperiod1nopad_after1963
	spectrum = out$spectrum
	spectrum = spectrum/out$variance%*%t(rep(1,ncol(spectrum)))
	nbstates = nrow(spectrum)
	theticks = c(nbstates,seq(nbstates+1,1,by=-10)[-1],1)
#	spectrum = spectrum^0.3
	image(seq(0.1,out$upperP,length=ncol(spectrum)),1:nbstates,t(spectrum[nbstates:1,]),
		col=rev(heat.colors(100)),xlab="period (years)",ylab="state",axes=F)
	mtext(paste(out$from,"-",out$to-1,sep=""),3,0.3)
	axis(2,at=theticks,labels=as.character(rev(theticks)))
	axis(1); box()
	abline(v=1,lty=2)
	abline(v=4,lty=2)
# The scale of the fourth graph:
	par(plt=c(x3+0.18+tr,x3+0.2+tr,y1,y2),new=T)
	colrange = seq(min(spectrum),max(spectrum),length=100)
	scalecol = matrix(rep(colrange,25),ncol=25)
	image(1:25,colrange,t(scalecol),col=rev(heat.colors(100)),ann=F,axes=F)
	axis(4)
	mtext("global power",4,line=1.5); box()
# Write the subfigure letters:
	par(plt=c(0,0.06,0.94,0.99),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(5,5,"A",font=2)
	par(plt=c(0.5,0.55,0.94,0.99),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(5,5,"B",font=2)
#	par(plt=c(0.18+tr,0.23+tr,0.48,0.53),new=T)
	par(plt=c(0,0.06,0.48,0.53),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(5,5,"C",font=2)
# Restaure the initial graph parameters:
	par(opar)
}
