figure1 = function(data=selectstates(pertussis),pop=selectstates(popsize),
	from,to,transfmat='log',transfts,object=datawaveletallstatesnopad)
# width = 4.5, height = 4.5
{
# For customizing the margin axes appropriately.
	require(Hmisc)
# Read the vaccine coverage from the current directory file and the birth rates:
	vacccov = read.table('pertussis vaccine coverage.dat',header=T)
	births = read.table('birth rates.dat',header=T)
# Set the values of the time selection if needed:
	if(missing(from)) from = floor(min(data$time))
	if(missing(to)) to = ceiling(max(data$time))
# Select the data to plot:
	data = subset(data,time>=from & time<to)
	pop = subset(pop,year>=from & year<to)
	births = subset(births,year>=from & year<to)
# Sort the 2 datasets so their state names match:
	pop = pop[order(pop$state),]; pop = pop[order(pop$year),]
	data = data[order(data$time),]; data = data[order(data$state),]
# Save the states names and
# order the data dataframe according the size of the states:
	thenames = unique(pop$state)
	pop0 = pop
	pop = matrix(pop$size,nrow=length(thenames))
	thesum = apply(pop,1,sum)
	thesum2 = rep(rank(thesum),
		rep(length(unique(data$time)),
			length(unique(data$state))))
	data = data[order(thesum2),]
# Save the times and the time series of the largest state and transform it:
# Instead of the largest state, we can consider the sum of the number of cases:
	thetime = unique(data$time)
#	timeseries = data$count[data$state==tail(data$state,1)]
	timeseries = as.vector(tapply(data$count,data$time,sum))
	if(!missing(transfts))
	{	
		if(transfts=='log') timeseries = log10(timeseries+1)
		if(transfts=='sqrt') timeseries = sqrt(timeseries)
	}
# Set the graphic and device parameters:
	opar = par()
	xmin = 0.12 
	xmax = 0.85
	ymin = 0.1
	ymax = 0.95
	parplt = c(xmin,xmax,ymin,0.43)
	par(plt=parplt,mgp=c(1.5,0.5,0))
# Plot the averaged wavelet local power spectrum:
	time = object$time
	period = object$period
	power = object$power
	themax = object$themax
	themax2 = object$themax2
	powert = power^0.3
	image(time,period,powert,xlab="time (year)",ylab="period (year)",axes=F,col=rev(heat.colors    (10)))
	points(time,sum(range(period))-themax,type="l",lty=2,col="black")
	points(time,sum(range(period))-themax2,type="l",lty=2,col="black")
	axis(1,pretty(time))
	tmp = range(period)
	axis(2,rev(sum(tmp)-pretty(tmp)),as.character(rev(pretty(period))))
	box()
# Plot the scale of the local wavelet power spectrum:
	par(plt=c(0.86,0.89,ymin,0.43),new=T)
	colrange = seq(min(powert),max(powert),length=10)
	scalecol = matrix(rep(colrange,25),ncol=25)
	image(1:25,colrange,t(scalecol),col=rev(heat.colors(10)),ann=F,axes=F)
	axis(4,pretty(range(powert)),as.character(round(pretty(range(powert))^(1/0.3))))
	mtext("averaged local power",4,line=1.5); box()
# Create the spatial matrix, transform and plot it:	
	par(plt=c(xmin,xmax,0.44,0.77),new=T)
	data = matrix(data$count,ncol=length(thenames))
	nbcol = ncol(data)
	if(transfmat=='log') data = log10(data+1)
	if(transfmat=='sqrt') data = sqrt(data)
	image(x=thetime,y=1:nbcol,z=data,col=rev(heat.colors(100)),axes=F,xlab="",ylab="state")
	theticks = c(nbcol,seq(nbcol+1,1,by=-10)[-1],1)
	axis(2,at=theticks,labels=as.character(rev(theticks)))
	box()
# Plot the scale of spatial matrix:
	par(plt=c(0.86,0.89,0.44,0.77),new=T)
	colrange = seq(min(data),max(data),length=100)
	scalecol = matrix(rep(colrange,25),ncol=25)
	image(1:25,colrange,t(scalecol),col=rev(heat.colors(100)),axes=F,ann=F)
	box(); axis(4)
	if(transfmat=="log") mtext("log(pertussis cases+1)",4,1.5)
	else if(transfmat=="sqrt") mtext("sqrt(pertussis cases)",2,1.5)
	else mtext("pertussis cases",2,1.5)
# Plot the time series:
	parplt[1:2] = c(xmin,xmax)
	parplt[3] = 0.78
	parplt[4] = ymax
	par(plt=parplt,new='T')
	plot(thetime,timeseries,axes=F,xlab="",type="l",ylab="",xaxs='i',col="black")
	if(missing(transfts)) title(ylab="pertussis cases")
	else
	{
		if(transfts=='log') title(ylab="Log(cases+1)")
		if(transfts=='sqrt') title(ylab="Sqrt(cases)")
	}
	polygon(c(1951,1963,1963,1951),c(-1000,-1000,8000,8000),col=rgb(1,0,0,0.1),border=NULL)
	polygon(c(2002,2008,2008,2002),c(-1000,-1000,8000,8000),col=rgb(0,0,1,0.1),border=NULL)
	axis(2); box()
# Write the subfigure letters:
	par(plt=c(0.001,0.06,0.38,0.43),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(4,5,"C",font=2)
	par(plt=c(0.001,0.06,0.72,0.77),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(4,5,"B",font=2)
	par(plt=c(0.001,0.06,ymax-0.05,ymax),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(4,5,"A",font=2)
# Show the names of the states from decreasing population size:
	cat(paste("\n\tStates ranked according to population size\n\nPeriod: ",from,"-",to,"\n\n"))
	print(thenames[order(-thesum)]) ; cat("\n")
	par(opar)
}
