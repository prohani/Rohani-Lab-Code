ccsplot = function(x,y,fact,pdf)
{
# Plot the graph:
	pop = x$pop
	par(mgp=c(1.5,0.5,0))
	plot(pop/fact,x$fadeout,
		xlab=paste("population size x",fact,sep=""),
		ylab="proportion of months with no notification",axes=F)
	axis(1)
	axis(2)
# Adding the regression curve:
	param = x$param
	the.x = seq(min(pop),max(pop),length=100)
	the.y = param[1]*exp(param[2]*the.x)
	points(the.x/fact,the.y,type='l')
}
