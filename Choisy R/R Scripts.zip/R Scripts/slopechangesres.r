slopechangesres = function(data=pertussis,from,to,lower=3.5,upper=4.5,mtype="smooth",alpha=0.05,pad=128,cum=F,rev=F)
{
# Set the values of the time selection if needed:
	if(missing(from)) from = floor(min(data$time))
	if(missing(to)) to = ceiling(max(data$time))
	states = unique(selectstates(data)$state)
	nbstates = length(states)
# Calculate and linearly transform the phases for all the states:
#	phases = NULL
#	for(i in states)
#		phases = cbind(phases,transfphase(waveletfilter(waveletanalysis(i,data=data,plot=F,pad=pad),lower,upper)$phase_ts))
## Take the residuals of the phases:
#	phases = phases - apply(phases,1,mean,na.rm=T)
# Make the latitude and longitude matrices:
	X = centroids[states,"X"]
	Y = centroids[states,"Y"]
	thelength = length(unique(data$time))
# Function that does the regression lines:
	if(cum)
	{
		if(rev)
			reg = function(y)
			{
				thresh = -100
				phases1 = as.vector(phases[y:thelength,X<=thresh])
				phases2 = as.vector(phases[y:thelength,X>thresh])
				X1 = rep(X[X<=thresh],each=thelength-y+1)
				X2 = rep(X[X>thresh],each=thelength-y+1)
				reg1 = lm(phases1~X1)
				reg2 = lm(phases2~X2)
				c(coef(reg1)[2],coef(reg2)[2],
					summary(reg1)$coef[2,2],summary(reg2)$coef[2,2],
					summary(reg1)$coef[2,4],summary(reg2)$coef[2,4])
			}
		else
			reg = function(y)
			{
				thresh = -100
				phases1 = as.vector(phases[1:y,X<=thresh])
				phases2 = as.vector(phases[1:y,X>thresh])
				X1 = rep(X[X<=thresh],each=y)
				X2 = rep(X[X>thresh],each=y)
				reg1 = lm(phases1~X1)
				reg2 = lm(phases2~X2)
				c(coef(reg1)[2],coef(reg2)[2],
					summary(reg1)$coef[2,2],summary(reg2)$coef[2,2],
					summary(reg1)$coef[2,4],summary(reg2)$coef[2,4])
			}
	}
	else
		reg = function(y)
		{
			thresh = -100
			phases1 = phases[y,X<=thresh]
			phases2 = phases[y,X>thresh]
			X1 = X[X<=thresh]
			X2 = X[X>thresh]
			Y1 = Y[X<=thresh]
			Y2 = Y[X>thresh]
			reg1 = lm(phases1~Y1)
			reg2 = lm(phases2~Y2)
			res1 = phases1-(coef(reg1)[1]+coef(reg1)[2]*Y1)			
			res2 = phases2-(coef(reg2)[1]+coef(reg2)[2]*Y2)			
			reg1 = lm(res1~X1)
			reg2 = lm(res2~X2)
#			reg1 = lm(phases1~X1)
#			reg2 = lm(phases2~X2)
			c(coef(reg1)[2],coef(reg2)[2],
				summary(reg1)$coef[2,2],summary(reg2)$coef[2,2],
				summary(reg1)$coef[2,4],summary(reg2)$coef[2,4])
		}
	slopes = NULL
	for(i in 1:nrow(phases)) slopes = rbind(slopes,reg(i))
	slopes[,3:4] = slopes[,3:4]*qnorm(1-alpha/2)
# The graph:
	oplt = par('plt')
	oplt[1] = (1-oplt[2]+oplt[1])/2
	oplt[2] = 1 - oplt[1]
	opar = par(plt=oplt,mgp=c(1.5,0.5,0))
	time = unique(data$time)
	sel = time>=from & time<=to
	upper = slopes[sel,1]+slopes[sel,3]
	lower = slopes[sel,1]-slopes[sel,3]
	plot(time[sel],slopes[sel,1],type="l",col="blue",xlab="year",ylab="estimated slopes",axes=T,ylim=c(-1,1))
	polygon(c(time[sel],rev(time[sel])),c(lower,rev(upper)),col=rgb(0,0,1,0.5),border=NA)
#	box(); axis(1); axis(2,col="blue",col.ticks="blue",col.axis="blue")
#	mtext("eastern slope",2,1.5,col="blue")
#	par(new=T)
	upper = slopes[sel,2]+slopes[sel,4]
	lower = slopes[sel,2]-slopes[sel,4]
#	plot(time[sel],slopes[sel,2],type="l",col="red",ann=F,axes=F,ylim=range(c(upper,lower)))
	points(time[sel],slopes[sel,2],type="l",col="red")
	polygon(c(time[sel],rev(time[sel])),c(lower,rev(upper)),col=rgb(1,0,0,0.5),border=NA)
#	axis(4,col="red",col.ticks="red",col.axis="red")
#	mtext("western slope",4,1.5,col="red")
#	points(time[sel],slopes[sel,5],col="blue",lwd=2,lty=1,type="l")
#	points(time[sel],slopes[sel,6],col="red",lwd=2,lty=1,type="l")
	par(opar)
	slopes
}
