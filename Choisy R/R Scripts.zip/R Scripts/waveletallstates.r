waveletallstates = function(from,to,data=selectstates(pertussis),transf="sqrt",centered=T,
	dt=1/12,lowerPeriod=0.1,upperPeriod=6.1,ns=100,pad=128,dj=1/100,test=11,pvalue=0.05,ps=1,amp=10)
# This function performs a wavelet decomposition for all the states in a roll over a specified time range.
# lowerPF and upperPF are the periods between which the signal is filtered.
# lowerPeriod and upperPeriod define the period range over which to perform the analysis.
# dt:		sampling rate (monthly data: dt=1/12)
# ns:		number of bootstrap samples.
# dj:		frequency resolution (i.e. number of sub-octaves)
# test: 	the test to use for testing significativity (test=11 : comparaison with a red noise)
# pvalue:	threshold significance level for the test
# ps:		other bootstrap parameter
# amp:		test parameter
{
# Selecting the state and time range to analyse:
	if(missing(from)) from = round(min(data$time))
	if(missing(to)) to = round(max(data$time))
	data = subset(data,time>=from & time<to)
# Performing the wavelet transform.
	thestates = unique(data$state)
	out = vector("list",length(thestates))
	ind = 0
	for(statename in thestates)
	{
		show(statename)
		ind = ind+1
		ys = unlist(subset(data,state==statename,select=count))
# Transforming the data:
		if(transf=="sqrt") ys = sqrt(ys)
		if(transf=="log") ys = log(ys+1)
		if(centered) ys = (ys-mean(ys))/sd(ys)
		out[[ind]] = wavelettransform(ys,dt,dj,lowerPeriod,upperPeriod,pad)
	}
# Drawing the plot:
	a = waveletallstatesplot(out,from,to,pvalue,transf,centered,test,ns,ps,amp)
# Giving the output:
	a
}
