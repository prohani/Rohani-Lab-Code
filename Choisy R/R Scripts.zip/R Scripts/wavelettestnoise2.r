wavelettestnoise2 = function(y,lag,dt,scale,pvalue=0.05,fourier_factor)
# This is the new version of wavelettestnoise and the one that should be used. As
# wavelettestnoise, this function gives the p-values by comparing the signal y to
# a white (lag=0) or red(lag=1) noise that have the same autocorrelation structure.
# Contrary to wavelettestnoise, this function does not gives the p-values for the
# signal filtered over a band, which is pointless here.
#------------ INPUTS
# y		: input time series
# lag		: lag!=0 for a test with a red noise, the AR(1) parameter will be computed
# dt		: observation time step
# dj		: frequency resolution (ie number of sub-octaves)
# scale		: vector of the wavelet scale employed during the computation
#
#------------ OUTPUT
# pv_scalog	: matrice of the p-values of the power wavelet at the level at the pvalue level.
# pv_spec	: pvalue significance level for the average wavelet spectrum of y.
{
	n = length(y)
	alpha = 1-pvalue
# In case of red noise, we calculate the coefficient of the AR(1) process (equation 15).
	if(lag!=0) lag = ar.ols(y,order=1,demean=F)$ar[1]
	period = scale*fourier_factor
# Degrees of freedom with no smoothing:
	dof = 2
	dofmin = dof
# Reconstruction factor:
	Cdelta = 0.776
# Time-decorrelation factor:
	gamma_fac = 2.32
# Scale-decorrelation factor:
	dj0 = 0.6
# Normalized frequency:
	freq = dt/period
# Calculating the theoretical FFT (equation 16):
# Note that this spectrum has been normalized by N/(2*var_y). This means that this
# spectrum can be compared only to a power which has also been normalized.
	fft_theor = (1-lag^2)/(1-2*lag*cos(freq*2*pi)+lag^2)
# Normalization:
#	fft_theor = var_y*fft_theor @@@@@ Je pense que cette ligne est inutile.
# From equation 18:
	pv_scalog = fft_theor*qchisq(alpha,dof)/dof
# significance level associated to the time-averaged spectrum (section 5a)
	dof = n - scale
	dof[dof<1] = 1
# Equation 23:
	dof = dofmin*sqrt(1+(dof*dt/gamma_fac/scale)^2)
	dof[dof<dofmin] = dofmin
	pv_spec = fft_theor*qchisq(alpha,dof)/dof
# Gives the output:
	list(pv_scalog=pv_scalog,pv_spec=pv_spec)
}
