phasedistanceref = function(ref="New York",from=1951,to=1963,lower=3.5,upper=4.5,data=selectstates(pertussis))
{
# Set the values of the time selection if needed:
#	if(missing(from)) from = floor(min(data$time))
#	if(missing(to)) to = ceiling(max(data$time))
# Select the data to plot:
	data = subset(data,time>=from & time<=to)
# Calculate the phases with and the distances to the reference state:
#	phaseref = waveletanalysis(ref,from,to,data,F,lower,upper)$out2$phase_tsi
	phaseref = waveletfilter(waveletanalysis(ref,from,to,data,F),lower,upper)$phase_ts
	phases = distances = NULL
	for(i in unique(data$state))
	{
		distances = c(distances,distance(ref,i))
#		phase = waveletanalysis(i,from,to,data,F,lower,upper)$out2$phase_ts
		phase = waveletfilter(waveletanalysis(i,from,to,data,F),lower,upper)$phase_ts
		tmp = phasediff(phaseref,phase)
		tmp[which(tmp<(-pi))] = tmp[which(tmp<(-pi))]+2*pi
		tmp[which(tmp>pi)] = tmp[which(tmp>pi)]-2*pi
		phases = c(phases,tmp)
	}
	plot(jitter(rep(distances,each=144)),phases)
}
