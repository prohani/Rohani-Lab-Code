speed = function(X1=-120,X2=-70,Y=40,data=dataphaseplot4,alpha=0.05)
# This function calculates the longitudinal speed of propagation at a given latitude (Y).
{
# Calculates the number of km by longitude degree at the Y latitude:
	lambda1 = X1*pi/180
	lambda2 = X2*pi/180
	delta = lambda1-lambda2
	phi1 = phi2 = Y*pi/180
	radius = 6378
	distance = radius*atan(sqrt((cos(phi2)*sin(delta))^2+
		(cos(phi1)*sin(phi2)-sin(phi1)*cos(phi2)*cos(delta))^2)/
		(sin(phi1)*sin(phi2)+cos(phi1)*cos(phi2)*cos(delta)))
	distance = distance/abs(X1-X2)
# Calculates the linear regressions of the phase angles as a function of longitude,
# for the western and eastern parts:
	y = cbind(data$X,data$phases)
	thresh = -100
	x1 = y[y[,1]<=thresh,1]
	y1 = y[y[,1]<=thresh,2]
	x2 = y[y[,1]>thresh,1]
	y2 = y[y[,1]>thresh,2]
	mod1 = lm(y1~x1)
	mod2 = lm(y2~x2)
# Extracts the slopes and their standard errors:
	slope1 = summary(mod1)$coef[2,1]
	slope2 = summary(mod2)$coef[2,1]
	slope1b = qnorm(1-alpha/2)*summary(mod1)$coef[2,2]
	slope2b = qnorm(1-alpha/2)*summary(mod2)$coef[2,2]
# Transforms the slopes into speeds and confidence intervals:
	speed1 = (2*pi*distance)/(4*abs(slope1))
	speed2 = (2*pi*distance)/(4*abs(slope2))
	speedmin1 = (2*pi*distance)/(4*abs(slope1+slope1b))
	speedmin2 = (2*pi*distance)/(4*abs(slope2+slope2b))
	speedmax1 = (2*pi*distance)/(4*abs(slope1-slope1b))
	speedmax2 = (2*pi*distance)/(4*abs(slope2-slope2b))
# Gives the output (km/month):
	c(speed1,speedmin1,speedmax1,speed2,speedmin2,speedmax2)/12
}
