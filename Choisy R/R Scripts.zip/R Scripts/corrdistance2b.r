corrdistance2b = function(from1,from2,to1,to2,data=selectstates(pertussis),out=datacorrdistance2b_64_94)
# This function plots the spatial correlation function for two adjacent time periods using Sncf.
{
	require(ncf)
	if(is.null(out))
	{
		states = unique(data$state)
		coord = centroids[states,]
# Cuts the dataset into 2 adjacent datasets:
		data1 = subset(data,time>=from1 & time<to1)
		data2 = subset(data,time>=from2 & time<to2)
# Calculates the spatial correlations:
		data1 = t(matrix(data1$count,ncol=length(states)))
		data2 = t(matrix(data2$count,ncol=length(states)))
		out1 = Sncf(coord$X,coord$Y,data1,latlon=T,quiet=T)
		out2 = Sncf(coord$X,coord$Y,data2,latlon=T,quiet=T)
	}
	else
	{
		out1 = out$out1
		out2 = out$out2
		from1 = out$from1
		from2 = out$from2
		to1 = out$to1
		to2 = out$to2
	}
# Draws the graphs:
	par(mgp=c(1.5,0.5,0))
	plot(out1$real$predicted$x,out1$real$predicted$y,type="l",ylim=c(0,0.8),
		col="red",xlab="distance (km)",ylab="correlation")
	points(out2$real$predicted$x,out2$real$predicted$y,type="l",col="blue")
	abline(h=out1$real$cbar,col="red")
	abline(h=out2$real$cbar,col="blue")
	x1 = out1$boot$boot.summary$predicted$x
	y1l = out1$boot$boot.summary$predicted$y["0.025",]
	y1u = out1$boot$boot.summary$predicted$y["0.975",]
	x2 = out2$boot$boot.summary$predicted$x
	y2l = out2$boot$boot.summary$predicted$y["0.025",]
	y2u = out2$boot$boot.summary$predicted$y["0.975",]
	lines(x1,y1l,lty=2,col="red")
	lines(x2,y2l,lty=2,col="blue")
	lines(x1,y1u,lty=2,col="red")
	lines(x2,y2u,lty=2,col="blue")
	polygon(c(x1,rev(x1)),c(y1l,rev(y1u)),col=rgb(1,0,0,0.1),border=NA)
	polygon(c(x2,rev(x2)),c(y2l,rev(y2u)),col=rgb(0,0,1,0.1),border=NA)
#	title(paste(mid))	# this is preferable to the legend for making a movie:
# Adding the legend:
#	legend("topright",legend=c(paste("period ",from,"-",mid,sep=""),
#		paste("period ",mid+1,"-",to-1,sep="")),col=c("red","blue"),
	legend("topright",legend=c(paste(from1,"-",to1-1,sep=""),
		paste(from2,"-",to2-1,sep="")),col=c("red","blue"),
		text.col=c("red","blue"),bty="n",lty=1)
#		text.col=c("red","blue"),bg="white",lty=1,box.col="white")
	if(is.null(out)) list(out1=out1,out2=out2,from1=from1,from2=from2,to1=to1,to2=to2)
}
