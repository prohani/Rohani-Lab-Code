figureS2a = function()
{
# width = 2.25, height = 2.25
	par(plt=c(0.22,0.98,0.225,0.88),mgp=c(1.5,0.5,0))
	correlation2()
# Write the subfigure letters:
	x = 0.01
	par(plt=c(x,x+0.05,0.88,0.93),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(5,5,"A",font=2)
}
