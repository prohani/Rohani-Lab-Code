distance3 = function(X1=-100,X2=-100,Y1=20,Y2=60)
# This function calculates de distance between two localities from their longitude
# and latitude values and accounting for the rotundity of the earth
{
	lambda1 = X1*pi/180
	lambda2 = X2*pi/180
	delta = lambda1-lambda2
	phi1 = Y1*pi/180
	phi2 = Y2*pi/180
	radius = 6378
	radius*atan(sqrt((cos(phi2)*sin(delta))^2+
		(cos(phi1)*sin(phi2)-sin(phi1)*cos(phi2)*cos(delta))^2)/
		(sin(phi1)*sin(phi2)+cos(phi1)*cos(phi2)*cos(delta)))
}
