slopechangesm1graph = function(data=b)
{
	slopes = data$slopes
	times = data$times
# The graph:
	opar = par(mgp=c(1.5,0.5,0))
# Western slopes:
	upper = slopes[,1]+slopes[,3]
	lower = slopes[,1]-slopes[,3]
	plot(times,slopes[,1],type="l",col="blue",xlab="year",ylab="estimated slopes",axes=T,ylim=c(-0.1,0.3),xlim=c(1960,1970))
	polygon(c(times,rev(times)),c(lower,rev(upper)),col=rgb(0,0,1,0.5),border=NA)
# Eastern slopes:
	upper = slopes[,2]+slopes[,4]
	lower = slopes[,2]-slopes[,4]
	points(times,slopes[,2],type="l",col="red")
	polygon(c(times,rev(times)),c(lower,rev(upper)),col=rgb(1,0,0,0.5),border=NA)
# Back to initial graph parameters:
	par(opar)
}
