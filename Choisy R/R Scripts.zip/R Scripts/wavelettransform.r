wavelettransform = function(y,dt,dj=0.25,lowerPeriod,upperPeriod,pad,ko=6,linear=T)
# This function performs a Morlet wavelet transform of the time series y over the time
# period defined by lowerPeriod and upperPeriod.
#
# Arguments:
# y		: input signal
# dt		: sampling rate
# dj		: frequency resolution (ie number of sub-octaves)
# lowerPeriod	: lower period of the decomposition
# upperPeriod	: upper period of the decomposition
# pad		: in case of zero padding (it must be a power of two)
# ko		: non-dimensional frequency of the Morlet mother wavelet.
#
# Value:
# wave		: wavelet Transform-matrix
# period	: the vector of "Fourier" periods (in time units) that corresponds to the scales
# scale		: the vector of scale indices.
# coi		: the "cone-of-influence", which is a vector of n_y points
# 			that contains the limit of the region where the wavelet
# 			transform is influenced by edge effects
# fourier_factor: the Fourier factor corresponding to the ko argument.
# y, dt, dj, pad, lowP, upP: the values of the arguments used to perform the decomposition.
{
# General parameters:
	fourier_factor = (4*pi)/(ko+sqrt(2+ko^2))
	if(missing(lowerPeriod)) so = 2*dt else so = lowerPeriod/fourier_factor
# Length of the time series before padding:
	n1 = length(y)
# Zero padding:
	if(pad==0)
# Pad with zeros to the nearest power of 2 to N:
	{
		base2 = trunc(log2(n1)+0.49999)
		x = c(y,rep(0,2^(base2+1)-n1))
		pad = length(x)
	}
	if(pad>0)
# Pad with zeros with a specified length of the new time series:
	{
		base2 = log2(pad)
		if (base2%%1) stop('pad must be a power of two')
		else
		{
			if(pad<n1) warning('pad is too low: no padding')
			x = c(y,rep(0,max(0,2^(base2)-n1)))
		}
	}
# Length of the time series after padding:
	n = length(x)
# Creating the vector of scales:
	if(linear)
# Linear repartition of scales:
	{
		fo = min(upperPeriod/fourier_factor,n*dt)
		scale = seq(so,fo,dj)
	}
	else
# Power of 2 repartition of scales:
	{
# The largest possible number of scales:
		largestNumberofScales = trunc((log(n*dt/so)/log(2))/dj)
# The current number of scales:
		currentNumberofScales = trunc((log(upperPeriod/so)/log(2))/dj)
# If upperPeriod is too long
		j1 = min(currentNumberofScales,largestNumberofScales)
		scale = so*2^((0:j1)*dj)
	}
# Creating the vector of angular frequencies (phases) (equation 5):
	k = 1:trunc(n/2)
	k = k*((2*pi)/(n*dt))
	k= c(0,k,-k[floor((n-1)/2):1])
	ventana = length(k)
# Fourier transform of the time series (equation 3):
	f = fft(x)
# Calculating the matrix of wavelet transform:
	wave = NULL
	for(scal in scale)
	{
# The daughter Morlet wavelet for the specified scale (table 1):
		daughter = pi^(-0.25)*(k>0)*exp(-(scal*k-ko)^2/2)
# Normalisation (equation 6):
		daughter = sqrt(scal*k[2]*ventana)*daughter
# Fourier inverse transform (equation 4):
# Note that the FFT of a (complex) Morlet wavelet is real, thus its conjugate is equal to itself.
# Note also that because of the normalization of the FFT in the R fft function, we need to
# divide the result by the length of the fft (see help(fft)).
		wave = rbind(wave,fft(f*daughter,inverse=T)/length(f*daughter))
	}
# Caculating the cone of influence:
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
# Comment calculer le cone d'influence?
	coi = fourier_factor*dt*c(1e-5,1:((n1+1)/2-1),rev((1:(n1/2-1))),1e-5)/sqrt(2)
# Give the output after getting rid of the padded zeros:
	list(wave=wave[,1:n1],scale=scale,coi=coi,fourier_factor=fourier_factor,
		y=y,dt=dt,dj=dj,pad=pad,lowP=lowerPeriod,upP=upperPeriod)
}
