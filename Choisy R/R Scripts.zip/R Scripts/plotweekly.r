plotweekly = function(thestate="Alabama",plot=T)
# This function plots the weekly cases on the 2003-2007 period.
{
	a = read.table('newdata0307.dat',sep='\t')
	names(a) = c("year","week","count","state")
	a = subset(a,state==thestate)
	if(plot)
	{
		par(mgp=c(1.5,0.5,0))
		plot(a$year+a$week/53,a$count,type="l",xlab="time (week)",ylab="pertussis cases")
	}
	else cbind(a$year+a$week/53,a$count)
}
