plotcomparison = function(state="Alabama")
{
	a = par('plt')
	a[1] = (1-a[2]+a[1])/2
	a[2] = 1-a[1]
	par(plt=a,mgp=c(1.5,0.5,0))
	a = plotweekly(state,F)
	b = plotmonthly(state,F)
	plot(a[,1],a[,2],type="l",col="blue",axes=F,ann=F)
	title(main=state)
	box()
	axis(1); mtext("time",1,1.5)
	axis(2,col="blue",col.ticks="blue",col.axis="blue"); mtext("weekly cases",2,1.5,col="blue")
	par(new=T)
	plot(b[,1],b[,2],type="l",axes=F,ann=F,col="red")
	axis(4,col="red",col.ticks="red",col.axis="red"); mtext("monthly cases",4,1.5,col="red")
}
