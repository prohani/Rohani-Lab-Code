figureS6 = function()
# width = 5.5, height = 2.25
{
	x1 = 0.08
	x4 = 0.91
	deltax = 0.355
	x2 = x1+deltax
	x3 = x4-deltax
	y1 = 0.11
	y4 = 0.94
	deltay = 0.34
	y2 = y1+deltay
	y3 = y4-deltay
	y3 = 0.2
	y4 = 0.88

	alpha = 0.01
	ylim = c(-pi,pi)

	crosses = function(x,alpha=0.05)
	{
		confint = function(vect)
		{
			vect = sort(vect)
			thelength = length(vect)
			vect[round(c(thelength*alpha/2,thelength*(1-alpha/2)))]
		}
		a = size[statenames==x]
		b = phases[statenames==x]
		c(mean(a,na.rm=T),confint(a),mean(b,na.rm=T),confint(b))
	}

# First graph:
	par(plt=c(x1,x2,y3,y4),mgp=c(1.5,0.5,0))
	size = datapopeffect1$size
	phases = datapopeffect1$phases
	statenames = datapopeffect1$statenames
	plot(size,phases,xlab="log(population size)",ylab="residual phase angle (radian)",
		ylim=ylim,col=rgb(0,0,0,0.05),pch=19,type="n")
#	points(size[statenames=="New York"],phases[statenames=="New York"],col=rgb(1,0,0,0.05),pch=19)
#	points(size[statenames=="Colorado"],phases[statenames=="Colorado"],col=rgb(0,0,1,0.05),pch=19)
	foo = matrix(unlist(lapply(unique(statenames),function(x)crosses(x))),byrow=T,ncol=6)
	mod = lm(phases~size)
	x = sort(unique(size))
	prd = predict(mod,data.frame(size=x),int="conf",level=1-alpha)
	lines(x,prd[,2],col="red")
	lines(x,prd[,3],col="red")
	segments(foo[,2],foo[,4],foo[,3],foo[,4])
	segments(foo[,1],foo[,5],foo[,1],foo[,6])
	points(foo[,1],foo[,4])
	points(foo[unique(statenames)=="New York",1],foo[unique(statenames)=="New York",4],col=heat.colors(12)[5],pch=20)
	points(foo[unique(statenames)=="New York",1],foo[unique(statenames)=="New York",4])
	points(foo[unique(statenames)=="Colorado",1],foo[unique(statenames)=="Colorado",4],col=heat.colors(12)[11],pch=20)
	points(foo[unique(statenames)=="Colorado",1],foo[unique(statenames)=="Colorado",4])
	mtext("1951-1962",3,0.3,col="red")

# Second graph:
	par(plt=c(x3,x4,y3,y4),mgp=c(1.5,0.5,0),new=T)
	size = datapopeffect2$size
	phases = datapopeffect2$phases
	statenames = datapopeffect2$statenames
	plot(size,phases,xlab="log(population size)",ylab="residual phase angle (radian)",
		ylim=ylim,col=rgb(0,0,0,0.05),pch=19,type="n")
#	points(size[statenames=="New York"],phases[statenames=="New York"],col=rgb(1,0,0,0.05),pch=19)
#	points(size[statenames=="Colorado"],phases[statenames=="Colorado"],col=rgb(0,0,1,0.05),pch=19)
	foo = matrix(unlist(lapply(unique(statenames),function(x)crosses(x))),byrow=T,ncol=6)
	mod = lm(phases~size)
	x = sort(unique(size))
	prd = predict(mod,data.frame(size=x),int="conf",level=1-alpha)
	lines(x,prd[,2],col="blue")
	lines(x,prd[,3],col="blue")
	segments(foo[,2],foo[,4],foo[,3],foo[,4])
	segments(foo[,1],foo[,5],foo[,1],foo[,6])
	points(foo[,1],foo[,4])
	points(foo[unique(statenames)=="New York",1],foo[unique(statenames)=="New York",4],col=heat.colors(12)[5],pch=20)
	points(foo[unique(statenames)=="New York",1],foo[unique(statenames)=="New York",4])
	points(foo[unique(statenames)=="Colorado",1],foo[unique(statenames)=="Colorado",4],col=heat.colors(12)[11],pch=20)
	points(foo[unique(statenames)=="Colorado",1],foo[unique(statenames)=="Colorado",4])
	mtext("2002-2007",3,0.3,col="blue")

# Write the subfigure letters:
	x = 0.04
	y = 0.04
	par(plt=c(x1-x,x1-x+0.05,y4+y,y4+y+0.05),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(5,5,"A",font=2)
	par(plt=c(x3-x,x3-x+0.05,y4+y,y4+y+0.05),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(5,5,"B",font=2)
}
