correlation1 = function(disease=selectstates(pertussis),transf,xlimits,ylimits,eps=0)
# This function cuts the dataset _disease_ into 2 time periods
# defined by _from_, _mid_, and _to_. It then calculates the
# correlation coefficients for each pair of states for the two
# time periods. The histograms of the correlation coefficients
# can be plotted.
{
# Load the needed library:
	require(ecodist)
	par(mgp=c(1.5,0.5,0))
# Transform the data:
	if(!missing(transf))
	{
		if(transf=='log') disease$count = log(disease$count+1)
		if(transf=='sqrt') disease$count = sqrt(disease$count)
	}
	disease1 = disease$count
# Calculate the correlation coefficients:
	nbstates = length(unique(disease$state))
	disease1 = lower(cor(as.data.frame(matrix(disease1,ncol=nbstates))))
	hist(disease1,breaks=100,xlab="correlation coefficient",ylab="number",main="")
# Output:
#	out = list(series1=disease1,series2=disease2,from=from,mid=mid,to=to)
#	if(graph) correlplot(out,xlimits,ylimits,eps)
#	else(out)
}
