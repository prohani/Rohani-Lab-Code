moviesmoothplot = function(data1=prevalenceusa(),data2=selectstates(pertussis),plot=T)
{
	require(maps)
	require(gam)
	require(multicore)
	yparam = 50
# The function that transforms the values into colors:
	colorfct = function(x,min,max)
		which(hist(x,breaks=seq(min,1.05*max,length=101),plot=F)$counts>0)
# The function that draws the graph:
	thegraph = function(time)
	{
		show(time)
# Plot the time series:
		par(plt=c(0.12,0.96,0.7,0.95),mgp=c(1.5,0.5,0))
		plot(data1$time,data1$prev,type="l",xlab="year",ylab="mean prevalence")
		abline(v=time,col="blue")
# Plot the map:
# Selecting the specific time point we analyse here:
		v = smootheddata[[paste(time)]]
		mv = matrix(v,100,yparam)
# Graph parameters:
		plt = c(0.15,1,0.02,NA)
		plt[4] = plt[3]+(plt[2]-plt[1])*ratio
		par(plt=plt,new=T)
# Plotting each state of the map with the good color:
#		show(themin); show(themax); show(min(v)); show(max(v))
#		show(colorset)
#		show(round(100*(min(v)-themin)/(themax-themin)))i
#		show(round(100*(max(v)-themin)/(themax-themin)))
		thecolors = colorset[round(100*(min(v)-themin)/(themax-themin)):round(100*(max(v)-themin)/(themax-themin))]
		plot(themap$x,themap$y,type="n",axes=F,ann=F,ylim=ylim)
		image(x,y,mv,col=thecolors,ann=F,axes=F,add=T)
#		contour(x,y,mv,add=T)
		polygon(c(themap$x,themap$x[1],themap$x[1],-127,-127,-65,-65,themap$x[1],themap$x[1]),
			c(themap$y,themap$y[1],23,23,60,60,23,23,themap$y[1]),col="white",border="white")
		points(themap$x,themap$y,type="l")
# Plot the centroids:
		for(i in states) points(centroids[i,"X"],centroids[i,"Y"],pch=20)
# Adding the month and the year in the top right corner:
		theyear = trunc(time)
		themonth = time-theyear
		text(-68,51,paste(month$name[abs(month$index-themonth)<0.01],theyear),adj=c(1,0.5))
# Plot the scale:
		par(plt=c(0.12,0.15,0.1,0.5),new=T)
		colrange = seq(themin,themax,length=100)
		scalecol = matrix(rep(colrange,25),ncol=25)
		image(1:25,colrange,t(scalecol),col=rev(heat.colors(100)),xlab="",ylab="quadriennal component",axes=F)
		axis(2)
		box()
	}
#############################################################
# Rounding the times:
	show('1')
	data2$time = round(data2$time,2)
# Selecting the time range we want to analyze (this doubled on lines 76-77 for fixing purposes):
#	thetimes = sort(unique(data2$time))#[1:1]
#	data2 = subset(data2,time<=max(thetimes))
#	data1 = subset(data1,time>=1951 & time<=1965)
#	data2 = subset(data2,time>=1951 & time<=1965)
	states = unique(data2$state)
	lower = 3.5; upper = 4.5
#	for(state in states)
#	{
#		show(state)
#		data2[data2$state==state,"count"] =
#			waveletfilter(waveletanalysis(state,data=data2,plot=F),lower,upper)[["filtr_ts"]]
#	}

#	data2[,"count"] = unlist(mclapply(states,function(x){show(x);waveletfilter(waveletanalysis(x,data=data2,plot=F),lower,upper)[["filtr_ts"]]}))
	
#	show('2')
# Selecting the time range we want to analyze:
#	thetimes = sort(unique(data2$time))[1:12]
#	data2 = subset(data2,time<=max(thetimes))
# Smoothing the data:
	x = seq(-125,-67,length=100)
	y = seq(25,50,length=yparam)
	xv = rep(x,yparam)
	yv = rep(y,each=100)
#	if(plot==F)
#	{
#		smootheddata = vector("list",length(thetimes))
#		names(smootheddata) = paste(thetimes)
#		for(time in thetimes)
#		{
#			show(time)
#			data3 = data2[data2$time==time,]
#			counts = data3$count
#			X = centroids[data3$state,"X"]
#			Y = centroids[data3$state,"Y"]
#			regamlolo = gam(counts~lo(X)+lo(Y)+lo(X,Y),family=gaussian)
#			smootheddata[[paste(time)]] = predict(regamlolo,newdata=data.frame(Y=yv,X=xv))
#		}
#	}

	smoothing = function(time)
	{
		show(time)
		data3 = data2[data2$time==time,]
		counts = data3$count
		X = centroids[data3$state,"X"]
		Y = centroids[data3$state,"Y"]
		regamlolo = gam(counts~lo(X)+lo(Y)+lo(X,Y),family=gaussian)
		predict(regamlolo,newdata=data.frame(Y=yv,X=xv))
	}
#	smootheddata = mclapply(thetimes,function(x)smoothing(x))
#	names(smootheddata) = paste(thetimes)

	show('3')
# Calculate the colors:
	colorset = rev(heat.colors(100))
	foo = range(smootheddata)
	themin = foo[1]
	themax = foo[2]
# Graphic parameters:
	themap = map("usa",plot=F)
	end = which(is.na(themap$x))[1]-1
	themap$x = themap$x[1:end]
	themap$y = themap$y[1:end]
	ylim = range(themap$y,na.rm=T)
	ylim[2] = 1.05*ylim[2]
	ratio = 4.5/7
# Months
	month = data.frame(index=round((0.5:11.5)/12,2),name=
		c("January","February","March","April","May","June",
			"July","August","September","October","November","December"))
# Draw the graphics or give the output:
#	if(plot) {for(time in thetimes) thegraph(time)} else smootheddata
	thegraph(1951.04)
}
