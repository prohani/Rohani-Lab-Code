loadpopsize = function(datafile='popsize.dat')
# The original data should be a text file with # of year +1 columns
# and # of state +1 lines. The first line should contains the names
# of the columns: state, 1900, 1901, 1902, etc...
# The data comes from www.census.gov/popest/archives.
{
	data = read.table(datafile,sep="\t")
# Save the names of the states and the times:
	states = as.character(data[-1,1])
	time = as.numeric(data[1,-1])
# Eliminate the first row and the first column
	data = as.vector(as.matrix(data[-1,-1]))
# Re-structure the data into a data frame:
	data = data.frame(
		rep(states,length(time)),
		data,
		rep(time,rep(length(states),length(time))))
# Give the column names of the dataframe:
	names(data) = c("state","size","year")
# Put each column in the right format:
	data$state = as.character(data$state)
	data$year = as.integer(data$year)
# Give the data frame as an output:
	data
}
