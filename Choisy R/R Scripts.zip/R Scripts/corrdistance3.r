corrdistance3 = function(from1=1951,to1=1963,from2=1963,to2=2002,from3=2002,to3=2008,data=selectstates(pertussis),out=datacorrdistance3_1962_2002)
# This function plots the spatial correlation function for two adjacent time periods using Sncf.
{
	require(ncf)
	if(is.null(out))
	{
		states = unique(data$state)
		coord = centroids[states,]
# Set the values of the time selection if needed:
#		if(missing(from)) from = floor(min(data$time))
#		if(missing(to)) to = ceiling(max(data$time))
#		if(missing(mid)) mid = round(mean(c(from,to)))
# Cuts the dataset into 2 adjacent datasets:
		data1 = subset(data,time>=from1 & time<to1)
		data2 = subset(data,time>=from2 & time<to2)
		data3 = subset(data,time>=from3 & time<to3)
# Calculates the spatial correlations:
		data1 = t(matrix(data1$count,ncol=length(states)))
		data2 = t(matrix(data2$count,ncol=length(states)))
		data3 = t(matrix(data3$count,ncol=length(states)))
		out1 = Sncf(coord$X,coord$Y,data1,latlon=T,quiet=T)
		out2 = Sncf(coord$X,coord$Y,data2,latlon=T,quiet=T)
		out3 = Sncf(coord$X,coord$Y,data3,latlon=T,quiet=T)
	}
	else
	{
		out1 = out$out1
		out2 = out$out2
		out3 = out$out3
		from1 = out$from1
		from2 = out$from2
		from3 = out$from3
		to1 = out$to1
		to2 = out$to2
		to3 = out$to3
	}
# Draws the graphs:
	par(mgp=c(1.5,0.5,0))
	plot(out1$real$predicted$x,out1$real$predicted$y,type="l",ylim=c(0,0.6),
		col="red",xlab="distance (km)",ylab="correlation coefficients",axes=F)
	axis(1);axis(2)
	points(out2$real$predicted$x,out2$real$predicted$y,type="l",col="black")
	points(out3$real$predicted$x,out3$real$predicted$y,type="l",col="blue")
	abline(h=out1$real$cbar,col="red",lty=2,lwd=0.75)
	abline(h=out2$real$cbar,col="black",lty=2,lwd=0.75)
	abline(h=out3$real$cbar,col="blue",lty=2,lwd=0.75)
	x1 = out1$boot$boot.summary$predicted$x
	y1l = out1$boot$boot.summary$predicted$y["0.025",]
	y1u = out1$boot$boot.summary$predicted$y["0.975",]
	x2 = out2$boot$boot.summary$predicted$x
	y2l = out2$boot$boot.summary$predicted$y["0.025",]
	y2u = out2$boot$boot.summary$predicted$y["0.975",]
	x3 = out3$boot$boot.summary$predicted$x
	y3l = out3$boot$boot.summary$predicted$y["0.025",]
	y3u = out3$boot$boot.summary$predicted$y["0.975",]
#	lines(x1,y1l,lty=2,col="red",lwd=1)
#	lines(x2,y2l,lty=2,col="black",lwd=1)
#	lines(x3,y3l,lty=2,col="blue",lwd=1)
#	lines(x1,y1u,lty=2,col="red",lwd=1)
#	lines(x2,y2u,lty=2,col="black",lwd=1)
#	lines(x3,y3u,lty=2,col="blue",lwd=1)
	polygon(c(x1,rev(x1)),c(y1l,rev(y1u)),col=rgb(1,0,0,0.1),border=NA)
	polygon(c(x2,rev(x2)),c(y2l,rev(y2u)),col=rgb(0,0,0,0.1),border=NA)
	polygon(c(x3,rev(x3)),c(y3l,rev(y3u)),col=rgb(0,0,1,0.1),border=NA)
#	title(paste(mid))	# this is preferable to the legend for making a movie:
# Adding the legend:
#	legend("topright",legend=c(paste(from1,"-",to1-1,sep=""),
#		paste(from3,"-",to3-1,sep="")),col=c("red","blue"),
#		text.col=c("red","blue"),bg="white",lty=1,box.col="white")
	legend("topright",legend=c(paste(from1,"-",to1-1,sep=""),
		paste(from2,"-",to2-1,sep=""),paste(from3,"-",to3-1,sep="")),col=c("red","black","blue"),
		text.col=c("red","black","blue"),bty="n",lty=1)
	if(is.null(out)) list(out1=out1,out2=out2,out3=out3,from1=from1,from2=from2,from3=from3,to1=to1,to2=to2,to3=to3)
}
