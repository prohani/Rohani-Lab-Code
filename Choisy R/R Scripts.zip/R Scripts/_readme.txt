# Functions to load the data:
	loaddata:	loads the disease notification cases.
	loadnewdata:	loads the new weekly dataset and transforms it into monthly data.
	loadnewdata2:	loads the new weekly dataset and transforms it into monthly data. The transformation
			here is different.
	combinedataset:	combines the monthly and the weekly datasets.
	loadpopsize:	loads the population size data.
	plotweekly:	plots the weekly cases on the 2003-2007 period. Used by plotcomparison.
	plotmonthly:	plots the monthly cases on the 2003-2007 period for comparison with plotweekly.
			Used by plotcomparison.
	plotcomparison: This function plot weekly and monthly cases together on the 2003-2007 period.
			This is to check whether the weekly to monthly transformation is good enough.
			Uses plotweekly and plotmonthly.
			
# Functions to plot the time series:
	plotstate:	plot the time series of a given state for a given time period.
	plotallstates:	plot the time series of all the states for a given time period.
			The states are ranked according to the mean population size over the
			time period under consideration. It also plots the vaccine coverage,
			the population size, the birth rate, and the susceptible recruitment.
	plotallstates2: same as plotallstates except that it does not plot the vaccine coverage,
			the population size, the birth rate, and the suceptible recruitment.

# Functions to investigate the pairwise correlations, both in space and in time:
	correlation1:	plot the correlation coeffecients of each pair of states.
	correlation2:	cuts the dataset into 2 adjacent time periods and calculates the
			correlation coefficients of each pair of states for the 2 periods.
	correlplot:	draws the plot of the correlation coefficient distribution if required
			by the correlation.r function.
	correlsum:	summarizes the information gathered from the correlation.r function.
			Used by the corrchanges.r function.
	corrchanges:	monitor the evolution of the distribution of the correlation coefficients
			in the 2 dataset of the correlation.r function when the separating year changes.
	corrdistance1:	plots the spatial correlation function for one time period using Sncf.
	corrdistance2:	plots the spatial correlation function for two adjacent time periods using Sncf.
	corrdistance2b:	same as corrdistance2 except that it can consider two time periods that are not adjacent.
	corrdistanceX:	plots the spatial correlation functions for periods of time of increasing duration.
	corrdistangle1:	the same as corrdistance1 but using Sncf2D (looking for the behavior of the
			correlation coefficient in all the space directions). Plots it for a specified
			time period.
	corrdistangleX:	same as corrdistangle1 but for time periods growing by steps of 1 year. 

# Functions to investigate the CCS:
	ccs1:		plots the CCS for the a specified time period + estimates of the
			CCS values and number of states above and below this CCS value.
			This function accounts for changes with time in population sizes.
	ccs2:		plots the CCS for two adjacent time periods + estimates.
	ccschanges:	monitor the number of states above the CCS of two adjacent time period
			when the separating year changes.
	ccsplot:	the function that draws the plots of the CSS curves.

# Functions to do Morlet wavelet decomposition:
	waveletanalysis: this is a cap function to wavelettransform and waveletplot.
	wavelettransform: performs the wavelet decomposition. Used by waveletanalysis.
	waveletplot:	draws the wavelet power spectrum. Used by waveletanalysis.
	wavelettest2:	in its current form, basically a wrap-up of the wavelettestnoise2 function. Used by waveletplot.
	wavelettestnoise2: gives the p-values by comparing the signal to a white or red noise
			of the same autocorrelation structure. Used by wavelettest2.
	waveletfilter:	filter a time series between two period values.
	waveletmiscellenous: includes utility functions for wavelet manipulation: wavepower and waveglobal.
	waveletallstates: calculates the wavelet power for each of the states.
	waveletallstatesplot: calculates and plot the mean wavelet power.
	waveletoutput:	this function is now useless.

# Functions to investigate the dominant period:
	mainperiod1:	plots the main period for each state over a specified time period.
	mainperiod2:	same as mainperiod1 but for 2 different time periods.
	mainperiodX:	same as mainperiod2 but for 20 different time periods.

# Functions to investigate the phase of the filtered time series:
	transfphase:	transforms the phase time series into a monotonically increasing one. Used by
			phaseplot* and filteredplot.
	phasediff:	Gives the difference betwen two phases. Used by phasedifffig and phasedistanceref.
	phasedifffig:	draws the figure that explain how the phase difference is calculated. For didactical
			purposes only.
	phasedistanceref:draw the phase difference with a reference state as a function of the distance to this
			reference state. Not used any more: replaced by phaseplot4 now.
#	phaseplot1:	plots the time series of the phase angles for each state.
#	phaseplot2:	same as phaseplot1 but with phase angles monotonically increasing.
#	phaseplot3:	do the same as in phaseplot2, then do the linear regression of all phases
#			against time and plot the residuals as a function of longitude.
# All the above functions have been replaced by the following filteredplot one:
	filteredplot:	plots the filtered time series or phase angle for all the states. Transformed or not.
			On residuals or not.
	lmconfint:	calculates and draws two regressions (on each side of a threshold) plus
			their confidence intervals. Used by phaseplot4 and phaseplot4plot.
	lmconfint2:	the same as lmconfint except that it deals with phase-latitude plots.
	lmconfint3:	the same as lmconfint except that it does 3 pieces in the piecewise regression.
	phaseplot4:	same as phaseplot3 but also plots the residuals as a function of latitude
			and smoothes the residuals on a map.
	phaseplot4plot: do the plot part only of phaseplot4 when mtype="smooth".
	speed:
	slopechangesm2:	plot the slopes of the regression lines of angle phases as a function of longitude against time.
	slopechangesm1: the same as slopechangesm2 but with method 1 (i.e. time range selection before wavelet transform). Very long!!!
	slopechangesm1graph: same as slopechangesm1 but does only the graph.
	slopechangesres: do the same as slopechanges except that it first corrects for the latitude. But this is
			actually pointless since longitude and latitude are not colinear. Could be suppressed.
	brokenlm:	gives the deviance of a broken linear model as a function of threshold and rotation angle.
			Used by brokenlm.
	phaserotation:	plot the deviance of a broken linear model as a function of its rotation angle.
	popeffect:	investigate the effect of population size of phase angles.
	popeffectres:	same as popeffect but on the residuals after having accounted for the effect of longitude,
			latitude and their interaction.
	lag:		same as plotallstates except that it orders the states according to their mean phase angle
			by putting first the states with longitude < -100 and then the states with longitude > -100.
	laglong:	same as lag except that it orders the states only according to their longitude.

# Population density analysis:
	metstatmap:
	metdensest:
	metdensmap:
	statdensmap:

# Miscellaneous general functions:
	selectstates:	selects the data for a specified set of states (the 49 mainland states).
	distance:
	distance2:
	distance3:
	translatestates:

# Still to class:
	mapplot:
	movie:
	moviesmooth:
	prevalencestate:
	prevalenceusa:
	vaccination:

# Datasets:
	pertussis
	popsize
	centroids
	smootheddata
	statesabbr:	the abbrevation of each state.
	met1950:
	met2000:
