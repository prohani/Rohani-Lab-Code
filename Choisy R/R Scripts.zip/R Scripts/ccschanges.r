ccschanges = function(disease=selectstates(pertussis),pop=selectstates(popsize),from,to)
{
# Set the values of the time selection if needed:
	if(missing(from)) from = floor(min(disease$time))
	if(missing(to)) to = ceiling(max(disease$time))
# Create the vector of separating years:
	sepyear = (from+2):(to-2)
	out = lapply(sepyear,function(x)
	{	
		out = ccs2(disease=selectstates(pertussis),pop=selectstates(popsize),from=from,mid=x,to,graph=F)
		c(out$nb1,out$nb2)
	})
	out = matrix(unlist(out),byrow=T,ncol=6)
	out = rbind(rep(NA,6),rep(NA,6),out,rep(NA,6),rep(NA,6))
# Plot the graph:
	sepyear = from:to
#	parplt = par('plt')
#	parplt[1:2] = c(0.14,0.88)
#	par(plt=parplt,mgp=c(1.5,0.5,0))
	plot(sepyear,out[,3],col="red",type="b",xlab="separating year",ylab="number of states above CCS",xaxs="i")
	points(sepyear,out[,6],col="blue",type="b")
#	abline(v=1965,lty=2)
	legend("topright",bty="n",c("before","after"),col=c("red","blue"),lty=1,text.col=c("red","blue"))
}
