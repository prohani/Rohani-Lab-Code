lmconfint = function(y,thresh=-100,col="red")
{
	x1 = y[y[,1]<=thresh,1]
	y1 = y[y[,1]<=thresh,2]
	x2 = y[y[,1]>thresh,1]
	y2 = y[y[,1]>thresh,2]
	mod1 = lm(y1~x1)
	mod2 = lm(y2~x2)
#	plot(y[,1],y[,2],pch=".")
	x1 = sort(unique(x1))
	x2 = sort(unique(x2))
	prd1 = predict(mod1,data.frame(x1=x1),int="conf",level=.99)
	prd2 = predict(mod2,data.frame(x2=x2),int="conf",level=.99)
	lines(x1,prd1[,2],lty=1,col=col)
	lines(x1,prd1[,3],lty=1,col=col)
	lines(x2,prd2[,2],lty=1,col=col)
	lines(x2,prd2[,3],lty=1,col=col)
}
