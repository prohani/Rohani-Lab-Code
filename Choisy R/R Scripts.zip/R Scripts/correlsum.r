correlsum = function(object,CI=0.95)
# This function gives the mean and confidence intervals for the parwaise
# correlation coefficients for the two periods.
{
	disease1 = sort(object$series1)
	disease2 = sort(object$series2)
	n1 = length(disease1)
	n2 = length(disease2)
	c("Lower 1" = disease1[max(round(n1*(1-CI)/2),1)],
		"Mean 1" = mean(disease1),
		"Upper 1" = disease1[round(n1*(1-(1-CI)/2))],
		"Lower 2" = disease2[max(round(n2*(1-CI)/2),1)],
		"Mean 2" = mean(disease2),
		"Upper 2" = disease2[round(n2*(1-(1-CI)/2))])
}
