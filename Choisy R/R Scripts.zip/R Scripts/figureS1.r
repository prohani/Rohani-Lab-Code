figureS1 = function()
# width = 3.65, height = 4.5
{
#	x0 = 0.17
	x0 = 0.19
	t = 0.005
	par(plt=c(x0,0.99,0.7775-t,0.99-t),mgp=c(1.5,0.5,0))
	data = dataFigS1a
	times = data$times
	filtered = data$filtered
	states = data$states
	state1 = data$state1
	state2 = data$state2
	plot(times,filtered[1,],type="l",col="grey",ylim=range(as.vector(filtered),na.rm=T),axes=F,ann=F)
	box(); axis(2)
	mtext("quadriennal",2,2.5)
	mtext("component",2,1.5)
	for(i in 2:length(states)) points(times,filtered[i,],type="l",col="grey")
	if(!state1=="") points(times,filtered[which(states==state1),],type="l",col="red")
	if(!state2=="") points(times,filtered[which(states==state2),],type="l",col="blue")


	par(plt=c(x0,0.99,0.555-t,0.7675-t),mgp=c(1.5,0.5,0),new=T)
	data = dataFigS1b
	times = data$times
	filtered = data$filtered
	states = data$states
	state1 = data$state1
	state2 = data$state2
	plot(times,filtered[1,],type="l",col="grey",ylim=range(as.vector(filtered),na.rm=T),axes=F,ann=F)
	box(); axis(2)
	mtext("phase",2,2.5)
	mtext("angle (radian)",2,1.5)
	for(i in 2:length(states)) points(times,filtered[i,],type="l",col="grey")
	if(!state1=="") points(times,filtered[which(states==state1),],type="l",col="red")
	if(!state2=="") points(times,filtered[which(states==state2),],type="l",col="blue")


	par(plt=c(x0,0.99,0.3275-t,0.545-t),mgp=c(1.5,0.5,0),new=T)
	data = dataFigS1c
	times = data$times
	filtered = data$filtered
	states = data$states
	state1 = data$state1
	state2 = data$state2
	plot(times,filtered[1,],type="l",col="grey",ylim=range(as.vector(filtered),na.rm=T),axes=F,ann=F)
	box(); axis(2)
	mtext("phase",2,2.5)
	mtext("angle (radian)",2,1.5)
	for(i in 2:length(states)) points(times,filtered[i,],type="l",col="grey")
	if(!state1=="") points(times,filtered[which(states==state1),],type="l",col="red")
	if(!state2=="") points(times,filtered[which(states==state2),],type="l",col="blue")


	par(plt=c(x0,0.99,0.105-t,0.3175-t),mgp=c(1.5,0.5,0),new=T)
	data = dataFigS1d
	times = data$times
	filtered = data$filtered
	states = data$states
	state1 = data$state1
	state2 = data$state2
	plot(times,filtered[1,],type="l",xlab="year",ylab="angle (radian)",col="grey",ylim=range(as.vector(filtered),na.rm=T))
	mtext("residual phase",2,2.5)
	for(i in 2:length(states)) points(times,filtered[i,],type="l",col="grey")
	if(!state1=="") points(times,filtered[which(states==state1),],type="l",col="red")
	if(!state2=="") points(times,filtered[which(states==state2),],type="l",col="blue")

# Write the subfigure letters:
	x1 = 0.0
	par(plt=c(x1,x1+0.05,0.94,0.99),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(5,8,"A",font=2)
	par(plt=c(x1,x1+0.05,0.7025,0.7525),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(5,8,"B",font=2)
	par(plt=c(x1,x1+0.05,0.475,0.525),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(5,8,"C",font=2)
	par(plt=c(x1,x1+0.05,0.2475,0.2975),new=T)
	plot(1:10,1:10,type="n",axes=F,ann=F)
	text(5,8,"D",font=2)
}
