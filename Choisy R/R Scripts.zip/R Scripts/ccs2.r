ccs2 = function(disease=selectstates(pertussis),pop=selectstates(popsize),
	from,mid,to,pdf=F,graph=T,fact=1000)
{
# Set the values of the time selection if needed:
	if(missing(from)) from = floor(min(disease$time))
	if(missing(to)) to = ceiling(max(disease$time))
	if(missing(mid)) mid = round(mean(c(from,to)))
# Segreggates the two datasets in two datasets each:
	pop1 = subset(pop,year>=from & year<mid)
	pop2 = subset(pop,year>=mid & year<to)
	disease1 = subset(disease,time>=from & time<=mid)
	disease2 = subset(disease,time>=mid & time<=to)
	out1 = ccs1(disease=selectstates(disease1),pop=selectstates(pop1),graph=F)
	out2 = ccs1(disease=selectstates(disease2),pop=selectstates(pop2),graph=F)
	if(graph)
	{
# Plot the graph:
		opar = par(mgp=c(1.5,0.5,0))
		pop1 = out1$pop
		pop2 = out2$pop
		fadeout1 = out1$fadeout
		fadeout2 = out2$fadeout
		param1 = out1$param
		param2 = out2$param
		the.x1 = seq(min(pop1),max(pop1),length=100)
		the.x2 = seq(min(pop2),max(pop2),length=100)
		the.y1 = param1[1]*exp(param1[2]*the.x1)
		the.y2 = param2[1]*exp(param2[2]*the.x2)
		plot(c(pop1,pop2)/fact,c(fadeout1,fadeout2),type="n",
			xlab=paste("population size x",fact,sep=""),
			ylab="with no notification",axes=F)
#			ylab="proportion of months with no notification",axes=F)
		mtext("proportion of months",2,2.5)
		axis(1); axis(2)
		points(pop1/fact,fadeout1,col="red")
		points(pop2/fact,fadeout2,col="blue")
		points(the.x1/fact,the.y1,type='l',col="red")
		points(the.x2/fact,the.y2,type='l',col="blue")
		abline(v=out1$CCS/1000,lty=2,col="red")
		abline(v=out2$CCS/1000,lty=2,col="blue")
# Adding the legend:	
#		legend("topright",legend=c(paste("period ",from,"-",mid,sep=""),
#			paste("period ",mid+1,"-",to-1,sep="")),col=c("red","blue"),
		legend("topright",legend=c(paste(from,"-",mid-1,"      ",sep=""),
			paste(mid,"-",to-1,"      ",sep="")),col=c("red","blue"),
			text.col=c("red","blue"),bg="white",lty=1,box.col="white")
		par(opar)
	}
# Output:
	list(CCS1=out1$CCS,CCS2=out2$CCS,nb1=out1$nb,nb2=out2$nb,from=from,mid=mid,to=to)
}
