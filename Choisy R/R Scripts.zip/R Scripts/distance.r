distance = function(state1="Alabama",state2="New York")
# This function calculates de distance between two localities from their longitude
# and latitude values and accounting for the rotundity of the earth
{
	lambda1 = centroids[state1,"X"]*pi/180
	lambda2 = centroids[state2,"X"]*pi/180
	delta = lambda1-lambda2
	phi1 = centroids[state1,"Y"]*pi/180
	phi2 = centroids[state2,"Y"]*pi/180
	radius = 6378
	radius*atan(sqrt((cos(phi2)*sin(delta))^2+
		(cos(phi1)*sin(phi2)-sin(phi1)*cos(phi2)*cos(delta))^2)/
		(sin(phi1)*sin(phi2)+cos(phi1)*cos(phi2)*cos(delta)))
}
