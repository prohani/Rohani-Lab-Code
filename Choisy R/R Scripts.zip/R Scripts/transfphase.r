transfphase = function(phase)
# The following function transforms the phase time series into a monotonally increasing one,
# accounting for the irregularities in the phase time series:
{
	A = which(diff(phase)<0)
	B = which(diff(A)==1)
	phase[A[B]+1] = NA
	A = which(phase<0)
	B = which(diff(A)>1)
	breaks = A[c(0,B)+1]
	breaks = breaks[breaks>1]
	end = length(phase)
	for(i in breaks) phase[i:end] = phase[i:end]+2*pi
	phase
}

