prevalencestate = function(pop=selectstates(popsize),data=selectstates(pertussis))
# This function calculates the prevalence of each state.
{
	themin = round(min(data$time))
	themax = trunc(max(data$time))
	pop = subset(pop,year>=themin & year<=themax)
	out = NULL
	statenames = unique(data$state)
	for(thestate in statenames)
	{
		poptmp = subset(pop,state==thestate)
		poptmp = poptmp[order(poptmp$year),]
		datatmp = subset(data,state==thestate)
		datatmp = datatmp[order(datatmp$time),]
		datatmp$count = datatmp$count/rep(poptmp$size,each=12)
		out = rbind(out,datatmp)
	}
	out
}
