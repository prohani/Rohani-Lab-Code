combinedatasets = function(data1=pertussis1,data2=pertussis2)
# This function combined the monthly dataset with the weekly dataset
# by avoiding the overlapping on the common 2003 year:
{
	data = rbind(data1,subset(pertussis2,time>=2004))
# Re-order the data frame chronologically for each state:
	data = data[order(data$time),]
	data = data[order(data$state),]
# Re-initilize the row names of the data frame: 
	rownames(data) = as.character(1:nrow(data))
# Give the output:
	data
}
