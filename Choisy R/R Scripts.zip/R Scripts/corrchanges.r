corrchanges = function(disease=selectstates(pertussis),from,to,transf='none',CI=0.5,pdf=F)
{
# Load the needed library:
	library(multicore)
# Set the values of the time selection if needed:
	if(missing(from)) from = floor(min(disease$time))
	if(missing(to)) to = ceiling(max(disease$time))
# Calculate the mean correlation coefficient of 'disease':
	corval = correlsum(correlation2(disease=disease,mid=to+1,graph=F,transf=transf,from=from,to=to),CI=CI)
	corval = corval[1:3]
# Create the vector of separating years:
	sepyear = (from+1):(to-1)
# Calculate the mean (plus CI)
	out = mclapply(sepyear,function(x)correlsum(correlation2(disease=disease,mid=x,graph=F,transf=transf),CI=CI))
	out = matrix(unlist(out),byrow=T,ncol=6)
	out = cbind(rbind(rep(NA,3),out[,c(1:3)],corval),rbind(corval,out[,c(4:6)],rep(NA,3)))
# Plot the graph:
	sepyear = from:to
#	parplt = par('plt')
#	parplt[1:2] = c(0.14,0.88)
#	par(plt=parplt)
#	par(mgp=c(1.5,0.5,0))
	plot(rep(sepyear,6),as.vector(out),type="n",xlab="separating year",ylab="correlation coefficient",xaxs="i")
	points(sepyear,out[,2],col="red",type="l")
	points(sepyear,out[,5],col="blue",type="l")
	last = to-from+1
	polygon(c(sepyear[-1],rev(sepyear[-1])),c(out[-1,1],rev(out[-1,3])),col=rgb(1,0,0,0.2),border=NA)
	polygon(c(sepyear[-last],rev(sepyear[-last])),c(out[-last,4],rev(out[-last,6])),col=rgb(0,0,1,0.2),border=NA)
#	abline(v=1965,lty=2)#,col="blue")
#	abline(v=1973,lty=2,col="red")
#	abline(h=out[2,2],lty=2)
#	abline(h=out[1,5],lty=2)
	legend("bottom",bty="n",c("before","after"),col=c("red","blue"),lty=1,text.col=c("red","blue"))
}
