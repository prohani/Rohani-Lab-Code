mainperiod1 = function(data=selectstates(pertussis),pop=selectstates(popsize),from,to,scaled=T,titlerange=T,signif=F,upperP=8,out=NULL,pad=128,method="method1")
# This function calculates the dominant period for each states for a given time period:
# method1: select the time period before the wavelet analysis.
# method2: select the time period after the wavelet analysis.
{
	if(is.null(out))	
	{
# Set the values of the time selection if needed:
#		if(missing(from)) from = round(min(data$time))
#		if(missing(to)) to = round(max(data$time))
# Select the data to plot:
#		data = subset(data,time>=from & time<to)
# Sort the 2 datasets so their state names match:
		pop = pop[order(pop$state),] ; pop = pop[order(pop$year),]
		data = data[order(data$time),] ; data = data[order(data$state),]
# Calculate the spectrum and the significativity for each state
		spectrum = significativity = variance = NULL
		statenames = unique(data$state)
		if(method=="method1")
			for(state in statenames)
			{
				tmp = waveletanalysis(state,from,to,data,F,upperPeriod=upperP,pad=pad)
				spectrum = rbind(spectrum,waveglobal(tmp))
				significativity = rbind(significativity,wavelettest2(tmp)$gm_ws)
				variance = c(variance,var(tmp$y))
			}
		else
			for(state in statenames)
			{
				tmp = waveletanalysis(state,data=data,plot=F,upperPeriod=upperP,pad=pad)
				spectrum = rbind(spectrum,waveglobal(tmp,from,to))
				ts = tmp$y
				time = tmp$time
				ts = ts[time>=from & time<to]
				variance = c(variance,var(ts))
			}
# Rename the row with the corresponding state to which they correspond:
		rownames(spectrum) = statenames
		showresults = T
	}
	else
	{
		showresults = F
		spectrum = out$spectrum
		variance = out$variance
		from = out$from
		to = out$to
		upperP = out$upperP
	}
# Different ways to visualize the results:
#	if(scaled) spectrum = t(apply(spectrum,1,function(x)(x-min(x))/(max(x)-min(x))))
# It is better to scale with the variance (which, anyway, here must be equal to 1,
# because data have been scaled):
	if(scaled) spectrum = spectrum/variance%*%t(rep(1,ncol(spectrum)))
	if(signif) spectrum[spectrum<significativity] = NA
# Drawing the graph:
	nbstates = nrow(spectrum)
	theticks = c(nbstates,seq(nbstates+1,1,by=-10)[-1],1)
	par(mgp=c(1.5,0.5,0),plt=c(0.2,0.7,0.25,0.8))
#	spectrum = spectrum^0.3
	image(seq(0.1,upperP,length=ncol(spectrum)),1:nbstates,t(spectrum[nbstates:1,]),
		col=rev(heat.colors(100)),xlab="period (years)",ylab="state",axes=F)
#	if(titlerange) title(paste("from",from,"to",to))
#	title(paste(from,"-",to,sep=""))
	mtext(paste(from,"-",to-1,sep=""),3,0.5)
	axis(2,at=theticks,labels=as.character(rev(theticks)))
	axis(1); box()
	abline(v=1,lty=2)
	abline(v=4,lty=2)
# Add the scale:
#	par(plt=c(0.9,0.95,0.25,0.8),new=T)
	par(plt=c(0.75,0.8,0.25,0.8),new=T)
	colrange = seq(min(spectrum),max(spectrum),length=100)
	scalecol = matrix(rep(colrange,25),ncol=25)
	image(1:25,colrange,t(scalecol),col=rev(heat.colors(100)),ann=F,axes=F)
	axis(4)
#	axis(2,pretty(range(powert)),as.character(round(pretty(range(powert))^(1/0.3))))
	mtext("global power",4,line=1.5); box()
# Shows the name of the state to which each row corresponds:
	show(rownames(spectrum))
# Gives the output:
	if(showresults) list(tmp=tmp,spectrum=spectrum,variance=variance,upperP=upperP,from=from,to=to)
}
