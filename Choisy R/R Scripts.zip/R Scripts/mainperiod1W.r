mainperiod1 = function(data=selectstates(pertussis),pop=selectstates(popsize),from,to,scaled=T,titlerange=T)
# This function calculates the dominant period of all the states over a given time period.
{
# Set the values of the time selection if needed:
	if(missing(from)) from = round(min(data$time))
	if(missing(to)) to = round(max(data$time))
# Select the data to plot:
	data = subset(data,time>=from & time<to)
# Sort the 2 datasets so their state names match:
	pop = pop[order(pop$state),] ; pop = pop[order(pop$year),]
	data = data[order(data$time),] ; data = data[order(data$state),]

	spectrum = significativity = NULL
	statenames = unique(data$state)
	for(state in statenames[1:3])
	{
		show(state)
# Selecting the state and time range to analyse:
#		if(missing(from)) from = round(min(data$time))
#		if(missing(to)) to = round(max(data$time))
#		ys = unlist(subset(data,state==statename & time>=from & time<=to,select=count))
#		out1 = wavelettransform(ys,dt,dj,lowerPeriod,upperPeriod,pad)
		tmp = waveletanalysis(state,from,to,data,F)
#		global_ws = variance*apply(power,1,mean)
#		spectrum = rbind(spectrum,tmp$out2$global_ws)
		spectrum = rbind(spectrum,wavepower(tmp$out1))
		significativity = rbind(significativity,tmp$gm_ws)
	}
	show('ok')
	show(dim(spectrum))
	rownames(spectrum) = statenames[1:3]
	show('ok2')
	if(scaled) spectrum = t(apply(spectrum,1,function(x)(x-min(x))/(max(x)-min(x))))
	else spectrum[spectrum<significativity] = NA
	nbstates = nrow(spectrum)
	theticks = c(nbstates,seq(nbstates+1,1,by=-10)[-1],1)
	par(mgp=c(1.5,0.5,0))
	image(seq(0.1,6,length=572),1:nbstates,-t(spectrum[nbstates:1,]),
		col=heat.colors(100),xlab="period (years)",ylab="state",axes=F)
	if(titlerange) title(paste("from",from,"to",to))
	axis(2,at=theticks,labels=as.character(rev(theticks)))
	axis(1); box()
	show(rownames(spectrum))
	spectrum
}
