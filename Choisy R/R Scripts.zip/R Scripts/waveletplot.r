waveletplot = function(object,time,pvalue,transf,centered,test,ns,ps,amp,ylab="number of cases")
# This function draws the plot of a wavelet decomposition.
{
	cor = 1
# Calculate the vector of periods:
	period = object$fourier_factor*object$scale
# Calculate the power:
	power = t(wavepower(object))
# (in the case our time series is reduced, its variance is equal to 1 and we don't
# have to reduce it again as below)
#	power = t(wavepower(object))/var(object$y)
	power = power[,ncol(power):1]
# Calculate the global wavelet spectrum:
	global_ws = waveglobal(object)
# Calculate the significativity:
#	out = wavelettest(object,test,ns,ps,amp,pvalue)
	out = wavelettest2(object,test,pvalue)
	gm_ws = out$gm_ws
	pvp = t(out$pv)
	pvp = pvp[,ncol(pvp):1]
# Ploting the local wavelet power spectrum:
	parplt = c(0.15,0.79,0.3,0.65); par(plt=parplt,mgp=c(1.5,0.5,0))
# We apply an exponent 0.3 to the power for visual purposes:
	image(time,period,power^0.3,xlab="time (year)",ylab="period (year)",axes=F,col=heat.colors(10))
#	image(time,period,power^0.3,xlab="time (year)",ylab="period (year)",axes=F,col=rev(rainbow(100,from=0,end=0.7,gamma=1)))
	contour(time,period,pvp,levels=c(pvalue/cor,1),add=T,drawlabels=F)
#	contour(time,period,pvp,levels=1,add=T,drawlabels=F)
	points(time,max(period)-object$coi,col="white",type="l")
	axis(1,pretty(time)); axis(2,pretty(period),as.character(rev(pretty(period)))); box()
# Plot the time series:
	parplt[3:4]=c(0.65,0.85); par(plt=parplt,new='T')
	plot(time,object$y,type="l",xaxs='i',axes=F,xlab="",ylab=ylab,col="blue")
	axis(2); box()
# Plot the global wavelet power spectrum:
	parplt = c(0.79,0.99,0.3,0.65); par(plt=parplt,new='T')
	plot(c(global_ws,gm_ws),rep(-period,2),xlab="power",ylab="",type="n",xaxs='i',yaxs='i',axes=F)
	points(global_ws,-period,type="l",col="blue")
	points(gm_ws,-period,type="l",lty=2)
	axis(1); box()
}
