correlplot = function(object,xlimits,ylimits,eps=0)
# This function plot the histograms of the correlation coefficients included
# in the _series1_ and _series2_ of the object _object_.
{
	par(mgp=c(1.5,0.5,0))
	tmp1 = hist(object$series1,plot=F,breaks=100)
	tmp2 = hist(object$series2,plot=F,breaks=100)
	if(missing(xlimits))
	{
		xlimits = range(c(tmp1$breaks,tmp2$breaks))
		eps = diff(xlimits)*eps
		xlimits = xlimits + c(-eps,eps)
	}
	if(missing(ylimits)) ylimits = range(c(tmp1$counts,tmp2$counts)) 
	hist(object$series1,xlim=xlimits,ylim=ylimits,breaks=100,main="",xlab="",
		ylab="",col=rgb(1,0,0,0.4),border=rgb(1,0,0,0.4),axes=F)
	par(new=T)
	hist(object$series2,xlim=xlimits,ylim=ylimits,breaks=100,main="",
		xlab="correlation coefficient",ylab="number",
		col=rgb(0,0,1,0.4),border=rgb(0,0,1,0.4))
#	box()
#        legend("topright",legend=c(paste("period ",object$from,"-",object$mid,sep=""),
#		paste("period ",object$mid+1,"-",object$to-1,sep="")),
#		fill=c(rgb(1,0,0,0.4),rgb(0,0,1,0.4)),text.col=c("red","blue"),bty="n")
        legend("topright",legend=c(paste(object$from,"-",object$mid-1,sep=""),
		paste(object$mid,"-",object$to-1,sep="")),
		fill=c(rgb(1,0,0,0.4),rgb(0,0,1,0.4)),text.col=c("red","blue"),bty="n")
}
