bootsbloc = function(y,ps)## Bootstrap by block of mean size, this mean size equal ns*ps## The starting point is randomly chosen####----- INPUTS## y	: raw series## ps	: probability of changing for another block with a new randomly strating point####----- OUTPUT## yb	: botstrapped series{	ns = length(y)	x = rep(y,3)	yb = matrix(0,ns,1)	j = round(ns*rand)+1	for(i in 1:ns)
	{		if(rand<ps) j = round(ns*rand)+1		else j = j+1		yb[i] = x[j]	}
	yb
}


bootsfix2 = function(y,per)## Bootstrap by block of block of fixed length. The bootstrapped series
## is composed of randomly chosen blocks of length per####------ INPUTS## y	: raw series## per	: block length####------ OUTPUT## yb	: botstrapped series{
	ns = length(y)	x = rep(y,2)	yb = matrix(0,ns,1)	j = round(ns*rand)+1	for(i in 1:ns)	{
		if(i%%per==0) j = round(ns*rand)+1		else j = j+1		yb[i] = x[j]	}	yb}


boostfixe = function(ll,per)## Bootstrap by block of block of fixed length## The series is decomposed in block of length per## and then the different blocks are randomized####------ INPUTS## ll	: raw series## per	: block length####------ OUTPUT## lb	: botstrapped series{	np0 = length(ll)	np = np0-np0%%per	la = reshape(ll(1:np),per,np/per) ### A TRADUIRE EN R ###	lb = matrix(0,per,np/per+1)	for(k in 1:(np/per+1))
	{		ind = ceiling(rand*np/per)		lb[,k]=la[,ind]	}	lb[1:np0]}
