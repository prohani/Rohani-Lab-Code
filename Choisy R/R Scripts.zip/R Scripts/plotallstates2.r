plotallstates2 = function(data=selectstates(pertussis),pop=selectstates(popsize),
	from,to,transfmat='log',transfts)
# This function is the same as plotallstates except that, among the time series,
# it plots only the number of cases
### Il faut sélectionner la bonne période de temps pour les tailles de populations.
### un peu comme il a été fait pour les CCS.
{
# For customizing the margin axes appropriately.
	require(Hmisc)
# Read the vaccine coverage from the current directory file and the birth rates:
	vacccov = read.table('pertussis vaccine coverage.dat',header=T)
	births = read.table('birth rates.dat',header=T)
# Set the values of the time selection if needed:
	if(missing(from)) from = floor(min(data$time))
	if(missing(to)) to = ceiling(max(data$time))
# Select the data to plot:
	data = subset(data,time>=from & time<to)
	pop = subset(pop,year>=from & year<to)
	births = subset(births,year>=from & year<to)
# Sort the 2 datasets so their state names match:
	pop = pop[order(pop$state),]; pop = pop[order(pop$year),]
	data = data[order(data$time),]; data = data[order(data$state),]
# Save the states names and
# order the data dataframe according the size of the states:
	thenames = unique(pop$state)
	pop0 = pop
	pop = matrix(pop$size,nrow=length(thenames))
	thesum = apply(pop,1,sum)
	thesum2 = rep(rank(thesum),
		rep(length(unique(data$time)),
			length(unique(data$state))))
	data = data[order(thesum2),]
# Save the times and the time series of the largest state and transform it:
# Instead of the largest state, we can consider the sum of the number of cases:
	thetime = unique(data$time)
#	timeseries = data$count[data$state==tail(data$state,1)]
	timeseries = as.vector(tapply(data$count,data$time,sum))
	if(!missing(transfts))
	{	
		if(transfts=='log') timeseries = log10(timeseries+1)
		if(transfts=='sqrt') timeseries = sqrt(timeseries)
	}
# Set the graphic and device parameters:
	xmin = 0.1 #0.14
	xmax = 0.85 #0.88
	ymin = 0.15  #0.2
	ymax = 0.9  #0.85
	parplt = c(xmin,xmax,ymin,0.65)
	par(plt=parplt,mgp=c(1.5,0.5,0))
# Create the matrix, transform and plot it:	
	data = matrix(data$count,ncol=length(thenames))
	nbcol = ncol(data)
	if(transfmat=='log') data = log10(data+1)
	if(transfmat=='sqrt') data = sqrt(data)
	image(x=thetime,y=1:nbcol,z=data,col=rev(heat.colors(100)),axes=F,xlab="year",ylab="state")
	theticks = c(nbcol,seq(nbcol+1,1,by=-10)[-1],1)
	axis(1)
	axis(2,at=theticks,labels=as.character(rev(theticks)))
	box()
	abline(v=1980)
#	abline(v=1965,lty=2)#,col="blue")
#	abline(v=1973,lty=2,col="red")
# Plot the scale:
	par(plt=c(0.87,0.89,0.15,0.9),new=T)
	colrange = seq(min(data),max(data),length=100)
	scalecol = matrix(rep(colrange,25),ncol=25)
	image(1:25,colrange,t(scalecol),col=rev(heat.colors(100)),axes=F,ann=F)
	box(); axis(4)
	if(transfmat=="log") mtext("log(pertussis cases+1)",4,1.5)
	else if(transfmat=="sqrt") mtext("sqrt(pertussis cases)",2,1.5)
	else mtext("pertussis cases",2,1.5)
# Plot the time series:
	parplt[3] = 0.65
	parplt[4] = ymax
	par(plt=parplt,new='T')
	plot(thetime,timeseries,axes=F,xlab="",type="l",ylab="",xaxs='i',col="blue")
	if(missing(transfts)) title(ylab="pertussis cases")
	else
	{
		if(transfts=='log') title(ylab="Log(cases+1)")
		if(transfts=='sqrt') title(ylab="Sqrt(cases)")
	}
	axis(2); box()
	abline(v=1980)
# Show the names of the states from decreasing population size:
	cat(paste("\n\tStates ranked according to population size\n\nPeriod: ",from,"-",to,"\n\n"))
	print(thenames[order(-thesum)]) ; cat("\n")
}
