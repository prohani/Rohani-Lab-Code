waveletanalysis = function(statename="New York",from,to,data=pertussis,plot=T,transf="sqrt",centered=T,
	dt=1/12,lowerPeriod=0.1,upperPeriod=6,ns=100,pad=128,dj=1/100,test=11,pvalue=0.05,ps=1,amp=10)
# This function performs a wavelet decomposition for a specified state over a specified time range.
# lowerPF and upperPF are the periods between which the signal is filtered.
# lowerPeriod and upperPeriod define the period range over which to perform the analysis.
# dt:		sampling rate (monthly data: dt=1/12)
# ns:		number of bootstrap samples.
# dj:		frequency resolution (i.e. number of sub-octaves)
# test: 	the test to use for testing significativity (test=11 : comparaison with a red noise)
# pvalue:	threshold significance level for the test
# ps:		other bootstrap parameter
# amp:		test parameter
# pad:
{
# Selecting the state and time range to analyse:
	if(missing(from)) from = round(min(data$time))
	if(missing(to)) to = round(max(data$time))
	ys = unlist(subset(data,state==statename & time>=from & time<to,select=count))
	time = unlist(subset(data,state==statename & time>=from & time<to,select=time))
# Transforming the data:
	if(centered)
	{
		if(transf=="sqrt") {ylab="std(sqrt(cases))"; ys = sqrt(ys)}
		else if(transf=="log") {ylab="std(log(cases))"; ys = log10(ys+1)}
		else ylab="std(number of cases)"
		ys = (ys-mean(ys))/sd(ys)
	}
	else
	{
		if(transf=="sqrt") {ylab="sqrt(cases)"; ys = sqrt(ys)}
		else if(transf=="log") {ylab="log(cases)"; ys = log10(ys+1)}
		else ylab="number of cases"
	}
# Performing the wavelet transform. The wavelet is in _out1$wave_:
	out = wavelettransform(ys,dt,dj,lowerPeriod,upperPeriod,pad)
	out[[length(out)+1]] = time
	names(out)[length(out)] = "time"
# Putting the wavelet transform in good shape:
#	out2 = waveletoutput(out1,3.5,4.5)
# Drawing the plot:
#	if(plot) waveletplot(out,from,to,pvalue,transf,centered,test,ns,ps,amp,ylab)
	if(plot) waveletplot(out,time,pvalue,transf,centered,test,ns,ps,amp,ylab)
# Giving the output:
#	else list(out1=out1,out2=out2,out3=out3,gm_ws=gm_ws,pvp=pvp,ys=ys)
#	else list(out1=out1,out3=out3,gm_ws=gm_ws,pvp=pvp,ys=ys)
	else out
}
