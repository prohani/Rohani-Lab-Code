lmconfint3 = function(y,thresh1=-100,thresh2=-80,col="blue")
{
	x1 = y[y[,1]<=thresh1,1]
	y1 = y[y[,1]<=thresh1,2]
	x2 = y[y[,1]>thresh1 & y[,1]<=thresh2,1]
	y2 = y[y[,1]>thresh1 & y[,1]<=thresh2,2]
	x3 = y[y[,1]>thresh2,1]
	y3 = y[y[,1]>thresh2,2]
	mod1 = lm(y1~x1)
	mod2 = lm(y2~x2)
	mod3 = lm(y3~x3)
	x1 = sort(unique(x1))
	x2 = sort(unique(x2))
	x3 = sort(unique(x3))
	prd1 = predict(mod1,data.frame(x1=x1),int="conf",level=.99)
	prd2 = predict(mod2,data.frame(x2=x2),int="conf",level=.99)
	prd3 = predict(mod3,data.frame(x3=x3),int="conf",level=.99)
	lines(x1,prd1[,2],lty=1,col=col)
	lines(x1,prd1[,3],lty=1,col=col)
	lines(x2,prd2[,2],lty=1,col=col)
	lines(x2,prd2[,3],lty=1,col=col)
	lines(x3,prd3[,2],lty=1,col=col)
	lines(x3,prd3[,3],lty=1,col=col)
}
