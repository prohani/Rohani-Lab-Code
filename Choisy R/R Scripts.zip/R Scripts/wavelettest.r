wavelettest = function(object,test,ns,ps,amp,pvalue=0.05,nbin,lowPF=NA,upPF=NA)
# NOTICE: This function contains all the tests that are possible to perform. It's aimed
# to be the final version of wavelettest but still need to be completed. In the
# meantime, we will use the function wavelettest2 that performs only does the comparison
# with the white or red noises.

# Statistical tests for a the wavelet transform by different boostrapping approaches
#	(test=1,2,3,4,5) or by compariosn with white or red noise (test=10,11)
#
#--------- INPUTS
# lowPF    : lower value of the period used for filtering some of the output
#            (filtr_ts, filtr_var, phase_ts)
# upPF     : upper value of the period used for filtering some of the output
#            (filtr_ts, filtr_var, phase_ts)
# pad      : in case of zero padding (it must be a power of two)
# test     : test options: 	1 simple bootstrap
#				2 bootstap with constant block
#                          	3 bootstrap by block
#				4 bootstap with random block
#                          	5 surrogate with Hidden Markow Model
#                          	6 surrogate with Fourier randomization
#                          	7 surrogate with Fourier gaussian amplitude-adjusted
#                         	10 comparison with white noise
#				11 with red noise
# ns       : number of surrogate or boostrapped series
# ps       : length of block or probability of changing block for the boostrap functions
#            or parameter of the gaussian amplitude-adjusted surrogates (ps = 1 or 2 or 3)
# nbin     : number of bin used for the distribution of the raw series in test=5
# amp      : power of 10 for the minima and maxima computations (example amp=10)
#
#--------- OUTPUT
# pv      : matrice of the Pvalue of the power wavelet, for test = 10,11 it's just the pvalue level
# gm_ws   : pvalue significance level for the average wavelet spectrum of y
# fm_var  : pvalue significance level for the average variance of the series
{
	y = object$y
	scale = object$scale
	power = abs(object$wave)^2
	dt = object$dt
	dj = object$dj
	pad = object$pad
	lowP = object$lowP
	upP = object$upP
	n_y = length(y)
	var_y = var(y)
	if(missing(nbin)) nbin = n_y

	del = 0.776
	avg = which(scale>=lowPF & scale<upPF)
	n = dim(power)
	nl = n[1]
	nc = n[2]
	pv5 = matrix(0,ncol=nc,nrow=nl)
	gws = gm_ws = gs2_ws = t(rep(0,nl))
	fvb = m_fvb = m2_fvb = t(rep(0,nc))
	if(test<10)
	{
		for(i in 1:ns)
		{
			if(test==1) yb = bootsbloc(y,1)
			else if(test==2) yb = bootsfixe(y,ps)
			else if(test==3) yb = bootsfix2(y,ps)
			else if(test==4) yb = bootsbloc(y,ps)
#			else if(test==5)
#			{	
#				if(i==1) out = ProbaTransition(y,n_y,nbin,amp)
##				if(i==1) [nw,nb,vbin,trans] = ProbaTransition(y,n_y,nbin,amp)
#				yb = SurrogateHMM(y,n_y,nbin,2,nw,nb,vbin,trans)
#			}
#			else if(test==6) yb  = FourierSurrogate1(y,sum(1000*clock))
#			else if(test==7)
#			{
#				if(ps<1) ps = 1
#				if(ps>3) ps = 1
#				yb = FourierSurrogate2(y,ps,sum(1000*clock))	# FourierSurrogate2 : AmplitudeHisto
#			}
			out = wavelettransform(yb,dt,dj,lowP,upP,pad)
			powb = (abs(out$wb))^2
			for(j in 1:nl)
				for(k in 1:nc)
					if(powb(j,k)>=power(j,k)) pv5(j,k) = pv5(j,k)+1
			gws = var_y*(apply(powb,1,sum)/n_y)
			gm_ws = gm_ws + gws
			gs2_ws = gs2_ws + gws^2
			fvb = out$scale%*%t(rep(1,nc))
			fvb = powb/fvb
			fvb = var_y*dj*dt/del*sum(fvb[avg,])
			m_fvb = m_fvb + fvb
			m2_fvb = m2_fvb + fvb^2
		}
		pv5 = pv5/ns
		pv1 = pv5
		gm5_ws = gm_ws/ns + 1.645*sqrt((gs2_ws - gm_ws^2/ns)/(ns-1))
		gm1_ws = gm_ws/ns + 2.326*sqrt((gs2_ws - gm_ws^2/ns)/(ns-1))
		fm5_var = m_fvb/ns + 1.645*sqrt((m2_fvb - m_fvb^2/ns)/(ns-1))
		fm1_var = m_fvb/ns + 2.326*sqrt((m2_fvb - m_fvb^2/ns)/(ns-1))
	}
	else if(test>=10)
	{   
		if(abs(mean(y))>0.0000001)
		{      
			message('the use of noise tests needs signal with zero mean')
			message('you will not be able to interpret the results of the test')
			message('you must employ bootstrap approaches or normalized signal')
		}
# white noise:
		if(test==10) lag = 0
# red noise:
		else if(test==11) lag = 1
		out = wavelettestnoise(y,lag,dt,dj,scale,lowPF,upPF,pvalue,object$fourier_factor)
		pv = out$pv_scalog%*%t(rep(1,n_y))
#		pv = pvalue*pv/power	# pv = power/pv
		pv = power/var_y/pv	# pv = power/pv
		fm_var = rep(out$pv_var,n_y)
	}
	list(pv=pv,gm_ws=out$pv_spec,fm_var=fm_var)
}
