waveletoutput = function(wave,period,scale,y,variance,dt,dj,lowPF,upPF)
## Computation of different "outputs" based on the Wavelet transform of the signal y
##
##----------- INPUTS
## wave		: wavelet transform computed by 'WaveletTransform'
## period	: vector of period obtained based on the vector scale
## scale	: vector of the wavelet scale employed during the computation 
## y		: THE TIME SERIES
## variance	: variance of y
## dt		: observation time step
## dj		: frequency resolution (ie number of sub-octaves)
## lowerPF	: lower value of the period used for filtering some of the output
##			(filtr_ts, filtr_var, phase_ts)
## upperPF	: upper value of the period used for filtering some of the output
##			(filtr_ts, filtr_var, phase_ts)
##
##----------- OUTPUT
## power	: power wavelet spectrum
## realwav	: real part of the wavelet transform (ie the modulus)
## imagwav	: imaginary part of the wavelet transform
## global_ws	: average power wavelet spectrum
## filtr_ts	: filtered time series (the reconstructed serie) based on the components
##			which are between lowerPF and upperPF periods
## filtr_var	: average variance of the components between lowerPF and upperPF periods
## phase_ts	: filtered phase series between lowerPF and upperPF periods
{
	n = length(y)
	del = 0.776
# Selecting the scale range:	### Shouldn't I multiply by the Fourier factor?
	avg = which(scale>=lowPF & scale<upPF)
# The wavelet power spectrum:
	power   = abs(wave)^2
# The wavelet real part:
	realwav = Re(wave)
# The wavelet imaginary part:
	imagwav = Im(wave)
# Global wavelet spectrum (i.e. time-average over all times):
	global_ws = variance*apply(power,1,mean)
	filtr_ts = sqrt(scale)%*%t(rep(1,n))	# Filtered time series
	filtr_ts = realwav/filtr_ts	# based on periods between lowPF--upPF
	filtr_ts = pi^(1/4)*dj*sqrt(dt)/del*apply(filtr_ts[avg,],2,sum)
	filtr_var = scale%*%t(rep(1,n))	# Filtered variance of the time series
	filtr_var = power/filtr_var	# based on periods between lowPF--upPF
	filtr_var = variance*dj*dt/del*apply(filtr_var[avg,],2,sum)
	phase_ts = atan2(imagwav,realwav)	# Phase of the time series
	phase_ts = apply(phase_ts[avg,],2,mean)	# based on periods between lowPF--upPF
# Give the output:
	list(power=power,realwav=realwav,imagwav=imagwav,global_ws=global_ws,
		filtr_ts=filtr_ts,filtr_var=filtr_var,phase_ts=phase_ts)
}
