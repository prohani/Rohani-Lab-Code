function plotphasedistancepairs(dataset,centres,start,last,states)

%plotphasedistancepairs(pertussis,centerspop,1951,1962,1:49)
%plotphasedistancepairs(pertussis,centerspop,1951,1962,pertussisperiod4)
%plotphasedistancepairs(pertussis,centerspop,1951,1962,pertussisperiod4scaled)
%plotphasedistancepairs(pertussis,centerspop,1951,1962,pertussisperiod4scaledext)
%Export : width = 12cm

%% S�lection des �tats :
dim = size(states);
if dim(1)==1
    pertussis = dataset(:,[1,2,states+2]);
else
    pertussis = dataset(:,[1,2,states'+2]);
end
centers = centres(states,:);

%% Nombre d'�tats :
nbstate = size(pertussis);
nbstate = nbstate(2)-2;

%% Calcul des phases :
lesphases = phase(start,last,pertussis(:,[1 3]));
for i = 4:nbstate+2
    laphase = phase(start,last,pertussis(:,[1 i]));
    lesphases = [lesphases; laphase];
end

%% Calcul des matrices des distances et de diff�rences de phases:
rayon = 6378;
distances = zeros(nbstate,nbstate);
kdim = 12*(last-start+1);
%differences = tensor(zeros(nbstate,nbstate,kdim),[nbstate nbstate kdim]);
differences = zeros(nbstate,nbstate,kdim);
for i=1:nbstate-1
    phi1 = centers(i,2)*pi/180;
    lambda1 = centers(i,1)*pi/180;
    for j=i+1:nbstate
        phi2 = centers(j,2)*pi/180;
        lambda2 = centers(j,1)*pi/180;
        delta = lambda1-lambda2;
        distances(i,j) = ...
            rayon*atan(sqrt((cos(phi2)*sin(delta))^2+...
            (cos(phi1)*sin(phi2)-sin(phi1)*cos(phi2)*cos(delta))^2)/...
            (sin(phi1)*sin(phi2)+cos(phi1)*cos(phi2)*cos(delta)));
        differences(i,j,:) = lesphases(i,:)-lesphases(j,:);
    end
end
differences = mod(differences+3*pi,2*pi)-pi;
moyennes = mean(differences,3);

%% Graphique :
xxx = distances(find(distances>0));
yyy = moyennes(find(distances>0));
plot(xxx,yyy,'ok')
%ylim([0 1])
xlabel('distance (km)')
ylabel('phase difference')
title('Pertussis 49 1951-1962')


