function plotcorrelationsize4(dataset,centers,popsizes)

%tic;plotcorrelationsize4(pertussis,centerspop,popsizesbyyear);toc
%Export : width = 16cm.

subplot(2,2,1)
plotcorrelationsize(dataset,centers,popsizes,1951,1962)
title('Pertussis 1951-1962')
%set(gca,'Box','on')

subplot(2,2,2)
plotcorrelationsize(dataset,centers,popsizes,1963,1976)
title('Pertussis 1963-1976')
%set(gca,'Box','on')

subplot(2,2,3)
plotcorrelationsize(dataset,centers,popsizes,1977,1991)
title('Pertussis 1977-1991')
%set(gca,'Box','on')

subplot(2,2,4)
plotcorrelationsize(dataset,centers,popsizes,1994,2003)
title('Pertussis 1994-2003')
%set(gca,'Box','on')
