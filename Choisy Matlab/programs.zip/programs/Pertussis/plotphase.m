function laphase = plotphase(start,last,dataset)

%% Nombre de couleurs jet :
nbcol = 1000;

%% Calcul des phases :
laphase = phase(start,last,dataset(:,[1 3]));
for i = 4:51
    ph = phase(start,last,dataset(:,[1 i]));
    laphase = [laphase; ph];
end

%% Les couleurs de chaque population :
marc = laphase(:,1);
marc = max(marc)-marc; % Met la phase 0 sur les c�tes.
couleurs = jet(nbcol+1);
marc = (marc-min(marc))/(2*pi);

hold on
for i=1:49
    plot(laphase(i,:),'Color',[...
        couleurs(round(marc(i)*nbcol)+1,1),...
        couleurs(round(marc(i)*nbcol)+1,2),...
        couleurs(round(marc(i)*nbcol)+1,3)])
end

%plot(laphase(31,:),'r')  %%% - Pour rep�rer New York.
%plot(laphase(5,:),'r')   %%% - Pour rep�rer le Colorado.
%plot(laphase(25,:),'r')  %%% - Pour rep�rer le Montana.

hold off
xlim([0 145]);
ylim([-4 4]);
set(gca,'XTick',1:12:156,'XTickLabel',{'1951','1952',...
    '1953','1954','1955','1956','1957','1958','1959',...
    '1960','1961','1962','1963'},'Box','on','YAxisLocation','right')
xlabel('year')
ylabel('phase (radians)')
