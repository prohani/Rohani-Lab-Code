function plotphase2(start,last,dataset)

subplot(4,1,1)
plot(dataset(1:144,33),'r')
hold on
plot(dataset(1:144,7),'k')
hold off

subplot(4,1,2)
plot(log(dataset(1:144,33)),'r')
hold on
plot(log(dataset(1:144,7)),'k')
hold off

subplot(4,1,3)
xxx = lefiltre(start,last,dataset(:,[1 33]));
plot(xxx,'r')
hold on
xxx = lefiltre(start,last,dataset(:,[1 7]));
plot(xxx,'k')
hold off

subplot(4,1,4)
xxx = phase(start,last,dataset(:,[1 33]));
plot(xxx,'r')
hold on
xxx = phase(start,last,dataset(:,[1 7]));
plot(xxx,'k')
hold off