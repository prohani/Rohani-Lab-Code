function [power,realwav,imagwav,global_ws,filtr_ts,filtr_var,phase_ts] = ...
     waveletoutput(wave,period,scale,y,variance,dt,dj,lowPF,upPF)
%
%  Computation of different "outputs" based on the Wavelet transform of the signal y.
%
%  function [power,realwav,imagwav,global_ws,filtr_ts,filtr_var,phase_ts] = ...
%     waveletoutput(wave,period,scale,y,variance,dt,lowPF,upPF)
%
%----------- INPUTS
% wave       : wavelet transform computed by 'WaveletTransform'
% period     : vector of period obtained based on the vector scale
% scale      : vector of the wavelet scale employed during the computation 
% y          : THE TIME SERIES
% variance   : variance of y
% dt         : observation time step
% dj         : frequency resolution (ie number of sub-octaves)
% lowerPF    : lower value of the period used for filtering some of the output 
%              (filtr_ts, filtr_var, phase_ts)
% upperPF    : upper value of the period used for filtering some of the output
%              (filtr_ts, filtr_var, phase_ts)
%
%----------- OUTPUT
% power      : power wavelet spectrum
% realwav    : real part of the wavelet transform (ie the modulus)
% imagwav    : imaginary part of the wavelet transform
% global_ws  : average power wavelet spectrum
% filtr_ts   : filtered time series (the reconstructed serie) based on the components 
%              which are between lowerPF and upperPF periods
% filtr_var  : average variance of the components between lowerPF and upperPF periods
% phase_ts   : filtered phase series between lowerPF and upperPF periods

n = length(y);
del = 0.776;
avg = find((scale >= lowPF) & (scale < upPF));

power   = (abs(wave)).^2 ;            % Wavelet power spectrum
realwav = real(wave) ;                % Real part of the wavelet
imagwav = imag(wave) ;                % Imaginary part of the wavelet

global_ws = variance*(sum(power')/n); % Global wavelet spectrum
                                      % ie time-average over all times

filtr_ts = sqrt(scale)'*(ones(1,n));  % Filtered time series
filtr_ts = realwav ./ filtr_ts;       % based on periods between lowPF--upPF
filtr_ts = pi^(1/4)*dj*sqrt(dt)/del*sum(filtr_ts(avg,:));

filtr_var = scale'*(ones(1,n));       % Filtered variance of the time series
filtr_var = power ./ filtr_var;       % based on periods between lowPF--upPF
filtr_var = variance*dj*dt/del*sum(filtr_var(avg,:)); 

phase_ts = atan2(imagwav,realwav);    % Phase of the time series
phase_ts = mean(phase_ts(avg,:));     % based on periods between lowPF--upPF

return
