function ccsperiods(pertussis,popsizes,debut,fin,couleur)
sortie = ccsduration(pertussis,popsizes,debut,fin,couleur);
hold on
ccsestimation(sortie(:,1),sortie(:,2),couleur)