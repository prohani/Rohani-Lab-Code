function [f dfe dfr pval Estimates] = phaseestimation2(t,Data,couleur)

Starting=[4e-4,0.8,2500,-0.001,6];
options=optimset('Display','iter');

%% Exstimations :
%Estimates=fminsearch(@phasemyfit,Starting,options,t,Data);
Estimates=fminsearch(@phasemyfit2,Starting,[],t,Data);

%% Graphique :
x1 = min(t):max(t(find(t<Estimates(3))));
x2 = min(t(find(t>=Estimates(3)))):max(t);
plot(x1,Estimates(1)*x1+Estimates(2),'Color',couleur)
plot(x2,Estimates(4)*x2+Estimates(5),'Color',couleur)

%% Statistiques de sortie :
n = length(t);
p = length(Estimates);
sse = phasemyfit2(Estimates,t,Data);
t1 = t(find(t<Estimates(3)));
t2 = t(find(t>=Estimates(3)));
yfit1 = Estimates(1)*t1+Estimates(2);
yfit2 = Estimates(4)*t2+Estimates(5);
yfit = [yfit1;yfit2];
ssr = norm(yfit - mean(yfit)).^2;
dfe = n-p;
dfr = p-1;
f = (ssr/dfr)/(sse/dfe);
pval = 1-fcdf(f,dfr,dfe);
