function phase_ts = phase(start,last,pop)

%pop = measles(:,[1 4]);
cor = 100;
%start = 1954;
%last = 1964;
xlim = [start last+1];
ys = pop((pop(:,1)>=start)&(pop(:,1)<=last),2);

%% TRANSFORMATION DES DONNEES
%ys = pop;
%ys = log(pop+1);
%ys = (pop-mean(pop))/std(pop);
%ys = (log(pop+1)-mean(log(pop+1)))/std(log(pop+1));
ys = (sqrt(ys)-mean(sqrt(ys)))/std(sqrt(ys));
dt = 1/12;
time = start:dt:last+1;
time(end) = [];

%% PARAMETRES DE LA TRANSFORME d'ONDELETTES
%% L'ONDELETTE  EST DANS wave
dj=1/100; pad = 128;
lowerPeriod=0.1; upperPeriod=1.5;
[wave,period,scale,coi] = wavelettransform(ys,dt,dj,lowerPeriod,upperPeriod,pad);

%% CALCUL DES SORTIES A PARTIR DE wave
%% POUR PLUS D'EXPLICATION TAPER "help WaveletOutput"
var_y = std(ys)^2;
lowerPF = 0.5; upperPF = 1.5;
[power,realwav,imagwav,global_ws,filtr_ts,filtr_var,phase_ts] = waveletoutput(wave,period,scale,ys,var_y,dt,dj,lowerPF,upperPF);


