function plotcounts(dataset,start,last,states, immigration, popsizes,popsizesbyyear, usbirthrates, centers)
%function plotdata(dataset,start,last,usbirths, states, immigration,popsizes)
%plots data from 49 states
%fits linear regression to explore increase
%correlates with (i)%foreign residents, (ii)#immigrating 1990-2000
%and population size

%plotcounts(pertussis,1994, 2003, states,immigration, popsizes,popsizesbyyear, usbirthrates)
load vacc3.dat;
vacc3 = vacc3([2, 4:12, 14:52],:);
load vacc4.dat;
vacc4 = vacc4([2, 4:12, 14:52],:);

time = dataset((dataset(:,1)>=start)&(dataset(:,1)<=last),[1 2]);
time = time(:,1)+time(:,2)./12;
pop = popsizesbyyear((popsizesbyyear(:,1)>=start)&(popsizesbyyear(:,1)<=last),...
    [2:50]);
%    [2:length(popsizesbyyear)]);

figskip=10;
%%
%plot cummulative annual cases

data = (dataset((dataset(:,1)>=start-1)&(dataset(:,1)<=last),:));
data2=[];
time=start:last;
for ii=start:last
    %X=sum(data(data(:,1)==ii,3:51));
    clear Y;
    Y1=data( data(:,1)==ii-1,3:51);
    Y2=data( data(:,1)==ii,3:51);
    X=sum(Y1(10:12,:))+sum(Y2(1:9,:));
    %sum( data( data( data(:,1)==ii,2)<=9,3:51));
%    X2=zeros(size(X));
    data2 = [data2; X];
end;
clear X;
X=[ones(length(time),1) time'];
nplots=4;
states_sig=[];
for i=1:49
    for j=1:(last-start+1)
        newpop3(:,j)=pop(j,i);
    end;
    %newpop = reshape(newpop2,1,108)';
    %data3=data2(:,i);
    data3=data2(:,i)./newpop3';    %prevalence data
   
    %    newdata=newdata./max(newdata);
    %    [b,bint,r,rint,stats] = regress(data,X);

    [b,bint,r,rint,stats] = regress(data3,X);

    slopes_a(i)=b(2);
        
    figure(ceil(i/(nplots*nplots))+figskip);
    plotno=mod(i,nplots*nplots);
    if plotno==0 plotno=nplots*nplots; end;
    subplot(nplots,nplots,plotno);
    h1=line(time,data3,'color','b','linewidth',2);
    ax1_1=gca;
    set(ax1_1,'YAxisLocation','left'); 
    line(time,b(1)+b(2).*time,'color','r','linewidth',2);
    axis([start-1 last+1 0 max(data3)]);
    set(gca,'XTick',[1986, 1994, 2002],'fontsize',8)
    xlabel 'Year'
    ylabel('Annual {\it per capita} Cases','fontsize',8)
    out=[strcat(states(i))];%,num2str(stats(3))];
    title(out);
    %    legend(out,'Location','Northwest');
    ax2_1 = axes('Position',get(ax1_1,'Position'),...
           'XAxisLocation','top',...
          'YAxisLocation','right',...
           'Color','none',...
          'XColor','w','YColor','g',...
          'Ylim',[90 100], 'Xlim',[start-1 last+1],'fontsize',1);

    vaccdatX=[1995:2003];
    vaccdatY=[vacc3(i,:)];
    line(vaccdatX,vaccdatY,'color','g','linewidth',2);
    set(ax2_1,'XTick',[1986, 1994, 2002],'fontsize',1)
    set(ax2_1,'YTick',[90, 94, 98],'fontsize',8)
    ylabel('DTP3','fontsize',8)
    
    if bint(2,:)>0
        out=['p = ',num2str(stats(3))];
        gtext(out,'fontsize',7);
        states_sig=[states_sig i];
        slopes_sig_a(i)=b(2);
    end
%    title(strcat(states(i)));
end;

%%
%Look for correlations between significant slopes and Population Size
whichs=1:length(states);

figure(5+figskip);
clf;
subplot(3,1,1);
pops=popsizes(2:end,2);
plot(pops(whichs),slopes_a(whichs),'o','Markersize',10);
X=[ones(size(pops(whichs))) pops(whichs)];
[b,bint,r,rint,stats] = regress(slopes_a(whichs)',X);
hold on;
line(pops(whichs), b(1)+b(2).*(pops(whichs)),'color','r','linewidth',2);
out=['p = ',num2str(stats(3))];
title(out);
xlabel 'Population Size 1990'
out=['Linear Slope ',num2str(start),' - ',num2str(last)];
ylabel(out);

subplot(3,1,2);
plot(immigration(whichs,1),slopes_a(whichs),'o','Markersize',10);
X=[ones(size(immigration(whichs,1))) immigration(whichs,1)];
[b,bint,r,rint,stats] = regress(slopes_a(whichs)',X);
hold on;
line(immigration(whichs,1), b(1)+b(2).*immigration(whichs,1),'color','r','linewidth',2);
out=['p = ',num2str(stats(3))];
title(out);
xlabel '% Foreign Residents';
out=['Linear Slope ',num2str(start),' - ',num2str(last)];
ylabel(out);

subplot(3,1,3);
plot(immigration(whichs,2)./(immigration(whichs,3)),slopes_a(whichs),'o','Markersize',10);
[ord p]=sort(immigration(whichs,2)./(immigration(whichs,3)));
X=[ones(size(immigration(whichs,2))) ord];
YY=slopes_a(whichs)';
[b,bint,r,rint,stats] = regress(YY(p),X);
hold on;
line(ord, b(1)+b(2).*ord,'color','r','linewidth',2);
out=['p = ',num2str(stats(3))];
title(out);
xlabel 'Per Capita Immigration 1990-2000'
out=['Linear Slope ',num2str(start),' - ',num2str(last)];
ylabel(out);

%%
%births = usbirthrates((usbirthrates(:,1)>=start)&(usbirthrates(:,1)<=last),2);

figure(6+figskip)
clf;
subplot(2,1,1);
v3=mean(vacc3');
v3=v3(v3>0);
mean(v3)
v3_sig=v3(states_sig);
plot(v3_sig,slopes_a(states_sig),'o','Markersize',10);
X=[ones(length(v3_sig),1) v3_sig'];
[b,bint,r,rint,stats] = regress(slopes_a(states_sig)',X);
hold on;
line(v3_sig, b(1)+b(2).*(v3_sig),'color','r','linewidth',2);
out=['p = ',num2str(stats(3))];
title(out);
out=['Linear Slope ',num2str(start),' - ',num2str(last)];
ylabel(out);
out=['Mean Vaccination Coverage (3 doses)'];
xlabel(out);
format short;
%axis([92 96 -inf 1.25e-5]);
out=['National Average ',num2str(mean(v3(v3>0)))];
gtext(out);

% for i=1:length(states_sig)
%     [h,p3(i)]=ttest(v3(v3~=v3_sig(i)),v3_sig(i));
% end;
% p3

subplot(2,1,2);
v4=mean(vacc4');
v4=v4(v4>0);
mean(v4)
v4_sig=v4(states_sig);
plot(v4_sig,slopes_a(states_sig),'o','Markersize',10);
X=[ones(length(v4_sig),1) v4_sig'];
[b,bint,r,rint,stats] = regress(slopes_a(states_sig)',X);
hold on;
line(v4_sig, b(1)+b(2).*(v4_sig),'color','r','linewidth',2);
out=['p = ',num2str(stats(3))];
title(out);
out=['Linear Slope ',num2str(start),' - ',num2str(last)];
ylabel(out);
out=['Mean Vaccination Coverage (4 doses)'];
xlabel(out);
format short;
out=['National Average ',num2str(mean(v4))];
%axis([76 84 -inf 1.25e-5]);
gtext(out);

% for i=1:length(states_sig)
%     [h,p4(i)]=ttest(v4(v4~=v4_sig(i)),v4_sig(i))
% end;
% p4

%plotmapsiginc(centers,states,states_sig, immigration)
