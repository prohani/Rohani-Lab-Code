function plotccspertussis1(pertussis,popsizes,dates)
ccsperiods(pertussis,popsizes,dates(1),dates(2),[0 0 1])
hold on
ccsperiods(pertussis,popsizes,dates(3),dates(4),[1 0 0])
ccsperiods(pertussis,popsizes,dates(5),dates(6),[0 0.5 0])
hold off
xlabel('population size')
ylabel('proportion of months with fadeouts')
title('Pertussis CCS for the first three periods')
legend('Period 1','Period 1','Period 2','Period 2','Period 3','Period 3')

%plotccspertussis1(pertussis,popsizes,[1951-x 1962 1963 1976 1977 1991]+x)