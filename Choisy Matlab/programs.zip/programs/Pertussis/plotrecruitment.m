function plotrecruitment(uspopsizes,usbirthrates,vaccpertussis)

%% Data transformations
pop = uspopsizes(find(...
    (uspopsizes(:,1)>=max(1951,min(uspopsizes(:,1))))&...
    (uspopsizes(:,1)<=min(2003,max(uspopsizes(:,1))))),:);
birth = usbirthrates(find(...
    (usbirthrates(:,1)>=max(1951,min(usbirthrates(:,1))))&...
    (usbirthrates(:,1)<=min(2003,max(usbirthrates(:,1))))),:);
debut = max(min(pop(:,1)),min(birth(:,1)));
fin = min(max(pop(:,1)),max(birth(:,1)));
pop = pop(find((pop(:,1)>=debut)&(pop(:,1)<=fin)),:);
birth = birth(find((birth(:,1)>=debut)&(birth(:,1)<=fin)),:);
birth(:,2) = pop(:,2).*birth(:,2)/1000;

A = vaccpertussis(find(vaccpertussis(:,1)==1),2:3);
B = vaccpertussis(find(vaccpertussis(:,1)==2),2:3);
C = vaccpertussis(find(vaccpertussis(:,1)==3),2:3);
D = vaccpertussis(find(vaccpertussis(:,1)==4),2:3);
E = vaccpertussis(find(vaccpertussis(:,1)==5),2:3);

F = birth(find((birth(:,1)>=min(A(:,1)))&(birth(:,1)<=max(A(:,1)))),:);
G = birth(find((birth(:,1)>=min(B(:,1)))&(birth(:,1)<=max(B(:,1)))),:);
H = birth(find((birth(:,1)>=min(C(:,1)))&(birth(:,1)<=max(C(:,1)))),:);
I = birth(find((birth(:,1)>=min(D(:,1)))&(birth(:,1)<=max(D(:,1)))),:);
J = birth(find((birth(:,1)>=min(E(:,1)))&(birth(:,1)<=max(E(:,1)))),:);
 
%% Create figure
figure1 = figure('PaperPosition',[0.6345 6.345 20.3 15.23],...
    'PaperSize',[20.98 29.68]);
 
%% Create axes
axes1 = axes(...
  'YColor',[0 0 1],...
  'YTick',[1e+006 2e+006 3e+006 4e+006],...
  'Parent',figure1);
axis(axes1,[1950 2000 1e4 4.4e6]);
ylabel(axes1,'births');
hold(axes1,'all');

axes2 = axes(...
  'YColor',[0 0.5 0],...
  'Color','none',...
  'YAxisLocation','right',...
  'YTick',[60 70 80 90 100],...
  'Parent',figure1);
axis(axes2,[1950 2000 60 100]);
title(axes2,'Recruitement in susceptibles for pertussis');
xlabel(axes2,'year');
ylabel(axes2,'vaccination uptake');
hold(axes2,'all');
 
%% Create plots
plot1 = plot(birth(:,1),birth(:,2),'Parent',axes1);
factor = 3;
plot1 = plot(A(:,1),(1-A(:,2)./100).*F(:,2)*factor,...
    'Color',[1 0 0],'Parent',axes1);
plot1 = plot(B(:,1),(1-B(:,2)./100).*G(:,2)*factor,...
    'Color',[1 0 0],'Parent',axes1);
plot1 = plot(C(:,1),(1-C(:,2)./100).*H(:,2)*factor,...
    'Color',[1 0 0],'Parent',axes1);
plot1 = plot(D(:,1),(1-D(:,2)./100).*I(:,2)*factor,...
    'Color',[1 0 0],'Parent',axes1);
plot1 = plot(E(1:5,1),(1-E(1:5,2)./100).*J(:,2)*factor,...
    'Color',[1 0 0],'Parent',axes1);

plot2 = plot(A(:,1),A(:,2),'Color',[0 0.5 0],'Parent',axes2);
plot2 = plot(B(:,1),B(:,2),'Color',[0 0.5 0],'Parent',axes2);
plot2 = plot(C(:,1),C(:,2),'Color',[0 0.5 0],'Parent',axes2);
plot2 = plot(D(:,1),D(:,2),'Color',[0 0.5 0],'Parent',axes2);
plot2 = plot(E(:,1),E(:,2),'Color',[0 0.5 0],'Parent',axes2);

%% Create textarrow
annotation1 = annotation(...
  figure1,'textarrow',...
  [0.2911 0.3411],[0.519 0.6357],...
  'String',{'recruitement in','susceptibles x3'});
