function sortie = regressionphasedistancesize(centers,start,last,dataset,sizes,states)

%tic;sortie=regressionphasedistancesize(centerspop,1951,1962,pertussis,popsizes(2:end,5),1:49);toc
%tic;sortie=regressionphasedistancesize(centerspop,1951,1962,pertussis,popsizes(2:end,5),pertussisperiod4);toc
%tic;sortie=regressionphasedistancesize(centerspop,1951,1962,pertussis,popsizes(2:end,5),pertussisperiod4scaled);toc
%tic;sortie=regressionphasedistancesize(centerspop,1951,1962,pertussis,popsizes(2:end,5),pertussisperiod4scaledext);toc

%export : width = 12 cm.

%% Calcul des distances
phi1 = centers(31,2)*pi/180;
lambda1 = centers(31,1)*pi/180;
rayon = 6378;
lesdistances = 0;
for i=1:49
    phi2 = centers(i,2)*pi/180;
    lambda2 = centers(i,1)*pi/180;
    delta = lambda1-lambda2;
    lesdistances = [lesdistances;...
        rayon*atan(sqrt((cos(phi2)*sin(delta))^2+...
        (cos(phi1)*sin(phi2)-sin(phi1)*cos(phi2)*cos(delta))^2)/...
        (sin(phi1)*sin(phi2)+cos(phi1)*cos(phi2)*cos(delta)))];
end
lesdistances(1) = [];

%% Calcul des moyennes des diff�rences de phases.
laphase = phase(start,last,dataset(:,[1 3]));
for i = 4:51
    ph = phase(start,last,dataset(:,[1 i]));
    laphase = [laphase; ph];
end
differences = laphase;
newyork = differences(31,:);
for i=1:49
    differences(i,:) = newyork-differences(i,:);
end
differences = mod(differences+3*pi,2*pi)-pi;
% Gestion du Montana :
indices = find(differences(25,:)<0);
differences(25,indices) = differences(25,indices)+2*pi;
moyenne = mean(differences,2);

%% S�lection des �tats :
lesdistances = lesdistances(states);
moyenne = moyenne(states,:);
tailles = sizes(states);

%% Coupons le jeu de donn�es en deux jeux de donn�es :
jeu1 = find((lesdistances<2500)&(lesdistances>0));
jeu2 = find(lesdistances>2500);

%% Premi�re r�gression multiple :
[Coeff,S_err,XTXI,R_sq,F_valA1,Coef_statsA1,Y_hat,resid,cov] = mregress(moyenne(jeu1),[tailles(jeu1) lesdistances(jeu1)],1);
[Coeff,S_err,XTXI,R_sq,F_valA2,Coef_statsA2,Y_hat,resid,cov] = mregress(moyenne(jeu2),[tailles(jeu2) lesdistances(jeu2)],1);
[Coeff,S_err,XTXI,R_sq,F_valB1,Coef_statsB1,Y_hat,resid,cov] = mregress(moyenne(jeu1),[lesdistances(jeu1) tailles(jeu1)],1);
[Coeff,S_err,XTXI,R_sq,F_valB2,Coef_statsB2,Y_hat,resid,cov] = mregress(moyenne(jeu2),[lesdistances(jeu2) tailles(jeu2)],1);

sortie = struct(...
    'F_valA1',F_valA1,'Coef_statsA1',Coef_statsA1,...
    'F_valA2',F_valA2,'Coef_statsA2',Coef_statsA2,...
    'F_valB1',F_valB1,'Coef_statsB1',Coef_statsB1,...
    'F_valB2',F_valB2,'Coef_statsB2',Coef_statsB2);

