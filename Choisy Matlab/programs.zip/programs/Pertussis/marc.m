function marc(dataset,birth,vaccine,popsizes,deb,fin)
pertussis = dataset((dataset(:,1)>=deb)&(dataset(:,1)<=fin),:);
tailles = mean(popsizes((popsizes(:,1)>=deb)&(popsizes(:,1)<=fin),2:end));
prevalence = mean(pertussis(:,3:end))./tailles;
naissance = mean(birth(2:end,:),2)./tailles';
vaccination = mean(vaccine(2:end,3:end),2);
subplot(1,2,1)
plot(naissance,prevalence,'ok')
subplot(1,2,2)
plot(naissance.*vaccination,prevalence,'ok')