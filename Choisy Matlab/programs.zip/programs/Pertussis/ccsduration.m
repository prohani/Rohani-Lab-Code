function sortie = ccsduration(pertussis,popsizes,first,last,couleur)
% This function plots the mean annual duration of fadeouts (in months), as a
% function of the state population size.
% pertussis: should be a 636 x 51 matrix where the first two columns are the
% year and the month respectively, and each of the following columns
% corresponds to one of the 49 states, order alphabetically. A typical
% matrix is "pertussis" in the matlab.m file.
% popsizes: should be a 50 x 11 matrix where the first row corresponds to
% the decennies and each of the following rows corresponds to one of the 49
% states, ordered alphabetically. A typical matrix is "popsizes" in the
% matlab.m. file.
% first and last are the first and the last years of the temporal windows
% we want to analyse.
tmp = pertussis((pertussis(:,1)>=first)&(pertussis(:,1)<=last),3:end);
int = popsizes;
% We discard Kansas if part of the selected window occurs between 1957 and
% 1966 where there seems to be a decennie without census.
if ((first>1956)&(first<1967))|((last>1956)&(last<1967))
    tmp(:,15) = [];
    int(16,:) = [];
end
yearref = round(mean([first,last])/10)*10;
nbfadeout = 0;
nbyear = last-first+1;
top = length(tmp(1,:));
for i = 1:top
    nbfadeout = [nbfadeout;sum(tmp(:,i)==0)];
end
nbfadeout(1) = [];
nbfadeout = nbfadeout/(nbyear*12);
plot(int(2:end,int(1,:)==yearref),nbfadeout,'o','Color',couleur)
sortie = [int(2:end,int(1,:)==yearref),nbfadeout];