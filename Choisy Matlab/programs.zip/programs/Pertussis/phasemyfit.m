function sse=phasemyfit(params,Input,Actual_Output)
A = params(1);
B = params(2);
Fitted_Curve = A*Input+B;
Error_Vector = Fitted_Curve-Actual_Output;
sse = sum(Error_Vector.^2);