function sortie = plotcorrelationbootstrap(pertussis)

%sortie=plotcorrelationbootstrap(pertussis)
% Export : width = 12 cm.

period1=correlationbootstrap(pertussis,1951,1962,1000);
period2=correlationbootstrap(pertussis,1963,1976,1000);
period3=correlationbootstrap(pertussis,1977,1991,1000);
period4=correlationbootstrap(pertussis,1994,2003,1000);
hist(period1(2:end))
hold on
hist(period2(2:end))
hist(period3(2:end))
hist(period4(2:end))
plot(period1(1)*ones(2,1),[0 300],'k')
plot(period2(1)*ones(2,1),[0 300],'k')
plot(period3(1)*ones(2,1),[0 300],'k')
plot(period4(1)*ones(2,1),[0 300],'k')
hold off
h = findobj(gca,'Type','patch');
set(h,'FaceColor',[0.5 0.5 0.5])
xlim([0.05 0.35])
text(period1(1)+0.01,285,'Per. 1')
text(period2(1)+0.01,285,'Per. 2')
text(period3(1)+0.01,285,'Per. 3')
text(period4(1)+0.01,285,'Per. 4')
xlabel('mean correlation coefficient')
ylabel('number')
sortie = [period1(1) period2(1) period3(1) period4(1)];
