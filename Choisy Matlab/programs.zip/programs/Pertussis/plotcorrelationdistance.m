function plotcorrelationdistance(dataset,centers,deb,fin)

%plotcorrelationdistance(pertussis,centerspop,1951,1962)
%Export : width = 12cm

% Param�tre de tension de la r�gression spline :
tension = 1e-8;

%% S�lection et transformation des donn�es :
pertussis = dataset((dataset(:,1)>=deb)&(dataset(:,1)<=fin),:);
pertussis = log(pertussis+1);

%% Calcul de la matrice des distances :
rayon = 6378;
nbstate = size(pertussis);
nbstate = nbstate(2)-2;
distances = zeros(nbstate,nbstate);
for i=1:nbstate-1
    phi1 = centers(i,2)*pi/180;
    lambda1 = centers(i,1)*pi/180;
    for j=i+1:nbstate
        phi2 = centers(j,2)*pi/180;
        lambda2 = centers(j,1)*pi/180;
        delta = lambda1-lambda2;
        distances(i,j) = ...
            rayon*atan(sqrt((cos(phi2)*sin(delta))^2+...
            (cos(phi1)*sin(phi2)-sin(phi1)*cos(phi2)*cos(delta))^2)/...
            (sin(phi1)*sin(phi2)+cos(phi1)*cos(phi2)*cos(delta)));
    end
end

%% Calcul de la matrice des coefficients de corr�lation :
correlations = corrcoef(pertussis(:,3:end));

%% Mise en forme des donn�es :
xxx = distances(find(distances>0));
yyy = correlations(find(distances>0));

%% Bootstrap du spline :
[X Y] = bootrsp2(xxx,yyy,1000);
YY = zeros(4500,1000);
for i=1:1000
    YY(:,i) = fnval(csaps(X(:,i),Y(:,i),tension),1:4500); %1e-8
end
YY = sort(YY,2);
muL = YY(:,25);
muU = YY(:,976);

%% Graphique :
%plot(xxx,yyy,'ok')   
hold on
plot(1:4500,fnval(csaps(xxx,yyy,tension),1:4500))
plot(1:4500,muL,'k')
plot(1:4500,muU,'k')
plot([0 4500],[mean(yyy) mean(yyy)],'--','Color',[0.5 0.5 0.5])
hold off

ylim([0 1])
xlabel('distance (km)')
ylabel('correlation coefficient')
%title('Pertussis')


