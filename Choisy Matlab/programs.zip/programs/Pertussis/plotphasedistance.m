function sortie = plotphasedistance(centers,start,last,dataset,states,statenames,ref)

%tic;sortie=plotphasedistance(centerspop,1951,1962,pertussis,1:49,states,31);toc
%tic;sortie=plotphasedistance(centerspop,1951,1962,pertussis,pertussisperiod4,states,31);toc
%tic;sortie=plotphasedistance(centerspop,1951,1962,pertussis,pertussisperiod4scaled,states,31);toc
%tic;sortie=plotphasedistance(centerspop,1951,1962,pertussis,pertussisperiod4scaledext,states,31);toc

%export : width = 12 cm.

%% Calcul des distances
phi1 = centers(ref,2)*pi/180;
lambda1 = centers(ref,1)*pi/180;
rayon = 6378;
lesdistances = 0;
for i=1:49
    phi2 = centers(i,2)*pi/180;
    lambda2 = centers(i,1)*pi/180;
    delta = lambda1-lambda2;
    lesdistances = [lesdistances;...
        rayon*atan(sqrt((cos(phi2)*sin(delta))^2+...
        (cos(phi1)*sin(phi2)-sin(phi1)*cos(phi2)*cos(delta))^2)/...
        (sin(phi1)*sin(phi2)+cos(phi1)*cos(phi2)*cos(delta)))];
end
lesdistances(1) = [];

%% Calcul des diff�rences de phases.
laphase = phase(start,last,dataset(:,[1 3]));
for i = 4:51
    ph = phase(start,last,dataset(:,[1 i]));
    laphase = [laphase; ph];
end
differences = laphase;
reference = differences(ref,:);
for i=1:49
    differences(i,:) = reference-differences(i,:);
end
differences = mod(differences+3*pi,2*pi)-pi;
%% Gestion du Montana :
indices = find(differences(25,:)<0);
differences(25,indices) = differences(25,indices)+2*pi;

%% Calcul des moyennes et de leur intervale de confiance.
moyenne = [0 0 0];
for i = 1:49
    [muL,muU] = confinth(differences(i,:),'mean',0.05,1000);
    moyenne = [moyenne;mean(differences(i,:)),muL,muU];
end
moyenne(1,:) = [];

%% Create figure
figure1 = figure('PaperPosition',[0.6345 6.345 20.3 15.23],...
    'PaperSize',[20.98 29.68]);

%% Create axes
axes1 = axes('XDir','reverse','Box','on','Parent',figure1);
axis(axes1,[0 4000 -0.5 3.5]);
title(axes1,'Pertussis');
a = 'distance from';
b = char(statenames(ref));
c = '(km)';
d = 'phase difference from';
e = '(radians)';
xlabel(axes1,sprintf('%s %s %s',a,b,c))
ylabel(axes1,sprintf('%s %s %s',d,b,e))
hold(axes1,'all');

%% S�lection des �tats :
lesdistances = lesdistances(states);
moyenne = moyenne(states,:);

%% Graphique :
plot(lesdistances,moyenne(:,1),'.k','MarkerSize',10)
hold on
for i = 1:length(states)
    plot([lesdistances(i) lesdistances(i)],moyenne(i,2:3),'-k')
end

%% R�gression lin�aires :
%% Deux r�gression lin�aires � deux param�tres chacune.
jeu1 = find((lesdistances<2500)&(lesdistances>0));
jeu2 = find(lesdistances>2500);
%% Enlever ou non le Montana des analyses:
%jeu2(5) = [];
[f1 dfe1 dfr1 pval1] = phaseestimation(lesdistances(jeu1),moyenne(jeu1,1),[0 0 0]);
[f2 dfe2 dfr2 pval2] = phaseestimation(lesdistances(jeu2),moyenne(jeu2,1),[0 0 0]);
[b,dev,stats] = glmfit(lesdistances(jeu1),moyenne(jeu1,1),'normal');
param1 = stats.beta;
proba1 = stats.p;
se1 = stats.se;
[b,dev,stats] = glmfit(lesdistances(jeu2),moyenne(jeu2,1),'normal');
param2 = stats.beta;
proba2 = stats.p;
se2 = stats.se;

%% Une unique r�gression lin�aire � cinq param�tres.
[f dfe dfr pval Estimates] = phaseestimation2(lesdistances(find(lesdistances>0)),moyenne(find(lesdistances>0),1),[0 0 1]);

hold off

%sortie = [f dfe dfr pval Estimates];

%sortie = struct(...
%    'F1',f1,'dfe1',dfe1,'dfr1',dfr1,'F1pval',pval1,'inter1',param1(1),'slope1',param1(2),...
%    'inter1pval',proba1(1),'slope1pval',proba1(2),'inter1se',se1(1),'slope1se',se1(2),...
%    'F2',f2,'dfe2',dfe2,'dfr2',dfr2,'F2pval',pval2,'inter2',param2(1),'slope2',param2(2),...
%    'inter2pval',proba2(1),'slope2pval',proba2(2),'inter2se',se2(1),'slope2se',se2(2));

sortie = struct(...
    'F',f,'dfe',dfe,'dfr',dfr,'Fpval',pval,...
    'F1',f1,'dfe1',dfe1,'dfr1',dfr1,'F1pval',pval1,'slope1',param1(2),...
    'slope1m',param1(2)-1.96*se1(2),'slope1p',param1(2)+1.96*se1(2),...
    'speed1',pi/(24*param1(2)),...
    'speed1m',pi/(24*(param1(2)-1.96*se1(2))),...
    'speed1p',pi/(24*(param1(2)+1.96*se1(2))),...
    'F2',f2,'dfe2',dfe2,'dfr2',dfr2,'F2pval',pval2,'slope2',param2(2),...
    'slope2m',param2(2)-1.96*se2(2),'slope2p',param2(2)+1.96*se2(2),...
    'speed2',-pi/(24*param2(2)),...
    'speed2m',-pi/(24*(param2(2)-1.96*se2(2))),...
    'speed2p',-pi/(24*(param2(2)+1.96*se2(2))));

%% 95%CI = M+/-1.96*se :
%sortie.slope1-1.96*sortie.slope1se
%sortie.slope1+1.96*sortie.slope1se
