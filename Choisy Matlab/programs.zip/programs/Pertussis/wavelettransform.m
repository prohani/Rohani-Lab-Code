function [wave,period,scale,coi] = wavelettransform(y,dt,dj,lowerPeriod,upperPeriod,pad)
%
%  Morlet Wavelet transform of signal y.
%  Decomposition between two periods (lowerPeriod,upperPeriod)
%
%   [wave,period,scale,coi] = wavelettransf(y,dt,dj,lowerPeriod,upperPeriod,pad)
%
%------------ INPUTS
% y           : input signal 
% dt          : sampling rate
% dj          : frequency resolution (ie number of sub-octaves)
% lowerPeriod : lower period of the decomposition
% upperPeriod : upper period of the decomposition
% pad         : in case of zero padding (it must be a power of two)
%
%------------- OUTPUT
%   wave      : wavelet Transform-matrix
%   period    : the vector of "Fourier" periods (in time units)
%             : that corresponds to the scale.s
%   scale     : the vector of scale indices, given by so*2.^((0:j1)*dj), j=0...J1
%               where J1 is the total number of scales.
%   coi       : the "cone-of-influence", which is a vector of n_y points
%               that contains the limit of the region where the wavelet transform
%               is influenced by edge effects.

ko = 6;
fourier_factor = (4*pi)/(ko + sqrt(2+ko^2));
so = lowerPeriod/fourier_factor;
fo = upperPeriod/fourier_factor; %%% -- marc -- %%%

if (lowerPeriod == -1), so = 2*dt; end
if (dj == -1), dj = 1./4.; end   %coarse

n1 = length(y);
x(1:n1) = y;

% coi = fourier_factor/sqrt(2);  Correction October 2003
%-------------------------------------------------------
coi = fourier_factor;
coi = coi*dt*[1E-5,1:((n1+1)/2-1),fliplr((1:(n1/2-1))),1E-5];

% --------->   zero padding
if (pad == 0)
    base2 = fix(log(n1)/log(2)+0.49999); %power of 2 nearest to N
    x = [x, zeros(1,2^(base2+1)-n1)];
    pad = length(x);
end
if pad > 0
    base2 = log(pad)/log(2);
    if rem(base2,1)
        error('pad must be a power of two')
    else
        x = [x, zeros(1,2^(base2)-n1)];
    end
end
n = length(x);  % new data length after zero padding

%  -----------> Upper Period = max Number of Scales
maxPeriod = n*dt;   %maximum Period allowed = T total
numberofScales = fix((log(upperPeriod/so)/log(2))/dj);
j1 = numberofScales;
% ------------> If upperPeriod is too long
largestNumberofScales = fix((log(n*dt/so)/log(2))/dj);
if (j1 == -1), j1 = largestNumberofScales, end  %calcul of the # scales
if j1 > largestNumberofScales
    disp('upperPeriod is too long, it will be adapted')
    j1 = largestNumberofScales;
end

k = [1:fix(n/2)];
k = k.*((2.*pi)/(n*dt));
k= [0., k, -k(fix((n-1)/2):-1:1)];
f = fft(x);

%scale = so*2.^((0:j1)*dj);   %%% -- marc --  %%%
scale = so:dj:fo;  %%% -- marc --  %%%
%Nom_scales = j1;  %%% -- marc --  %%%
Nom_scales = length(scale);  %%% -- marc --  %%%
%wave = zeros(Nom_scales+1, n);  %%% -- marc --  %%%
wave = zeros(Nom_scales, n);  %%% -- marc --  %%%
wave = wave + i*wave;
ventana = length(k);
%for a1 = 1:Nom_scales+1   %%% -- marc --  %%%
for a1 = 1:Nom_scales   %%% -- marc --  %%%
    scal = scale(a1);
    expnt = -(scal.*k-ko).^2/2.*(k > 0.);
    norm = sqrt(scal*k(2))*(pi^(-0.25))*sqrt(ventana);
    daughter = norm*exp(expnt);
    daughter = daughter.*(k > 0.);
    wave(a1,:) = ifft(f.*daughter);
end
period = fourier_factor*scale;
wave = wave(:, 1:n1);

return
