function ccsestimation(t,Data,couleur)

Starting=[0.65,1.7154E-6];
%options=optimset('Display','iter');
%Estimates=fminsearch(@ccsmyfit,Starting,options,t,Data);
Estimates=fminsearch(@ccsmyfit,Starting,[],t,Data);

x = min(t):200000:max(t);
plot(x,Estimates(1)*exp(-Estimates(2)*x),'Color',couleur)
