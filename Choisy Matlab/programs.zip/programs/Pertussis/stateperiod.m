function marc = stateperiod(vecteur,ordersize)
marc = vecteur;
marc = 50-marc;
marc = ordersize(marc);
marc = sort(marc);

%pertussisperiod4 = stateperiod([4:8,11:21,23:25,28,31,32,35:37,39,41,44,46,49],ordersize);
%pertussisperiod3 = stateperiod([2,40,43,48],ordersize);
%pertussisperiod4scaled = stateperiod([1,4:21,23:25,27:32,34:39,41,42,44,46,49],ordersize);
%pertussisperiod3scaled = stateperiod([2,22,40,43,45],ordersize);
%pertussisperiod6pscaled = stateperiod([3,26,33,47,48],ordersize);
%pertussisperiod4scaledext = stateperiod([1,3:21,23:39,41,42,44,46,49],ordersize);
%pertussisperiod3scaledext = stateperiod([2,22,40,43,45,47,48],ordersize);

%states1=[4,1,20,9,10,19,46,38,28,7]
%states2=[4,42,29,45,22,46,14,35,23,15,47,43,40,25,27,49]

%non-scaled, period 4:
%4:8,11:21,23:25,28,31,32,35:37,39,41,44,46,49

%non-scaled, period 3:
%2,40,43,48

%scaled, period 4:
%1,4:21,23:25,27:32,34:39,41,42,44,46,49

%scaled, period 3:
%2,22,40,43,45

%scaled, period >=6:
%(period ~ 4:)
%3,26,33
%(period ~ 3:)
%47,48
