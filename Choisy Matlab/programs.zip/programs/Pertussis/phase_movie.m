output = plotphase(1951,1962,pertussis);

n=length(output);
plotmapphase2(centerspop,output(:,1), 1951+floor(1/12), 1);
fig1=figure(2);
winsize = get(fig1,'Position');
winsize(1:2) = [0 0];
numframes=10;
A=moviein(numframes,fig1,winsize);
set(fig1,'NextPlot','replacechildren')
for i=2:2:2*numframes
    plotmapphase2(centerspop,output(:,i), 1951+floor(i/12), i);
    fig1=figure(i+1);
    A(:,i)=getframe(fig1,winsize);
    %print -d
end
movie(fig1,A,2,3,winsize);
    