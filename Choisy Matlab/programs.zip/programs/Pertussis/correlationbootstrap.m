function sortie = correlationbootstrap(pertussis,deb,fin,bootnb)

%tic;sortie=plotcorrelationbootstrap(pertussis,1951,1962,1000);toc
%Export : width = 12cm

%% S�lection des ann�es :
dataset = pertussis(find((pertussis(:,1)>=deb)&(pertussis(:,1)<=fin)),3:end);

%% Calcul et bootstrap de la matrice des coefficients de corr�lation :
correlations = corrcoef(dataset);
correlations = tril(correlations);
correlations = correlations(find((correlations~=0)&(correlations<1)));
if length(correlations)~=1176
    disp('Problem!')
end
bootstrap = mean(bootrsp(correlations,bootnb));
sortie = [mean(correlations) bootstrap];

