function plotccspertussis2(pertussis,popsizes,dates)
ccsperiods(pertussis,popsizes,dates(1),dates(2),[0 0 1])
hold on
ccsperiods(pertussis,popsizes,dates(3),dates(4),[1 0 0])
hold off
xlabel('population size')
ylabel('proportion of months with fadeouts')
title('Pertussis CCS for the first three periods - Lag = 5')
legend('Period 1','Period 1','Period 2-3','Period 2-3')

%plotccspertussis2(pertussis,popsizes,[1951-5 1962 1963 1991]+5)