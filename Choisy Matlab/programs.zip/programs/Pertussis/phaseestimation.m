function [f dfe dfr pval] = phaseestimation(t,Data,couleur)

Starting=[8e-4,1];
options=optimset('Display','iter');

%% Exstimations :
%Estimates=fminsearch(@phasemyfit,Starting,options,t,Data);
Estimates=fminsearch(@phasemyfit,Starting,[],t,Data);

%% Graphique :
x = min(t):max(t);
plot(x,Estimates(1)*x+Estimates(2),'Color',couleur)

%% Statistiques de sortie :
n = length(t);
p = length(Estimates);
sse = phasemyfit(Estimates,t,Data);
yfit = Estimates(1)*t+Estimates(2);
ssr = norm(yfit - mean(yfit)).^2;
dfe = n-p;
dfr = p-1;
f = (ssr/dfr)/(sse/dfe);
pval = 1-fcdf(f,dfr,dfe);
