function plotdistancepopsize(centers,sizes,states)

%tic;plotdistancepopsize(centerspop,popsizes(2:end,5),1:49);toc
%tic;plotdistancepopsize(centerspop,popsizes(2:end,5),pertussisperiod4);toc
%tic;plotdistancepopsize(centerspop,popsizes(2:end,5),pertussisperiod4scaled);toc
%tic;plotdistancepopsize(centerspop,popsizes(2:end,5),pertussisperiod4scaledext);toc

%export : width = 12 cm.

%% Calcul des distances
phi1 = centers(31,2)*pi/180;
lambda1 = centers(31,1)*pi/180;
rayon = 6378;
lesdistances = 0;
for i=1:49
    phi2 = centers(i,2)*pi/180;
    lambda2 = centers(i,1)*pi/180;
    delta = lambda1-lambda2;
    lesdistances = [lesdistances;...
        rayon*atan(sqrt((cos(phi2)*sin(delta))^2+...
        (cos(phi1)*sin(phi2)-sin(phi1)*cos(phi2)*cos(delta))^2)/...
        (sin(phi1)*sin(phi2)+cos(phi1)*cos(phi2)*cos(delta)))];
end
lesdistances(1) = [];

%% S�lection des �tats :
lesdistances = lesdistances(states);
tailles = sizes(states);

%% Calcul des bins :
range = 0:500:4000;
histoY = 0;
for i = 1:length(range)-1
    histoY = [histoY; sum(tailles(find((lesdistances>=range(i))&(lesdistances<range(i+1)))))];
end
histoY(1)=[];

%% Create figure
figure1 = figure('PaperPosition',[0.6345 6.345 20.3 15.23],'PaperSize',[20.98 29.68]);
 
%% Create axes
axes1 = axes(...
  'XDir','reverse',...
  'XTick',[250 750 1250 1750 2250 2750 3250 3750],...
  'Box','on',...
  'Parent',figure1);
hold(axes1,'all');

%% Graphique
bar(250:500:4000,histoY,'FaceColor',[0 0 0])   
xlabel('distance from New York (km)')
ylabel('population size in 1960')
title('Distance-Population Size Relationship')

