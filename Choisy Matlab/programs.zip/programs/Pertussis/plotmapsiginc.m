function plotmapsiginc(centers,states,P3,immigration)

%plotmapperiod2(centerspop,pertussisperiod3scaledext,pertussisperiod4scaled
%ext)
% export : width : 14 cm.

%% Taille des points sur la carte :
taillemap = 40;

%% Travail sur les donn�es.
%% Les donn�es du fond de carte.
tmp = load('usa.mat','-mat');
x = tmp.x;
y = tmp.y;
tmp = find(isnan(x));
x(tmp(1):end)=[];
y(tmp(1):end)=[];

%% Set the figure properties.
figure1 = figure(...
  'Color',[1 1 1],...
  'PaperPosition',[0.6345 6.345 20.3 15.23],...
  'PaperSize',[20.98 29.68]);

%% Set the figure axes properties.
%'Position',[0.06429 0.119 0.9336 0.8036],...
%'Position',[-0.04464 -0.07862 1.13 1.145],...
axes1 = axes('DataAspectRatio',[1.387247 1 1],...
             'Position',[-0.04464 -0.07862 1.13 1.145],...             
             'XColor',[1 1 1],...
             'YColor',[1 1 1],...
             'ZColor',[1 1 1]);
axis(axes1,[-130 -60 24 50]);
hold(axes1,'all');

%% Plot the map.
plot1 = plot(x,y,'k','Parent',axes1);

%% Plot the states with significant increase.
for i=1:length(P3)
    plot(centers(P3(i),1),centers(P3(i),2),'.','MarkerSize',taillemap,...
        'Color',[0 0 1],'Parent',axes1);
    out=[strcat(states(P3(i)))];
    %text(centers(P3(i),1)+0.1*P3(i),centers(P3(i),2),out);
    gtext(out);
end


%% L�gende :
%plot(-120,26,'.','MarkerSize',taillemap,'Color',[1 0 0],'Parent',axes1)
plot(-120,28,'.','MarkerSize',taillemap,'Color',[0 0 1],'Parent',axes1)
annotation1 = annotation(...
  figure1,'textbox',...
  'Position',[0.125 0.1817 0.1607 0.07222],...
  'LineStyle','none',...
  'String',{'Significant Re-emergence'},...
  'FitHeightToText','on');