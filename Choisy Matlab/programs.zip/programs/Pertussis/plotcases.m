function plotcases(dataset,start,last,states, immigration, popsizes,popsizesbyyear, usbirthrates, centers)
%function plotdata(dataset,start,last,usbirths, states, immigration,popsizes)
%plots data from 49 states
%fits linear regression to explore increase
%correlates with (i)%foreign residents, (ii)#immigrating 1990-2000
%and population size

%plotcases(pertussis,1994, 2003, states,immigration, popsizes,popsizesbyyear, usbirthrates)
load vacc3.dat;
vacc3 = vacc3([2, 4:12, 14:52],:);
load vacc4.dat;
vacc4 = vacc4([2, 4:12, 14:52],:);

time = dataset((dataset(:,1)>=start)&(dataset(:,1)<=last),[1 2]);
time = time(:,1)+time(:,2)./12;
pop = popsizesbyyear((popsizesbyyear(:,1)>=start)&(popsizesbyyear(:,1)<=last),...
    [2:50]);
%    [2:length(popsizesbyyear)]);
X= [ones(size(time)) time];

%%
%plot the data in 4x4 grids
len=last-start+1;
nplots=4;
for i=1:length(dataset(1,:)')-2
    data = (dataset((dataset(:,1)>=start)&(dataset(:,1)<=last),i+2));
    
    for j=1:len
        newpop2(1:12,j)=ones(12,1).*pop(j,i+1);
    end;
    newpop = reshape(newpop2,1,len*12)';
    newdata=data./newpop;
    %    newdata=newdata./max(newdata);
    %    [b,bint,r,rint,stats] = regress(data,X);
    [b,bint,r,rint,stats] = regress(newdata,X);
    
    figure(ceil(i/(nplots*nplots)));
    plotno=mod(i,nplots*nplots);
    if plotno==0 plotno=nplots*nplots; end;
    subplot(nplots,nplots,plotno);
    line(time,newdata,'color','b','linewidth',2);
    line(time,b(1)+b(2).*time,'color','r','linewidth',2);
%     axis([1993 2004 0 max(newdata)]);
%     set(gca,'XTick',[1994, 1998, 2011])

    if bint(2,:)>0
        out=['p = ',num2str(stats(3))];
        %gtext(out,'fontsize',8);
        slopes_sig(i)=b(2);
    end
    xlabel 'Year'
    ylabel 'Monthly Cases'
    title(strcat(states(i)));
    slopes(i)=b(2);
end;
%%
%plot the slopes of linear regression against immigration parameters
%(i) % foreign residents in any state, (ii) immigrants over past decade

figure(5);
subplot(2,1,1);
plot(immigration(:,1),slopes,'o','Markersize',10);
X=[ones(size(immigration(:,1))) immigration(:,1)];
[b,bint,r,rint,stats] = regress(slopes',X);
hold on;
line(immigration(:,1), b(1)+b(2).*immigration(:,1),'color','r','linewidth',2);
out=['p = ',num2str(stats(3))];
title(out);
xlabel '% Foreign Residents';
out=['Linear Slope ',num2str(start),' - ',num2str(last)];
ylabel(out);

subplot(2,1,2);
plot(immigration(:,2)./immigration(:,3),slopes,'o','Markersize',10);
X=[ones(size(immigration(:,2))) immigration(:,2)./immigration(:,3)];
[b,bint,r,rint,stats] = regress(slopes',X);
hold on;
line(immigration(:,2)./immigration(:,3), b(1)+b(2).*immigration(:,2)./immigration(:,3),'color','r','linewidth',2);
out=['p = ',num2str(stats(3))];
title(out);
xlabel 'Immigration 1990-2000 (as fraction)'
out=['Linear Slope ',num2str(start),' - ',num2str(last)];
ylabel(out);
%%
%Look for correlations between slopes and Population Size

figure(6);
subplot(3,1,1);
plot(popsizes(2:end,2),slopes,'o','Markersize',10);
X=[ones(size(popsizes(2:end,1))) (popsizes(2:end,2))];
[b,bint,r,rint,stats] = regress(slopes',X);
hold on;
line(popsizes(2:end,2), b(1)+b(2).*(popsizes(2:end,2)),'color','r','linewidth',2);
out=['p = ',num2str(stats(3))];
title(out);
xlabel 'Population Size 1990'
out=['Linear Slope ',num2str(start),' - ',num2str(last)];
ylabel(out);

subplot(3,1,2);
plot(popsizes(2:end,1)-popsizes(2:end,2),slopes,'o','Markersize',10);
X=[ones(size(popsizes(2:end,1))) (popsizes(2:end,1)-popsizes(2:end,2))];
[b,bint,r,rint,stats] = regress(slopes',X);
hold on;
line(popsizes(2:end,1)-popsizes(2:end,2), b(1)+b(2).*(popsizes(2:end,1)-popsizes(2:end,2)),'color','r','linewidth',2);
out=['p = ',num2str(stats(3))];
title(out);
xlabel 'Population Size 2000 - Population Size 1990'
out=['Linear Slope ',num2str(start),' - ',num2str(last)];
ylabel(out);

subplot(3,1,3);
plot((popsizes(2:end,1)-popsizes(2:end,2))./popsizes(2:end,2),slopes,'o','Markersize',10);
X=[ones(size(popsizes(2:end,1))) (popsizes(2:end,1)-popsizes(2:end,2))./popsizes(2:end,2)];
[b,bint,r,rint,stats] = regress(slopes',X);
hold on;
line((popsizes(2:end,1)-popsizes(2:end,2))./popsizes(2:end,2), ...
    b(1)+b(2).*(popsizes(2:end,1)-popsizes(2:end,2))./popsizes(2:end,2),...
    'color','r','linewidth',2);
out=['p = ',num2str(stats(3))];
title(out);
xlabel 'Relative Population Change'
out=['Linear Slope ',num2str(start),' - ',num2str(last)];
ylabel(out);
%%
births = usbirthrates((usbirthrates(:,1)>=start)&(usbirthrates(:,1)<=last),2);

figure(7)
subplot(2,1,1);
v3=mean(vacc3');
plot(v3,slopes,'o','Markersize',10);
X=[ones(length(v3),1) v3'];
[b,bint,r,rint,stats] = regress(slopes',X);
hold on;
line(v3, b(1)+b(2).*(v3),'color','r','linewidth',2);
out=['p = ',num2str(stats(3))];
title(out);
out=['Linear Slope ',num2str(start),' - ',num2str(last)];
ylabel(out);
out=['Mean Vaccination Coverage (3 doses)'];
xlabel(out);

subplot(2,1,2);
v4=mean(vacc4');
plot(v4,slopes,'o','Markersize',10);
X=[ones(length(v4),1) v4'];
[b,bint,r,rint,stats] = regress(slopes',X);
hold on;
line(v4, b(1)+b(2).*(v4),'color','r','linewidth',2);
out=['p = ',num2str(stats(3))];
title(out);
out=['Linear Slope ',num2str(start),' - ',num2str(last)];
ylabel(out);
out=['Mean Vaccination Coverage (4 doses)'];
xlabel(out);

