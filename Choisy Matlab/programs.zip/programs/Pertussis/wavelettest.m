function [pv5,pv1,gm5_ws,gm1_ws,fm5_var,fm1_var] = ...
     wavelettest(y,var_y,power,dt,dj,scale,lowP,upP,lowPF,upPF,pad,test,ns,ps,nbin,amp);
%
%  Statistical tests for same "outputs" of the wavelet transform of the series y
%                          by different boostrapping approaches (test=1,2,3,4,5)
%                          or by compariosn with white or red noise (test=10,11)
%
%  function [pv5,pv1,gm5_ws,gm1_ws,fm5_var,fm1_var] = ...
%     wavelettest(y,var_y,power,dt,dj,scale,lowP,upP,lowPF,upPF,pad,test,ns,ps,nbin,amp)
%
%--------- INPUTS
% y        : input time series 
% var_y    : variance of y
% power    : power wavelet spectrum
% dt       : observation time step
% dj       : frequency resolution (ie number of sub-octaves)
% scale    : vector of the wavelet scale employed during the computation 
% lowP     : lower period of the decomposition
% upP      : upper period of the decomposition
% lowerPF  : lower value of the period used for filtering some of the output 
%            (filtr_ts, filtr_var, phase_ts)
% upperPF  : upper value of the period used for filtering some of the output
%            (filtr_ts, filtr_var, phase_ts)
% pad      : in case of zero padding (it must be a power of two)
% test     : test options: 1 simple bootstrap,   2 bootstap with constant block
%                          3 bootstrap by block, 4 bootstap with random block
%                          5 surrogate with Hidden Markow Model
%                          6 surrogate with Fourier randomization
%                          7 surrogate with Fourier gaussian amplitude-adjusted
%                         10 comparison with white noise, 11  with red noise
% ns       : number of surrogate or boostrapped series
% ps       : length of block or probability of changing block for the boostrap functions
%            or parameter of the gaussian amplitude-adjusted surrogates (ps = 1 or 2 or 3)
% nbin     : number of bin used for the distribution of the raw series in test=5
% amp      : power of 10 for the minima and maxima computations (example amp=10)
%
%--------- OUTPUT
% pv5      : matrice of the Pvalue of the power wavelet, for test = 10,11 it's just the 5% level
% pv1      : matrice of the Pvalue of the power wavelet, for test = 10,11 it's just the 1% level
% gm5_ws   : 5% significance level for the average wavelet spectrum of y
% gm1_ws   : 1% significance level for the average wavelet spectrum of y
% fm5_var  : 5% significance level for the average variance of the series
% fm1_var  : 1% significance level for the average variance of the series

n_y = length(y);
del = 0.776;
avg = find((scale >= lowPF) & (scale < upPF));
n = size(power);
nl = n(1);
nc = n(2);

pv5 = zeros(n);
gws = zeros(1,nl);
gm_ws = zeros(1,nl);
gs2_ws = zeros(1,nl);
fvb = zeros(1,nc);
m_fvb = zeros(1,nc);
m2_fvb = zeros(1,nc);

if test < 10 
   for i=1:ns
      if test==1
         yb = BootsBloc(y,1);
      elseif test==2
         yb = BootsFixe(y,ps);
      elseif test==3
         yb = BootsFix2(y,ps);
      elseif test==4
         yb = BootsBloc(y,ps);
      elseif test==5
         if i==1; [nw,nb,vbin,trans] = ProbaTransition(y,n_y,nbin,amp); end
         yb = SurrogateHMM(y,n_y,nbin,2,nw,nb,vbin,trans);
      elseif test==6
         yb  = FourierSurrogate1(y,sum(1000*clock));
      elseif test==7
         if ps < 1; ps = 1; end
         if ps > 3; ps = 1; end
         yb = FourierSurrogate2(y,ps,sum(1000*clock));
      end
      [wb,period,scale] = wavelettransform(yb,dt,dj,lowP,upP,pad);
      powb = (abs(wb)).^2;
      for j=1:nl
        for k=1:nc
             if powb(j,k) >= 1*power(j,k)
                pv5(j,k) = pv5(j,k) + 1;
             end
          end
      end
      gws = var_y*(sum(powb')/n_y);
      gm_ws = gm_ws + gws;
      gs2_ws = gs2_ws + gws.^2;
      fvb = scale'*(ones(1,nc));
      fvb = powb ./ fvb;
      fvb = var_y*dj*dt/del*sum(fvb(avg,:));
      m_fvb = m_fvb + fvb;
      m2_fvb = m2_fvb + fvb.^2;
   end

   pv5 = pv5/ns;
   pv1 = pv5;
   gm5_ws = gm_ws/ns + 1.645*sqrt((gs2_ws - gm_ws.^2/ns)/(ns-1));
   gm1_ws = gm_ws/ns + 2.326*sqrt((gs2_ws - gm_ws.^2/ns)/(ns-1));
   fm5_var = m_fvb/ns + 1.645*sqrt((m2_fvb - m_fvb.^2/ns)/(ns-1));
   fm1_var = m_fvb/ns + 2.326*sqrt((m2_fvb - m_fvb.^2/ns)/(ns-1));

elseif test >= 10

   if abs(mean(y)) > 0.0000001
      fprintf('the use of noise tests needs signal with zero mean        \n')
      fprintf('you will not be able to interpret the results of the test \n')
      fprintf('you must employ bootstrap approaches or normalized signal \n')
   end
   if test == 10
      lag = 0;
   elseif test == 11
      lag = 1;
   end
   [pv5,pv1,gm5_ws,gm1_ws,fm5_var,fm1_var] = wavelettestnoise(y,var_y,lag,dt,dj,scale,lowPF,upPF);
   pv5 = (pv5')*ones(1,n_y);
   pv5 = 0.05*pv5./power;         %   pv5 = power./pv5; 
   pv1 = (pv1')*ones(1,n_y);      %   pv1 = power./pv1;
   pv1 = 0.01*pv1./power;
   fm5_var = fm5_var*ones(1,n_y);
   fm1_var = fm1_var*ones(1,n_y);

end

return
