function plotphase3SCGA(start,last,dataset,state1,state2)

%% For South Carolina et Georgia :
%plotphase3SCGA(1951,1962,pertussis,41,12)
% Export : width = 16 cm.

%% Couleurs :
nbcol = 1000;
couleurs = jet(nbcol+1);

%% Calcul des phases :
laphase = phase(start,last,dataset(:,[1 3]));
for i = 4:51
    ph = phase(start,last,dataset(:,[1 i]));
    laphase = [laphase; ph];
end

%% Les couleurs de chaque population :
marc = laphase(:,1);
marc = max(marc)-marc; % Met la phase 0 sur les c�tes.
couleurs = jet(nbcol+1);
marc = (marc-min(marc))/(2*pi);
coul1 = round(marc(state1-2)*1000)+1;
coul2 = round(marc(state2-2)*1000)+1;

%% Figure and axes properties :

figure1 = figure('PaperPosition',[0.6345 6.345 20.3 15.23],...
    'PaperSize',[20.98 29.68]);

axes1 = axes('Position',[0.13 0.7 0.775 0.19],...
    'XTick',1:12:156,'XTickLabel',{},...
    'YTick',[0 200 400],...
    'YTickLabel',{'0','200','400'},...    
    'Box','on','Parent',figure1);
axis(axes1,[0 145 0 400]);
ylabel(axes1,'cases');
hold(axes1,'all');

axes2 = axes('Position',[0.13 0.5 0.775 0.19],...
    'XTick',1:12:156,'XTickLabel',{},'Box','on',...
    'YTick',[0 2 4 6],...
    'YTickLabel',{'0','2','4','6'},...        
    'YAxisLocation','right','Parent',figure1);
axis(axes2,[0 145 0 6]);
ylabel(axes2,'log_{10}(cases)');
hold(axes2,'all');

axes3 = axes('Position',[0.13 0.3 0.775 0.19],...
    'XTick',1:12:156,'XTickLabel',{},'Box','on',...
    'YTick',[-1 0 1],...
    'YTickLabel',{'-1' '0' '1'},...        
    'Parent',figure1);
axis(axes3,[0 145 -1.5 1.5]);
ylabel(axes3,'quadriennal component');
hold(axes3,'all');

axes4 = axes('Position',[0.13 0.1 0.775 0.19],...
    'XTick',1:12:156,'XTickLabel',{'1951','1952',...
    '1953','1954','1955','1956','1957','1958','1959',...
    '1960','1961','1962','1963'},'Box','on','YAxisLocation','right',...
    'Parent',figure1);
axis(axes4,[0 145 -4 4]);
xlabel(axes4,'year')
ylabel(axes4,'phase (radians)')
hold(axes4,'all');

%% Les graphiques :

deb = (start-dataset(1,1))*12+1;
fin = (last-start+1)*12;

plot(dataset(deb:fin,state1),'Color',couleurs(coul1,:),'Parent',axes1);
plot(dataset(deb:fin,state2),'Color',couleurs(coul2,:),'Parent',axes1);

plot(log(dataset(deb:fin,state1)),'Color',couleurs(coul1,:),'Parent',axes2);
plot(log(dataset(deb:fin,state2)),'Color',couleurs(coul2,:),'Parent',axes2);

xxx = lefiltre(start,last,dataset(:,[1 state1]));
plot(xxx,'Color',couleurs(coul1,:),'Parent',axes3);
xxx = lefiltre(start,last,dataset(:,[1 state2]));
plot(xxx,'Color',couleurs(coul2,:),'Parent',axes3);

xxx = phase(start,last,dataset(:,[1 state1]));
plot(xxx,'Color',couleurs(coul1,:),'Parent',axes4);
xxx = phase(start,last,dataset(:,[1 state2]));
plot(xxx,'Color',couleurs(coul2,:),'Parent',axes4);

%% Create legend
legend1 = legend(axes1,{'South Carolina','Georgia'},...
    'Position',[0.6374 0.7814 0.2554 0.09524]);

%% Create textarrow
annotation1 = annotation(...
  figure1,'textbox',...
  'Position',[0.4394 0.8835 0.1607 0.06681],...
  'LineStyle','none',...
  'HorizontalAlignment','center',...
  'String',{'Pertussis'},...
  'FitHeightToText','on');

