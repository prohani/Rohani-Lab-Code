function plotcorrelationsize(dataset,centers,popsizes,deb,fin)

%plotcorrelationsize(pertussis,centerspop,popsizesbyyear,1951,2003)
%Export : width = 12cm

% Param�tre de tension de la r�gression spline :
tension = 1e-8;

%% S�lection et transformation des donn�es :
pertussis = dataset((dataset(:,1)>=deb)&(dataset(:,1)<=fin),:);
%pertussis = log(pertussis+1);
tailles = mean(popsizes((popsizes(:,1)>=deb)&(popsizes(:,1)<=fin),2:end));

%% Cr�ation des quatres groupes de taille :
nbstate = size(pertussis);
nbstate = nbstate(2)-2;
[x indices] = sort(tailles);
q1 = round(nbstate*0.25);
q2 = round(nbstate*0.5);
q3 = round(nbstate*0.75);

%% Calcul des coefficients de correlation :
%% Q1-Q1 :
Q1Q1 = tril(corrcoef(pertussis(:,indices(1:q1)+2)));
Q1Q1 = Q1Q1(find((Q1Q1>-1)&(Q1Q1<1)&(Q1Q1~=0)));
%% Q1-Q2, Q1-Q3, Q1-Q4 :
Q1Q2 = 0;
Q1Q3 = 0;
Q1Q4 = 0;
for i=1:q1
    for j=q1+1:q2
        coeff = corrcoef(pertussis(:,[indices(i) indices(j)]+2));
        Q1Q2 = [Q1Q2;coeff(1,2)];
    end
    for j=q2+1:q3
        coeff = corrcoef(pertussis(:,[indices(i) indices(j)]+2));
        Q1Q3 = [Q1Q3;coeff(1,2)];
    end
    for j=q3+1:nbstate
        coeff = corrcoef(pertussis(:,[indices(i) indices(j)]+2));
        Q1Q4 = [Q1Q4;coeff(1,2)];
    end
end
Q1Q2(1) = [];
Q1Q3(1) = [];
Q1Q4(1) = [];
%% Q2-Q2 :
Q2Q2 = tril(corrcoef(pertussis(:,indices(q1+1:q2)+2)));
Q2Q2 = Q2Q2(find((Q2Q2>-1)&(Q2Q2<1)&(Q2Q2~=0)));
%% Q2-Q3, Q2-Q4 :
Q2Q3 = 0;
Q2Q4 = 0;
for i=q1+1:q2
    for j=q2+1:q3
        coeff = corrcoef(pertussis(:,[indices(i) indices(j)]+2));
        Q2Q3 = [Q2Q3;coeff(1,2)];
    end
    for j=q3+1:nbstate
        coeff = corrcoef(pertussis(:,[indices(i) indices(j)]+2));
        Q2Q4 = [Q2Q4;coeff(1,2)];
    end
end
Q2Q3(1) = [];
Q2Q4(1) = [];
%% Q3-Q3 :
Q3Q3 = tril(corrcoef(pertussis(:,indices(q2+1:q3)+2)));
Q3Q3 = Q3Q3(find((Q3Q3>-1)&(Q3Q3<1)&(Q3Q3~=0)));
%% Q3-Q4 :
Q3Q4 = 0;
for i=q2+1:q3
    for j=q3+1:nbstate
        coeff = corrcoef(pertussis(:,[indices(i) indices(j)]+2));
        Q3Q4 = [Q3Q4;coeff(1,2)];
    end
end
Q3Q4(1) = [];
%% Q4-Q4 :
Q4Q4 = tril(corrcoef(pertussis(:,indices(q3+1:end)+2)));
Q4Q4 = Q4Q4(find((Q4Q4>-1)&(Q4Q4<1)&(Q4Q4~=0)));

%% Graphique
yyy = [Q1Q1;Q1Q2;Q1Q3;Q1Q4;Q2Q2;Q2Q3;Q2Q4;Q3Q3;Q3Q4;Q4Q4];
xxx = [ones(length(Q1Q1),1);2*ones(length(Q1Q2),1);3*ones(length(Q1Q3),1);...
    4*ones(length(Q1Q4),1);5*ones(length(Q2Q2),1);6*ones(length(Q2Q3),1);...
    7*ones(length(Q2Q4),1);8*ones(length(Q3Q3),1);9*ones(length(Q3Q4),1);...
    10*ones(length(Q4Q4),1)];
boxplot(yyy,xxx)
set(gca,...
    'XTick',[1 2 3 4 5 6 7 8 9 10],...
    'XTickLabel',{'Q1','','','','Q2','','','Q3','','Q4'});
xlabel('population sizes (quartiles)')
ylabel('correlation coefficient')
%axis([0.5 10.5 -0.05 1.05])
axis([0.5 10.5 -0.4 0.9])
h = findobj('Color','r');
set(h,'Color','k')
h = findobj('Color','b');
set(h,'Color','k')
%h = findobj('LineStyle','--');
%set(h,'LineStyle',':')






