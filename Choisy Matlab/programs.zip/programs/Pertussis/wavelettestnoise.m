function [pv5_scalog,pv1_scalog,pv5_spec,pv1_spec,pv5_var,pv1_var] = ...
     wavelettestnoise(y,var_y,lag,dt,dj,scale,lowPF,upPF)
%
%  [pv5_scalog,pv1_scalog,pv5_spec,pv1_spec,pv5_var,pv1_var] = ...
%     WaveletTestNoise(y,var_y,lag,dt,dj,scale,lowPF,upPF)
%
%------------ INPUTS
% y           : input time series 
% var_y       : variance of y
% lag         : lag~=0 for a test with a red noise, the AR(1) parameter will be computed
% dt          : observation time step
% dj          : frequency resolution (ie number of sub-octaves)
% scale       : vector of the wavelet scale employed during the computation 
% lowP        : lower period of the decomposition
% upP         : upper period of the decomposition
%
%------------ OUTPUT
% pv5_scalog  : matrice of the Pvalue of the power wavelet at the level 5%
% pv1_scalog  : matrice of the Pvalue of the power wavelet at the level 1%
% pv5_spec    : 5% significance level for the average wavelet spectrum of y
% pv1_spec    : 1% significance level for the average wavelet spectrum of y
% pv5_var     : 5% significance level for the average variance of y
% gv1_var     : 1% significance level for the average variance of y

n = length(y);
ns = length(scale) - 1;
alpha5 = 0.95;
alpha1 = 0.99;

if lag~=0
   % coef of the AR(1) process
   % possibility of using a AR(2) with p=2 and X2=y(p+1-1:n-2); X=[X1 X2]
   p = 1;
   Y = y(p+1:n);
   X1 = y(p+1-1:n-1);
   X = [X1];
   par = inv(X'*X)*X'*Y;
   lag = par(1);
end

k0 = 6;
fourier_factor = (4*pi)/(k0 + sqrt(2 + k0^2));

period = scale.*fourier_factor;
dof = 2;               % Degrees of freedom with no smoothing
dofmin = dof;
Cdelta = 0.776;        % reconstruction factor
gamma_fac = 2.32;      % time-decorrelation factor
dj0 = 0.6;             % scale-decorrelation factor

freq = dt./ period;
fft_theor = (1-lag^2) ./ (1-2*lag*cos(freq*2*pi)+lag^2);
fft_theor = var_y*fft_theor;

% significance level associated to the wavelet power spectrum
%
chisq5 = chisquarequantile(alpha5,dof)/dof;
chisq1 = chisquarequantile(alpha1,dof)/dof;
pv5_scalog = fft_theor*chisq5;
pv1_scalog = fft_theor*chisq1;

% significance level associated to the time-averaged spectrum
%
dof = n - scale;
truncate = find(dof < 1);
dof(truncate) = ones(size(truncate));
dof = dofmin*sqrt(1 + (dof*dt/gamma_fac./scale).^2);
truncate = find(dof < dofmin);
dof(truncate) = dofmin*ones(size(truncate));
for i=1:ns+1
   chisq5 = chisquarequantile(alpha5,dof(i))/dof(i);
   chisq1 = chisquarequantile(alpha1,dof(i))/dof(i);
   pv5_spec(i) = fft_theor(i)*chisq5;
   pv1_spec(i) = fft_theor(i)*chisq1;
end

% significance level associated to the time-averaged variance in a defined band
%
dof = 2;
avg = find((scale >= lowPF) & (scale < upPF));
navg = length(avg);
if (navg == 0)
   error(['No valid scales between ',num2str(lowPF),' and ',num2str(upPF)])
end
Savg = 1./sum(1./scale(avg));
Smid = exp((log(lowPF)+log(upPF))/2.);
dof = (dofmin*navg*Savg/Smid)*sqrt(1 + (navg*dj/dj0)^2);
fft_theor = Savg*sum(fft_theor(avg)./scale(avg));
chisq5 = chisquarequantile(alpha5,dof)/dof;
chisq1 = chisquarequantile(alpha1,dof)/dof;
pv5_var = (dj*dt/Cdelta/Savg)*fft_theor*chisq5;
pv1_var = (dj*dt/Cdelta/Savg)*fft_theor*chisq1;

return
