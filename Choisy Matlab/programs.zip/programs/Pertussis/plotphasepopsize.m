function sortie = plotphasepopsize(centers,start,last,dataset,sizes,states,inf,sup)

%tic;sortie=plotphasepopsize(centerspop,1951,1962,pertussis,popsizes(2:end,5),1:49,0,1000);toc
%tic;sortie=plotphasepopsize(centerspop,1951,1962,pertussis,popsizes(2:end,5),pertussisperiod4,0,1000);toc
%tic;sortie=plotphasepopsize(centerspop,1951,1962,pertussis,popsizes(2:end,5),pertussisperiod4scaled,0,1000);toc
%tic;sortie=plotphasepopsize(centerspop,1951,1962,pertussis,popsizes(2:end,5),pertussisperiod4scaledext,0,1000);toc

%export : width = 12 cm.

%% Calcul des distances
phi1 = centers(31,2)*pi/180;
lambda1 = centers(31,1)*pi/180;
rayon = 6378;
lesdistances = 0;
for i=1:49
    phi2 = centers(i,2)*pi/180;
    lambda2 = centers(i,1)*pi/180;
    delta = lambda1-lambda2;
    lesdistances = [lesdistances;...
        rayon*atan(sqrt((cos(phi2)*sin(delta))^2+...
        (cos(phi1)*sin(phi2)-sin(phi1)*cos(phi2)*cos(delta))^2)/...
        (sin(phi1)*sin(phi2)+cos(phi1)*cos(phi2)*cos(delta)))];
end
lesdistances(1) = [];

%% Calcul des diff�rences de phases.
laphase = phase(start,last,dataset(:,[1 3]));
for i = 4:51
    ph = phase(start,last,dataset(:,[1 i]));
    laphase = [laphase; ph];
end
differences = laphase;
newyork = differences(31,:);
for i=1:49
    differences(i,:) = newyork-differences(i,:);
end
differences = mod(differences+3*pi,2*pi)-pi;
% Gestion du Montana :
indices = find(differences(25,:)<0);
differences(25,indices) = differences(25,indices)+2*pi;

%% Calcul des moyennes et de leur intervale de confiance.
moyenne = [0 0 0];
for i = 1:49
    [muL,muU] = confinth(differences(i,:),'mean',0.05,1000);
    moyenne = [moyenne;mean(differences(i,:)),muL,muU];
end
moyenne(1,:) = [];

%% S�lection des �tats :
lesdistances = lesdistances(states);
tailles = sizes(states);
moyenne = moyenne(states,:);

%% Graphique
indices = find((lesdistances<=sup)&(lesdistances>inf));
plot(tailles(indices),moyenne(indices,1),'.k','MarkerSize',10)
hold on
for i = 1:length(indices)
    plot([tailles(indices(i)) tailles(indices(i))],moyenne(indices(i),2:3),'-k')
end
hold off
xlabel('population size in 1960')
ylabel('phase difference from New York (radians)')
title('49 Pertussis < 1000 km from NY')

sortie = [tailles moyenne];

