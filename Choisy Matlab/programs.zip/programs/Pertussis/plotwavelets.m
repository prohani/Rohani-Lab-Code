function plotwavelets(pop,start,last,statename,states)

%plotwavelets(pertussis,1951,1962,31,states)
%plotwavelets(pertussis,1994,2003,31,states)
%Export : width = 15 cm.

cor = 100;
xlim = [start last+1];
ys = pop(:,[1 statename+2]);
ys = ys((ys(:,1)>=start)&(ys(:,1)<=last),2);

%% Transformation des donn�es
%ys = pop;
%ys = log(pop+1);
%ys = (pop-mean(pop))/std(pop);
%ys = (log(pop+1)-mean(log(pop+1)))/std(log(pop+1));
ys = (sqrt(ys)-mean(sqrt(ys)))/std(sqrt(ys));
dt = 1/12;  % donn�es mensuelles.
time = start:dt:last+1;
time(end) = [];

%% Param�tres de la transform�e d'ondelettes. L'ondelette est dans "wave".
dj = 1/100; % frequency resolution (i.e. number of sub-octaves).
pad = 128;  % for 0-padding (it must be a power of 2).
lowerPeriod = 0.1;
upperPeriod = 6;
[wave,period,scale,coi] = wavelettransform(ys,dt,dj,lowerPeriod,upperPeriod,pad);

%% Calcul des sorties � partir de "wave".
var_y = std(ys)^2;
lowerPF = 1.5; upperPF = 2.5;   % p�riodes filtr�es (non utilis� ici).
[power,realwav,imagwav,global_ws,filtr_ts,filtr_var,phase_ts] = waveletoutput(wave,period,scale,ys,var_y,dt,dj,lowerPF,upperPF);

%% Test : au d�part utiliser test=11 (i.e. comparaison avec un bruit rouge).
n_y = length(ys);
m_y = mean(ys); 
test = 11;  % comparaison avec un bruit rouge.
ns = 100;   % nombre de r�-�chantillonage bootstrap.
pvalue = 5;
ps = 1;     % autre param�tre de bootstrap.
nbin = n_y; % param�tre utile si test = 5.
amp = 10;
[pvp,pvp1,gm5_ws,gm1_ws,fm5_var,fm1_var] = wavelettest(ys,var_y,power,dt,dj,scale,lowerPeriod,upperPeriod,lowerPF,upperPF,pad,test,ns,ps,nbin,amp);
if pvalue == 5
   gm_ws = gm5_ws;
   fm_var = fm5_var;
elseif pvalue == 1
   gm_ws = gm1_ws;
   fm_var = fm1_var;
   if test > 10
      pvp5 = pvp;
      pvp = pvp1;
   end;
end

%% Les graphiques :
figure 

%% La s�rie temporelle :
subplot('position',[0.1 0.58 0.65 0.33])
plot(time,ys)
set(gca,'XLim',xlim(:))
ylabel('std(sqrt(cases))')
title('Time series')

%% Le spectre de puissance des ondelettes :
subplot('position',[0.1 0.08 0.65 0.38])
Yticks = [0.5 1 2 3 4 5];
imagesc(time,period,power.^.3);
xlabel('time (year)')
ylabel('period (year)')
title('Wavelet power spectrum')
set(gca,'XLim',xlim(:))
set(gca,'YLim',[min(period),max(period)],'YDir','reverse',...
	'YTick',Yticks(:),'YTickLabel',Yticks)
hold on
contour(time,period,pvp,[pvalue/cor,1],'k--');
plot(time,coi,'w')
hold off

%% Le spectre global :
subplot('position',[0.77 0.08 0.2 0.38])
plot(global_ws,period)
hold on
plot(gm_ws,period,'k--')
hold off
xlabel('power')
title('Global spectrum')
set(gca,'YLim',[min(period),max(period)],'YDir','reverse',...
	'YTick',Yticks(:),'YTickLabel','')
set(gca,'XLim',[0,1.1*max(max(gm_ws),max(global_ws))])

%% Create textbox
annotation1 = annotation('textbox',...
  'Position',[0.03393 0.9079 0.1607 0.07222],...
  'LineStyle','none',...
  'String',states(statename),...
  'FitHeightToText','on');

%text(-110,52,strcat('Pertussis ',int2str(year),' /',int2str(month)),'FontSize',16);

