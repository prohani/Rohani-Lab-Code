function sse=phasemyfit2(params,Input,Actual_Output)
A = params(1);
B = params(2);
C = params(3);
D = params(4);
E = params(5);
indices1 = find(Input<C);
indices2 = find(Input>=C);
Input1 = Input(indices1);
Input2 = Input(indices2);
Output1 = Actual_Output(indices1);
Output2 = Actual_Output(indices2);
Fitted_Curve1 = A*Input1+B;
Fitted_Curve2 = D*Input2+E;
Error_Vector1 = Fitted_Curve1-Output1;
Error_Vector2 = Fitted_Curve2-Output2;
sse = sum(Error_Vector1.^2)+sum(Error_Vector2.^2);