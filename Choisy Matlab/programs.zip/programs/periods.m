function periods(start,last,dataset,ordersize,scaled)

[spectrum significativity] = specmat(start,last,dataset(:,[1 3]));
for i = 4:51
    [spec sign] = specmat(start,last,dataset(:,[1 i]));
    spectrum = [spectrum; spec];
    significativity = [significativity; sign];
end

if scaled>0
    for i =1:49
        spectrum(i,:) = (spectrum(i,:)-min(spectrum(i,:)))/max(spectrum(i,:));
    end
else
    spectrum(spectrum<significativity)=NaN;
end

imagesc(spectrum(flipud(ordersize),:))
%set(gca,'XTick',[1 88 185 282 378],'XTickLabel',[0.1 1 2 3 4])
set(gca,'XTick',[1 88 185 282 379 475 572],'XTickLabel',[0.1 1 2 3 4 5 6])
colormap([white(1);jet(128)])
line([88 88],[0 49],'LineStyle',':','Color','k')
line([185 185],[0 49],'LineStyle',':','Color','k')
line([282 282],[0 49],'LineStyle',':','Color','k')
line([379 379],[0 49],'LineStyle',':','Color','k')
line([475 475],[0 49],'LineStyle',':','Color','k')
