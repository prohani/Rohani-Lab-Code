function x = chisquarequantile(p,dof)
%
%  The chisquare inverse distribution function
%
%     x = ChiSquareQuantile(p,dof)

if any(any(abs(2*p-1)>1))
   error('a probability should be 0<=p<=1 !!!')
end
if any(any(dof<=0))
   error('degreesOFfreedom, dof, is wrong')
end

x = gammaquantile(p,dof*0.5)*2;

return
