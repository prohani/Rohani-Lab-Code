function plotperiods(dataset,ordersize,dates,scaled)

%plotperiods(pertussis,ordersize,[1951 1962 1963 1976 1977 1991],-1)
%plotperiods(pertussis,ordersize,[1951 1962 1963 1991 1994 2003],-1)
%plotperiods(pertussis,ordersize,[1951 1962 1963 1976 1977 1991],1)
%plotperiods(pertussis,ordersize,[1951 1962 1963 1991 1994 2003],1)
% export : width = 15 cm.

figure
subplot(1,3,1)
periods(dates(1),dates(2),dataset,ordersize,scaled)
xlabel('period (year)')
ylabel('states')
title(strcat(num2str(dates(1)),'-',num2str(dates(2))))
subplot(1,3,2)
periods(dates(3),dates(4),dataset,ordersize,scaled)
xlabel('period (year)')
title(strcat(num2str(dates(3)),'-',num2str(dates(4))))
subplot(1,3,3)
periods(dates(5),dates(6),dataset,ordersize,scaled)
xlabel('period (year)')
title(strcat(num2str(dates(5)),'-',num2str(dates(6))))

annotation('textbox',...
  'Position',[0.04643 0.9127 0.1607 0.07222],...
  'LineStyle','none',...
  'String',{'Pertussis'},...
  'FitHeightToText','on');
