function f = gammadensity(x,dof)
%
%  The gamma density function
%
%     f = gammadensity(p,dof)

if any(any(dof<=0))
   error('degreesOFfreedom, dof, is wrong')
end

f = x .^ (dof-1) .* exp(-x) ./ gamma(dof);
I0 = find(x<0);
f(I0) = zeros(size(I0));

return
