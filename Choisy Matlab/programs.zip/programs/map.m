function map
% This function draws a map.
% Load the data and discard all the island points.
tmp = load('usa.mat','-mat');
x = tmp.x;
y = tmp.y;
tmp = find(isnan(x));
x(tmp(1):end)=[];
y(tmp(1):end)=[];
% Set the figure properties.
figure1 = figure(...
  'Color',[1 1 1],...
  'PaperPosition',[0.6345 6.345 20.3 15.23],...
  'PaperSize',[20.98 29.68]);
% Set the figure axes properties.
axes1 = axes('DataAspectRatio',[1.387247 1 1],...
             'Position',[-0.01089 -0.08493 1.089 1.167],...
             'XColor',[1 1 1],...
             'YColor',[1 1 1],...
             'ZColor',[1 1 1]);
xlim(axes1,[-130 -60]);
ylim(axes1,[24 50]);
hold(axes1,'all');
% Plot the map.
%plot1 = fill(x,y,[0.8314 0.8157 0.7843]);
plot1 = plot(x,y,'k');