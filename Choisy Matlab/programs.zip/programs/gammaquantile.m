function x = gammaquantile(p,dof)
%
%  The gamma inverse distribution function
%
%     x = gammaquantile(p,dof)

if any(any(abs(2*p-1)>1))
   error('a probability should be 0<=p<=1 !!!')
end
if any(any(dof<=0))
   error('degreesOFfreedom, dof, is wrong')
end

x = max(dof-1,0.1);
dx = 1;
while any(any(abs(dx)>256*eps*max(x,1)))
   dx = (gammaproba(x,dof) - p) ./ gammadensity(x,dof);
   x = x - dx;
   x = x + (dx - x) / 2 .* (x<0);
end

I0 = find(p==0);
x(I0) = zeros(size(I0));
I1 = find(p==1);
x(I1) = zeros(size(I0)) + Inf;

return
